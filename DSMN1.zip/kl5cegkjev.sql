-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Lun 27 Mars 2023 à 20:36
-- Version du serveur :  5.7.33-0ubuntu0.16.04.1
-- Version de PHP :  7.0.33-0ubuntu0.16.04.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `kl5cegkjev`
--

-- --------------------------------------------------------

--
-- Structure de la table `achievements`
--

CREATE TABLE `achievements` (
  `uid` int(10) DEFAULT NULL,
  `achievement` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `achievements`
--

INSERT INTO `achievements` (`uid`, `achievement`) VALUES
(14, 'Finally, A Job'),
(140, 'At the End'),
(14, 'Finally, A Job'),
(106, 'Finally, A Job'),
(141, 'At the End'),
(28, 'A Dirty Mind'),
(142, 'At the End'),
(100, 'Finally, A Job'),
(106, 'Finally, A Job'),
(1, 'Finally, A Job'),
(28, 'Finally, A Job'),
(88, 'Finally, A Job'),
(49, 'Finally, A Job'),
(143, 'At the End'),
(88, 'Finally, A Job'),
(144, 'At the End'),
(145, 'At the End'),
(48, 'Finally, A Job'),
(8, 'Finally, A Job'),
(76, 'Finally, A Job'),
(141, 'Finally, A Job'),
(8, 'Finally, A Job'),
(90, 'Finally, A Job'),
(48, 'Finally, A Job'),
(68, 'Finally, A Job'),
(48, 'Finally, A Job'),
(90, 'Finally, A Job'),
(5, 'Finally, A Job'),
(7, 'Finally, A Job'),
(143, 'A Dirty Mind'),
(7, 'Finally, A Job'),
(14, 'Finally, A Job'),
(76, 'A Dirty Mind'),
(76, 'A Dirty Mind'),
(146, 'At the End'),
(125, 'Finally, A Job'),
(146, 'Finally, A Job'),
(42, 'Finally, A Job'),
(125, 'Finally, A Job'),
(28, 'Finally, A Job'),
(14, 'Fitness'),
(30, 'Fitness'),
(30, 'Fitness'),
(38, 'Fitness'),
(63, 'Finally, A Job'),
(38, 'Fitness'),
(28, 'Fitness'),
(28, 'Fitness'),
(38, 'Fitness'),
(36, 'A Dirty Mind'),
(147, 'At the End'),
(28, 'Fitness'),
(8, 'Finally, A Job'),
(148, 'At the End'),
(54, 'Fitness'),
(54, 'Fitness'),
(135, 'Fitness'),
(54, 'Fitness'),
(54, 'Fitness'),
(63, 'Finally, A Job'),
(149, 'At the End'),
(149, 'Fitness'),
(148, 'Legal driver'),
(150, 'At the End'),
(150, 'Legal driver'),
(8, 'Finally, A Job'),
(91, 'Finally, A Job'),
(76, 'Finally, A Job'),
(151, 'At the End'),
(152, 'At the End'),
(124, 'Fitness'),
(124, 'Fitness'),
(36, 'Finally, A Job'),
(153, 'At the End'),
(124, 'Fitness'),
(150, 'Finally, A Job'),
(23, 'Finally, A Job'),
(49, 'Finally, A Job'),
(49, 'Finally, A Job'),
(152, 'Fitness'),
(152, 'Fitness'),
(100, 'Finally, A Job'),
(45, 'Finally, A Job'),
(106, 'Finally, A Job'),
(100, 'Finally, A Job'),
(76, 'Finally, A Job'),
(13, 'Finally, A Job'),
(91, 'Finally, A Job'),
(100, 'Finally, A Job'),
(28, 'Finally, A Job'),
(76, 'Finally, A Job'),
(91, 'Finally, A Job'),
(93, 'Finally, A Job'),
(131, 'Fitness'),
(76, 'Finally, A Job'),
(13, 'Fitness'),
(106, 'Fitness'),
(13, 'Fitness'),
(13, 'Fitness'),
(13, 'Fitness'),
(13, 'Fitness'),
(13, 'Fitness'),
(37, 'Fitness'),
(106, 'Fitness'),
(13, 'Fitness'),
(120, 'Fitness'),
(150, 'Fitness'),
(150, 'Fitness'),
(154, 'At the End'),
(149, 'Fitness'),
(155, 'At the End'),
(156, 'At the End'),
(157, 'At the End'),
(154, 'Fitness'),
(158, 'At the End'),
(157, 'A Dirty Mind'),
(159, 'At the End'),
(160, 'At the End'),
(157, 'A Dirty Mind'),
(157, 'A Dirty Mind'),
(15, 'Finally, A Job'),
(113, 'Finally, A Job'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(13, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(35, 'Finally, A Job'),
(155, 'Obamacare'),
(63, 'Obamacare'),
(63, 'Obamacare'),
(93, 'A Dirty Mind'),
(93, 'A Dirty Mind'),
(113, 'Obamacare'),
(110, 'A Dirty Mind'),
(154, 'Finally, A Job'),
(76, 'A Dirty Mind'),
(154, 'Finally, A Job'),
(154, 'Finally, A Job'),
(63, 'Obamacare'),
(161, 'At the End'),
(35, 'Finally, A Job'),
(28, 'Finally, A Job'),
(100, 'Finally, A Job'),
(28, 'Finally, A Job'),
(35, 'Finally, A Job'),
(91, 'Fitness'),
(100, 'Fitness'),
(91, 'Fitness'),
(88, 'Fitness'),
(100, 'Finally, A Job'),
(88, 'A Dirty Mind'),
(62, 'Fitness'),
(100, 'Fitness'),
(62, 'Fitness'),
(100, 'Fitness'),
(106, 'Fitness'),
(35, 'Finally, A Job'),
(63, 'Fitness'),
(13, 'Fitness'),
(13, 'Finally, A Job'),
(63, 'Finally, A Job'),
(35, 'Finally, A Job'),
(13, 'Finally, A Job'),
(63, 'Finally, A Job'),
(35, 'Finally, A Job'),
(13, 'A Dirty Mind'),
(35, 'Finally, A Job'),
(28, 'Regular'),
(28, 'A Dirty Mind'),
(63, 'A Dirty Mind'),
(35, 'First wheels'),
(163, 'At the End'),
(17, 'Finally, A Job'),
(28, 'Regular'),
(35, 'Legal driver'),
(35, 'Finally, A Job'),
(48, 'Finally, A Job'),
(35, 'Finally, A Job'),
(63, 'A Dirty Mind'),
(63, 'A Dirty Mind'),
(90, 'Finally, A Job'),
(90, 'Finally, A Job'),
(90, 'Finally, A Job'),
(48, 'Finally, A Job'),
(63, 'Finally, A Job'),
(48, 'Finally, A Job'),
(90, 'Fitness'),
(164, 'At the End'),
(42, 'Finally, A Job'),
(165, 'At the End'),
(28, 'Regular'),
(121, 'Fitness'),
(166, 'At the End'),
(76, 'Finally, A Job'),
(8, 'Finally, A Job'),
(167, 'At the End'),
(167, 'Finally, A Job'),
(83, 'A Dirty Mind'),
(83, 'A Dirty Mind'),
(83, 'A Dirty Mind'),
(168, 'At the End'),
(8, 'Illegal Weapon'),
(169, 'At the End'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(42, 'Fitness'),
(91, 'Finally, A Job'),
(121, 'Finally, A Job'),
(42, 'Finally, A Job'),
(167, 'Finally, A Job'),
(167, 'Finally, A Job'),
(28, 'Finally, A Job'),
(28, 'Regular'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(28, 'A Dirty Mind'),
(24, 'Finally, A Job'),
(98, 'High roller'),
(113, 'A Dirty Mind'),
(113, 'A Dirty Mind'),
(113, 'A Dirty Mind'),
(113, 'A Dirty Mind'),
(93, 'Finally, A Job'),
(24, 'Finally, A Job'),
(117, 'Finally, A Job'),
(167, 'Fitness'),
(170, 'At the End'),
(8, 'First wheels'),
(156, 'Obamacare'),
(171, 'At the End'),
(156, 'Finally, A Job'),
(156, 'Finally, A Job'),
(8, 'Meeting people'),
(42, 'Meeting people'),
(8, 'Meeting people'),
(42, 'Meeting people'),
(171, 'Finally, A Job'),
(7, 'Finally, A Job'),
(7, 'Finally, A Job'),
(7, 'Finally, A Job'),
(113, 'Finally, A Job'),
(148, 'Finally, A Job'),
(170, 'Finally, A Job'),
(158, 'Finally, A Job'),
(148, 'Finally, A Job'),
(170, 'Finally, A Job'),
(171, 'Finally, A Job'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(42, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(8, 'A Dirty Mind'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(172, 'At the End'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(171, 'Finally, A Job'),
(148, 'Finally, A Job'),
(171, 'Legal driver'),
(148, 'Finally, A Job'),
(42, 'Finally, A Job'),
(173, 'At the End'),
(156, 'Obamacare'),
(174, 'At the End'),
(91, 'Finally, A Job'),
(173, 'Finally, A Job'),
(176, 'At the End'),
(100, 'Finally, A Job'),
(177, 'At the End'),
(178, 'At the End'),
(85, 'Finally, A Job'),
(175, 'At the End'),
(147, 'Legal driver'),
(178, 'Finally, A Job'),
(178, 'Fitness'),
(152, 'Finally, A Job'),
(13, 'A Dirty Mind'),
(175, 'Legal driver'),
(49, 'Finally, A Job'),
(169, 'Finally, A Job'),
(13, 'A Dirty Mind'),
(91, 'Finally, A Job'),
(29, 'Finally, A Job'),
(157, 'A Dirty Mind'),
(179, 'At the End'),
(167, 'Legal driver'),
(28, 'Regular'),
(98, 'I\'m rich!'),
(36, 'High roller'),
(169, 'Finally, A Job'),
(98, 'I\'m rich!'),
(36, 'High roller'),
(98, 'I\'m rich!'),
(36, 'High roller'),
(98, 'I\'m rich!'),
(36, 'High roller'),
(98, 'High roller'),
(98, 'High roller'),
(98, 'High roller'),
(98, 'High roller'),
(98, 'High roller'),
(36, 'I\'m rich!'),
(98, 'High roller'),
(36, 'I\'m rich!'),
(98, 'High roller'),
(36, 'I\'m rich!'),
(98, 'High roller'),
(36, 'I\'m rich!'),
(98, 'High roller'),
(42, 'A Dirty Mind'),
(113, 'A Dirty Mind'),
(88, 'A Dirty Mind'),
(157, 'A Dirty Mind'),
(35, 'Finally, A Job'),
(169, 'Finally, A Job'),
(28, 'Finally, A Job'),
(98, 'I\'m rich!'),
(93, 'A Dirty Mind'),
(169, 'Finally, A Job'),
(168, 'Fitness'),
(36, 'High roller'),
(36, 'High roller'),
(100, 'Finally, A Job'),
(98, 'High roller'),
(98, 'First wheels'),
(98, 'I\'m rich!'),
(48, 'Finally, A Job'),
(180, 'At the End'),
(181, 'At the End'),
(152, 'Finally, A Job'),
(179, 'Finally, A Job'),
(177, 'A Dirty Mind'),
(179, 'Finally, A Job'),
(148, 'Finally, A Job'),
(48, 'Finally, A Job'),
(182, 'At the End'),
(183, 'At the End'),
(181, 'Finally, A Job'),
(180, 'Finally, A Job'),
(154, 'Finally, A Job'),
(152, 'Fitness'),
(152, 'Finally, A Job'),
(184, 'At the End'),
(185, 'At the End'),
(36, 'High roller'),
(48, 'Finally, A Job'),
(91, 'Finally, A Job'),
(168, 'Finally, A Job'),
(36, 'I\'m rich!'),
(35, 'Finally, A Job'),
(183, 'Finally, A Job'),
(42, 'Finally, A Job'),
(8, 'Finally, A Job'),
(186, 'At the End'),
(36, 'High roller'),
(28, 'Regular'),
(8, 'Regular'),
(100, 'Finally, A Job'),
(36, 'High roller'),
(182, 'Finally, A Job'),
(173, 'Finally, A Job'),
(154, 'Finally, A Job'),
(184, 'Finally, A Job'),
(184, 'Finally, A Job'),
(187, 'At the End'),
(48, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(173, 'Finally, A Job'),
(154, 'Finally, A Job'),
(88, 'Finally, A Job'),
(48, 'Finally, A Job'),
(85, 'Finally, A Job'),
(188, 'At the End'),
(48, 'Finally, A Job'),
(154, 'Finally, A Job'),
(189, 'At the End'),
(190, 'At the End'),
(158, 'Finally, A Job'),
(191, 'At the End'),
(158, 'Finally, A Job'),
(19, 'Finally, A Job'),
(98, 'High roller'),
(98, 'I\'m rich!'),
(154, 'Finally, A Job'),
(173, 'Finally, A Job'),
(179, 'Finally, A Job'),
(188, 'Finally, A Job'),
(192, 'At the End'),
(19, 'Finally, A Job'),
(186, 'Finally, A Job'),
(167, 'Finally, A Job'),
(175, 'Finally, A Job'),
(36, 'I\'m rich!'),
(4, 'Finally, A Job'),
(188, 'Finally, A Job'),
(36, 'High roller'),
(49, 'Finally, A Job'),
(173, 'A Dirty Mind'),
(173, 'A Dirty Mind'),
(173, 'A Dirty Mind'),
(36, 'High roller'),
(167, 'A Dirty Mind'),
(167, 'A Dirty Mind'),
(167, 'A Dirty Mind'),
(154, 'A Dirty Mind'),
(49, 'Finally, A Job'),
(106, 'Obamacare'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(193, 'At the End'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(35, 'Finally, A Job'),
(189, 'Finally, A Job'),
(91, 'Finally, A Job'),
(36, 'High roller'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(36, 'High roller'),
(184, 'Legal driver'),
(154, 'Finally, A Job'),
(154, 'Finally, A Job'),
(178, 'Finally, A Job'),
(167, 'Finally, A Job'),
(175, 'Finally, A Job'),
(184, 'Finally, A Job'),
(184, 'Finally, A Job'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(36, 'I\'m rich!'),
(184, 'Finally, A Job'),
(36, 'I\'m rich!'),
(194, 'At the End'),
(184, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(173, 'Finally, A Job'),
(184, 'Finally, A Job'),
(184, 'Finally, A Job'),
(195, 'At the End'),
(12, 'Finally, A Job'),
(173, 'Finally, A Job'),
(154, 'Legal driver'),
(173, 'Finally, A Job'),
(196, 'At the End'),
(154, 'Finally, A Job'),
(194, 'Finally, A Job'),
(178, 'Legal driver'),
(141, 'Finally, A Job'),
(182, 'Finally, A Job'),
(154, 'Finally, A Job'),
(154, 'Finally, A Job'),
(36, 'High roller'),
(178, 'Finally, A Job'),
(48, 'Finally, A Job'),
(117, 'Fitness'),
(48, 'Finally, A Job'),
(154, 'Finally, A Job'),
(182, 'Legal driver'),
(167, 'Finally, A Job'),
(8, 'Regular'),
(91, 'Regular'),
(164, 'Finally, A Job'),
(182, 'Finally, A Job'),
(175, 'Finally, A Job'),
(182, 'Finally, A Job'),
(178, 'Finally, A Job'),
(48, 'Finally, A Job'),
(182, 'Finally, A Job'),
(178, 'Finally, A Job'),
(178, 'Finally, A Job'),
(147, 'Fitness'),
(197, 'At the End'),
(48, 'Finally, A Job'),
(148, 'Finally, A Job'),
(154, 'Finally, A Job'),
(154, 'A Dirty Mind'),
(154, 'A Dirty Mind'),
(86, 'A Dirty Mind'),
(86, 'A Dirty Mind'),
(167, 'A Dirty Mind'),
(86, 'A Dirty Mind'),
(86, 'A Dirty Mind'),
(86, 'A Dirty Mind'),
(167, 'A Dirty Mind'),
(147, 'Finally, A Job'),
(1, 'A Dirty Mind'),
(198, 'At the End'),
(36, 'Finally, A Job'),
(8, 'Regular'),
(91, 'Regular'),
(36, 'High roller'),
(1, 'A Dirty Mind'),
(36, 'High roller'),
(35, 'Finally, A Job'),
(176, 'Finally, A Job'),
(48, 'Finally, A Job'),
(36, 'Legal driver'),
(36, 'I\'m rich!'),
(35, 'Finally, A Job'),
(48, 'Finally, A Job'),
(98, 'Legal driver'),
(98, 'I\'m rich!'),
(36, 'High roller'),
(36, 'A Dirty Mind'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(174, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(174, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(174, 'Flash mob'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(174, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(174, 'Flash mob'),
(48, 'Flash mob'),
(36, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(174, 'Flash mob'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(35, 'Finally, A Job'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(36, 'High roller'),
(48, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(171, 'Flash mob'),
(157, 'Flash mob'),
(17, 'Flash mob'),
(148, 'Flash mob'),
(113, 'Finally, A Job'),
(8, 'Regular'),
(36, 'High roller'),
(98, 'I\'m rich!'),
(35, 'Finally, A Job'),
(199, 'At the End'),
(93, 'A Dirty Mind'),
(93, 'A Dirty Mind'),
(30, 'Finally, A Job'),
(98, 'I\'m rich!'),
(98, 'I\'m rich!'),
(93, 'A Dirty Mind'),
(157, 'A Dirty Mind'),
(93, 'A Dirty Mind'),
(157, 'A Dirty Mind'),
(93, 'A Dirty Mind'),
(93, 'A Dirty Mind'),
(178, 'Finally, A Job'),
(98, 'High roller'),
(30, 'Finally, A Job'),
(164, 'Finally, A Job'),
(164, 'Finally, A Job'),
(36, 'High roller'),
(178, 'Finally, A Job'),
(98, 'I\'m rich!'),
(178, 'A Dirty Mind'),
(165, 'Finally, A Job'),
(100, 'Finally, A Job'),
(157, 'A Dirty Mind'),
(200, 'At the End'),
(182, 'Finally, A Job'),
(21, 'Finally, A Job'),
(8, 'Regular'),
(158, 'Finally, A Job'),
(200, 'Legal driver'),
(183, 'Finally, A Job'),
(163, 'Fitness'),
(183, 'Finally, A Job'),
(156, 'Obamacare'),
(183, 'Finally, A Job'),
(188, 'Obamacare'),
(36, 'Obamacare'),
(36, 'Obamacare'),
(36, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(98, 'I\'m rich!'),
(30, 'I\'m rich!'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'High roller'),
(30, 'I\'m rich!'),
(98, 'I\'m rich!'),
(45, 'I\'m rich!'),
(45, 'I\'m rich!'),
(45, 'I\'m rich!'),
(45, 'High roller'),
(98, 'I\'m rich!'),
(45, 'High roller'),
(98, 'I\'m rich!'),
(98, 'I\'m rich!'),
(98, 'I\'m rich!'),
(98, 'I\'m rich!'),
(98, 'High roller'),
(45, 'I\'m rich!'),
(45, 'High roller'),
(45, 'High roller'),
(45, 'I\'m rich!'),
(45, 'I\'m rich!'),
(45, 'I\'m rich!'),
(45, 'I\'m rich!'),
(45, 'High roller'),
(98, 'I\'m rich!'),
(36, 'High roller'),
(36, 'High roller'),
(36, 'High roller'),
(35, 'High roller'),
(35, 'High roller'),
(35, 'High roller'),
(35, 'High roller'),
(35, 'High roller'),
(35, 'High roller'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(98, 'I\'m rich!'),
(98, 'I\'m rich!'),
(35, 'I\'m rich!'),
(98, 'I\'m rich!'),
(122, 'Obamacare'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(35, 'I\'m rich!'),
(98, 'I\'m rich!'),
(7, 'High roller'),
(7, 'I\'m rich!'),
(7, 'High roller'),
(7, 'High roller'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(16, 'High roller'),
(7, 'I\'m rich!'),
(16, 'High roller'),
(7, 'I\'m rich!'),
(16, 'High roller'),
(7, 'I\'m rich!'),
(16, 'High roller'),
(7, 'I\'m rich!'),
(16, 'High roller'),
(7, 'I\'m rich!'),
(16, 'High roller'),
(16, 'I\'m rich!'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(1, 'High roller'),
(1, 'High roller'),
(16, 'I\'m rich!'),
(16, 'I\'m rich!'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(7, 'I\'m rich!'),
(16, 'I\'m rich!'),
(16, 'I\'m rich!'),
(7, 'High roller'),
(7, 'High roller'),
(16, 'I\'m rich!'),
(7, 'I\'m rich!'),
(16, 'I\'m rich!'),
(7, 'I\'m rich!'),
(16, 'I\'m rich!'),
(1, 'High roller'),
(1, 'High roller'),
(1, 'High roller'),
(7, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'High roller'),
(1, 'I\'m rich!'),
(9, 'High roller'),
(9, 'I\'m rich!'),
(9, 'High roller'),
(9, 'I\'m rich!'),
(9, 'I\'m rich!'),
(9, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'High roller'),
(1, 'High roller'),
(1, 'High roller'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'High roller'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'High roller'),
(11, 'High roller'),
(1, 'High roller'),
(1, 'High roller'),
(30, 'High roller'),
(30, 'I\'m rich!'),
(30, 'I\'m rich!'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(11, 'High roller'),
(30, 'I\'m rich!'),
(30, 'I\'m rich!'),
(30, 'I\'m rich!'),
(30, 'I\'m rich!'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(4, 'High roller'),
(30, 'I\'m rich!'),
(1, 'High roller'),
(1, 'High roller'),
(11, 'High roller'),
(11, 'I\'m rich!'),
(4, 'High roller'),
(11, 'High roller'),
(4, 'I\'m rich!'),
(11, 'High roller'),
(4, 'I\'m rich!'),
(11, 'High roller'),
(4, 'I\'m rich!'),
(11, 'High roller'),
(4, 'I\'m rich!'),
(11, 'High roller'),
(4, 'I\'m rich!'),
(11, 'High roller'),
(4, 'I\'m rich!'),
(4, 'I\'m rich!'),
(11, 'High roller'),
(1, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'High roller'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(4, 'High roller'),
(16, 'I\'m rich!'),
(1, 'I\'m rich!'),
(9, 'High roller'),
(9, 'High roller'),
(9, 'I\'m rich!'),
(1, 'High roller'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(1, 'I\'m rich!'),
(11, 'I\'m rich!'),
(1, 'I\'m rich!'),
(11, 'High roller'),
(1, 'I\'m rich!'),
(11, 'High roller'),
(1, 'I\'m rich!'),
(11, 'High roller'),
(1, 'I\'m rich!'),
(11, 'High roller'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(9, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'High roller'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(17, 'High roller'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'High roller'),
(17, 'High roller'),
(17, 'High roller'),
(17, 'High roller'),
(17, 'High roller'),
(17, 'High roller'),
(17, 'High roller'),
(17, 'High roller'),
(17, 'High roller'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(1, 'I\'m rich!'),
(17, 'I\'m rich!'),
(1, 'I\'m rich!'),
(17, 'I\'m rich!'),
(1, 'I\'m rich!'),
(17, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(17, 'High roller'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(17, 'I\'m rich!'),
(4, 'I\'m rich!'),
(28, 'High roller'),
(28, 'I\'m rich!'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(28, 'I\'m rich!'),
(8, 'High roller'),
(8, 'High roller'),
(4, 'I\'m rich!'),
(11, 'High roller'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'High roller'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(1, 'I\'m rich!'),
(8, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(8, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(9, 'High roller'),
(9, 'I\'m rich!'),
(9, 'I\'m rich!'),
(28, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'I\'m rich!'),
(11, 'High roller'),
(1, 'I\'m rich!'),
(8, 'High roller'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(11, 'I\'m rich!'),
(24, 'High roller'),
(71, 'High roller'),
(71, 'I\'m rich!'),
(11, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(8, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'High roller'),
(1, 'I\'m rich!'),
(1, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'High roller'),
(24, 'I\'m rich!'),
(1, 'I\'m rich!'),
(24, 'I\'m rich!'),
(1, 'I\'m rich!'),
(1, 'High roller'),
(28, 'High roller'),
(28, 'I\'m rich!'),
(28, 'I\'m rich!'),
(28, 'High roller'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(1, 'High roller'),
(4, 'I\'m rich!'),
(4, 'High roller'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!'),
(24, 'I\'m rich!');

-- --------------------------------------------------------

--
-- Structure de la table `bans`
--

CREATE TABLE `bans` (
  `id` int(10) NOT NULL,
  `username` varchar(24) DEFAULT NULL,
  `unbandate` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(16) DEFAULT NULL,
  `bannedby` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `reason` varchar(128) DEFAULT NULL,
  `permanent` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `bans`
--

INSERT INTO `bans` (`id`, `username`, `unbandate`, `ip`, `bannedby`, `date`, `reason`, `permanent`) VALUES
(1, 'X__2', 0, '41.250.123.41', 'Rex', '2023-03-15 17:47:04', 'Airbreak', 3),
(2, 'Yasser_Zineddine', 0, '41.250.121.97', 'Rex', '2023-03-15 22:08:29', 'Airbreak', 3),
(3, 'dob_lghaba', 0, '196.89.38.66', 'psiko_boukhris', '2023-03-16 00:16:25', 'DM (3/3 warnings)', 0),
(4, 'STEVAW_MARTINEZ', 0, '196.74.232.227', 'Rex', '2023-03-16 08:08:05', 'Teleport hacks', 0),
(5, 'White_Flash', 0, '105.71.147.148', 'Rex', '2023-03-16 12:07:52', 'Weapon hacks (Silenced Pistol)', 0),
(6, 'POP_SMOKE', 0, '196.64.223.8', 'Rex', '2023-03-16 13:11:09', 'Weapon hacks (Silenced Pistol)', 0),
(7, 'HOUSSAM_KABBACHE', 0, '41.143.55.8', 'Rex', '2023-03-16 16:04:10', 'Weapon hacks (M4)', 0),
(9, 'Vigas_Omerta', 0, '105.72.59.250', 'Rex', '2023-03-16 20:22:18', 'Weapon hacks (Colt 45)', 0),
(10, 'HADES_SMOKERS', 0, '196.65.166.188', 'psiko_boukhris', '2023-03-16 20:45:37', 'DM (3/3 warnings)', 0),
(11, 'Limbo_sinyore', 1679324558, '196.117.3.94', 'psiko_boukhris', '2023-03-17 15:02:38', 'DM (3/3 warnings)', 0),
(12, 'PABLO_PICASO', 1679584780, '41.249.150.0', 'Rex', '2023-03-20 15:19:40', 'Teleport hacks', 0),
(13, 'SALIM_LUCAS', 1679664906, '196.112.130.116', 'Rex', '2023-03-21 13:35:06', 'Weapon hacks (Silenced Pistol)', 0),
(14, 'Snop_Amar', 1679720633, '105.66.128.235', 'psiko_boukhris', '2023-03-22 05:03:53', 'DM (3/3 warnings)', 0),
(16, 'BADR_PEDRI', 1680141597, '105.155.18.50', 'Rex', '2023-03-27 01:59:57', 'Teleport hacks', 0);

-- --------------------------------------------------------

--
-- Structure de la table `billboards`
--

CREATE TABLE `billboards` (
  `id` int(11) NOT NULL,
  `text` int(11) DEFAULT NULL,
  `rentby` int(11) NOT NULL DEFAULT '0',
  `rentdate` int(11) NOT NULL DEFAULT '0',
  `cost` int(11) NOT NULL DEFAULT '0',
  `posX` float NOT NULL DEFAULT '0',
  `posY` float NOT NULL DEFAULT '0',
  `posZ` float NOT NULL DEFAULT '0',
  `posRX` float NOT NULL DEFAULT '0',
  `posRY` float NOT NULL DEFAULT '0',
  `posRZ` float NOT NULL DEFAULT '0',
  `int` int(11) NOT NULL DEFAULT '0',
  `vw` int(11) NOT NULL DEFAULT '0',
  `model` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `businesses`
--

CREATE TABLE `businesses` (
  `id` int(10) NOT NULL,
  `ownerid` int(10) DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `name` varchar(64) DEFAULT 'Unamed Business',
  `message` varchar(128) DEFAULT 'Welcome to the business!',
  `type` tinyint(2) DEFAULT '0',
  `price` int(10) DEFAULT '0',
  `entryfee` int(10) DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `timestamp` int(10) DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `int_x` float DEFAULT '0',
  `int_y` float DEFAULT '0',
  `int_z` float DEFAULT '0',
  `int_a` float DEFAULT '0',
  `interior` tinyint(2) DEFAULT '0',
  `world` int(10) DEFAULT '0',
  `outsideint` tinyint(2) DEFAULT '0',
  `outsidevw` int(10) DEFAULT '0',
  `cash` int(10) DEFAULT '0',
  `products` int(10) DEFAULT '500',
  `robbed` smallint(6) NOT NULL DEFAULT '3',
  `robbing` int(11) DEFAULT NULL,
  `prices0` int(11) NOT NULL DEFAULT '0',
  `prices1` int(11) NOT NULL DEFAULT '0',
  `prices2` int(11) NOT NULL DEFAULT '0',
  `prices3` int(11) NOT NULL DEFAULT '0',
  `prices4` int(11) NOT NULL DEFAULT '0',
  `prices5` int(11) NOT NULL DEFAULT '0',
  `prices6` int(11) NOT NULL DEFAULT '0',
  `prices7` int(11) NOT NULL DEFAULT '0',
  `prices8` int(11) NOT NULL DEFAULT '0',
  `prices9` int(11) NOT NULL DEFAULT '0',
  `prices10` int(11) NOT NULL DEFAULT '0',
  `prices11` int(11) NOT NULL DEFAULT '0',
  `prices12` int(11) NOT NULL DEFAULT '0',
  `prices13` int(11) NOT NULL DEFAULT '0',
  `prices14` int(11) NOT NULL DEFAULT '0',
  `prices15` int(11) NOT NULL DEFAULT '0',
  `prices16` int(11) NOT NULL DEFAULT '0',
  `prices17` int(11) NOT NULL DEFAULT '0',
  `prices18` int(11) NOT NULL DEFAULT '0',
  `prices19` int(11) NOT NULL DEFAULT '0',
  `prices20` int(11) NOT NULL DEFAULT '0',
  `prices21` int(11) NOT NULL DEFAULT '0',
  `prices22` int(11) NOT NULL DEFAULT '0',
  `prices23` int(11) NOT NULL DEFAULT '0',
  `prices24` int(11) NOT NULL DEFAULT '0',
  `cVehicleX` float DEFAULT '0',
  `cVehicleY` float DEFAULT '0',
  `cVehicleZ` float DEFAULT '0',
  `cVehicleA` float DEFAULT '0',
  `materials` int(10) DEFAULT '0',
  `radarstatu` int(10) DEFAULT '0',
  `vehtype` int(12) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `businesses`
--

INSERT INTO `businesses` (`id`, `ownerid`, `owner`, `name`, `message`, `type`, `price`, `entryfee`, `locked`, `timestamp`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `int_x`, `int_y`, `int_z`, `int_a`, `interior`, `world`, `outsideint`, `outsidevw`, `cash`, `products`, `robbed`, `robbing`, `prices0`, `prices1`, `prices2`, `prices3`, `prices4`, `prices5`, `prices6`, `prices7`, `prices8`, `prices9`, `prices10`, `prices11`, `prices12`, `prices13`, `prices14`, `prices15`, `prices16`, `prices17`, `prices18`, `prices19`, `prices20`, `prices21`, `prices22`, `prices23`, `prices24`, `cVehicleX`, `cVehicleY`, `cVehicleZ`, `cVehicleA`, `materials`, `radarstatu`, `vehtype`) VALUES
(1, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 8, 15000000, 0, 0, 1679807114, 542.969, -1293.81, 17.242, -165.053, 37.701, -3.543, 1225.51, 262.64, 3, 3000001, 0, 0, 0, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(3, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1679470651, 1833.78, -1842.64, 13.578, 105.529, 2585.81, 1437.58, 1800.97, 0, 16, 3000003, 0, 0, 4780, 863, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(4, 94, 'Unknown_', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1678974422, 1928.58, -1776.23, 13.547, -85.542, 2585.81, 1437.58, 1800.97, 0, 16, 3000004, 0, 0, 55200, 810, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(5, 36, 'James_Edrian', 'Unamed Business', 'Welcome to the business!', 2, 2250000, 0, 0, 1678996143, 1154.73, -1439.86, 15.797, 83.737, 2080.62, 1224.9, 1019.08, 356, 1, 3000005, 0, 0, 54953, -5822, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(6, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 3, 1800000, 0, 0, 1678797342, 1154.73, -1457.59, 15.797, 91.353, 772.408, -4.741, 1000.73, 0, 5, 3000006, 0, 0, 68625, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(7, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1678797342, 1158.54, -1473.66, 15.797, 120.223, 2585.81, 1437.58, 1800.97, 0, 16, 3000007, 0, 0, 13740, 955, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(8, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 4, 2500000, 0, 0, 1678797342, 1102.41, -1440.18, 15.797, -87.734, 363.328, -74.65, 1001.51, 315, 10, 3000008, 0, 0, 7290, 726, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(9, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 3, 1800000, 0, 0, 1678797342, 1102.41, -1457.69, 15.797, -83.475, 772.408, -4.741, 1000.73, 0, 5, 3000009, 0, 0, 23275, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(10, 17, 'JAIMSE_PALACIO', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1679470794, 1352.47, -1759.25, 13.508, -9.151, 2585.81, 1437.58, 1800.97, 0, 16, 3000010, 0, 0, 1741018150, 4000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(11, 9, 'STEVAW_MARTINEZ', 'Unamed Business', 'Welcome to the business!', 2, 2250000, 0, 0, 1679339693, 2244.32, -1665.55, 15.477, -21.199, 2080.62, 1224.9, 1019.08, 356, 1, 3000011, 0, 0, 4465, -5058, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(12, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 3, 1800000, 0, 0, 1678797342, 2229.92, -1721.27, 13.555, 138.087, 772.408, -4.741, 1000.73, 0, 5, 3000012, 0, 0, 367450, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(13, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 4, 2500000, 0, 0, 1678797342, 279.485, -1435.47, 13.98, -146, 363.328, -74.65, 1001.51, 315, 10, 3000013, 0, 0, 680, 979, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(14, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 2, 2250000, 0, 0, 1678797342, 461.579, -1500.65, 31.051, -75.986, 2080.62, 1224.9, 1019.08, 356, 1, 3000014, 0, 0, 4000, 996, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(15, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1678797342, 388.04, -1897.14, 7.836, -85.107, 2585.81, 1437.58, 1800.97, 0, 16, 3000015, 0, 0, 10480, 959, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(16, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 5, 2025000, 0, 0, 1678797342, 371.232, -1637.32, 32.891, -6.479, 834.152, 7.41, 1004.19, 90, 3, 3000016, 0, 0, 2100, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(17, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1678797342, 640.597, -1758.03, 13.329, -4.861, 2585.81, 1437.58, 1800.97, 0, 16, 3000017, 0, 0, 3530, 980, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(18, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 2, 2250000, 0, 0, 1678797342, 822.93, -1756.98, 13.648, -28.61, 2080.62, 1224.9, 1019.08, 356, 1, 3000018, 0, 0, 9518, -1499, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(19, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 2, 2250000, 0, 0, 1678797342, 810.485, -1616.26, 13.547, 87.089, 2080.62, 1224.9, 1019.08, 356, 1, 3000019, 0, 0, 2000, 998, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(20, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 7, 1575000, 0, 0, 1678797342, 776.371, -1036.3, 24.274, 4.384, -2240.7, 128.301, 1035.41, 270, 6, 3000020, 0, 0, 0, 994, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15500, 1, 1),
(21, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1678797342, 1000.42, -919.533, 42.328, -94.607, 2585.81, 1437.58, 1800.97, 0, 16, 3000021, 0, 0, 2440, 993, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(22, 30, 'CORLO_NEGRO', 'Unamed Business', 'Welcome to the business!', 4, 2500000, 0, 0, 1679332880, 1199.27, -918.25, 43.13, 7.446, 363.328, -74.65, 1001.51, 315, 10, 3000022, 0, 0, 1840, 931, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(23, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1678797342, 1315.38, -897.683, 39.578, -2.21, 2585.81, 1437.58, 1800.97, 0, 16, 3000023, 0, 0, 1830, 994, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(24, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 7, 1575000, 0, 0, 1678797342, 1109.14, -1270.83, 13.547, -4.384, -2240.7, 128.301, 1035.41, 270, 6, 3000024, 0, 0, 0, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(25, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 4, 2500000, 0, 0, 1678797342, 1038.12, -1340.69, 13.737, 179.209, 363.328, -74.65, 1001.51, 315, 10, 3000025, 0, 0, 5870, 812, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(26, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 3, 1800000, 350, 0, 1678797342, 986.847, -1295.58, 13.547, 178.023, 772.408, -4.741, 1000.73, 0, 5, 3000026, 0, 0, 92625, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(27, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 1678797342, 979.597, -1295.73, 13.547, 6.226, 2585.81, 1437.58, 1800.97, 0, 16, 3000027, 0, 0, 3780, 989, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(28, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 5, 2025000, 0, 0, 1678797342, 1001.41, -1296.05, 13.547, 170.687, 834.152, 7.41, 1004.19, 90, 3, 3000028, 0, 0, 1425, 1000, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(29, 24, 'ROCH_PRAN', 'Unamed Business', 'Welcome to the business!', 2, 2250000, 0, 0, 1679806354, 1264.57, -1424.49, 14.953, 174.388, 2080.62, 1224.9, 1019.08, 356, 1, 3000029, 0, 0, 29485, -2881, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(30, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 4, 2500000, 0, 0, 0, 2105.34, -1806.42, 13.555, -86.977, 363.328, -74.65, 1001.51, 315, 10, 3000030, 0, 0, 5360, 305, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(31, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 4, 2500000, 0, 0, 0, 2419.72, -1509.03, 24, 108.121, 363.328, -74.65, 1001.51, 315, 10, 3000031, 0, 0, 1830, 434, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1),
(33, 11, 'GOD_TIPO', 'Unamed Business', 'Welcome to the business!', 0, 0, 0, 0, 1679259369, 2441.96, -1403.65, 24, -112.868, 2585.81, 1437.58, 1800.97, 0, 16, 3000033, 0, 0, 600, 4999999, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30000, 0, 1),
(34, 4, 'Pablo_Walid', 'Unamed Business', 'Welcome to the business!', 4, 500000, 500, 0, 1679337267, 1289.28, -1271.52, 13.544, 170.382, 363.328, -74.65, 1001.51, 315, 10, 3000034, 0, 0, 1210, 476, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(37, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 0, 0, 0, 1207.96, -1131.62, 23.953, 177.589, 2585.81, 1437.58, 1800.97, 0, 16, 3000037, 0, 0, 0, 500, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(40, 0, 'Nobody', 'Unamed Business', 'Welcome to the business!', 0, 1800000, 200, 0, 0, 994.298, -1295.76, 13.547, -178.677, 2585.81, 1437.58, 1800.97, 0, 16, 3000040, 0, 0, 200, 500, 3, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Structure de la table `changes`
--

CREATE TABLE `changes` (
  `slot` tinyint(2) DEFAULT NULL,
  `text` varchar(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `charges`
--

CREATE TABLE `charges` (
  `id` int(10) NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `chargedby` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `reason` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `charges`
--

INSERT INTO `charges` (`id`, `uid`, `chargedby`, `date`, `reason`) VALUES
(1, 36, 'Rachid_ekambi', '2023-03-16 20:15:36', 'hareb mn comico okan 3ndo t7e9i9'),
(2, 11, 'abdollah_algnawi', '2023-03-19 20:28:40', 'dasr');

-- --------------------------------------------------------

--
-- Structure de la table `clothing`
--

CREATE TABLE `clothing` (
  `id` int(10) NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `modelid` smallint(5) DEFAULT NULL,
  `boneid` tinyint(2) DEFAULT NULL,
  `attached` tinyint(1) DEFAULT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `rot_x` float DEFAULT NULL,
  `rot_y` float DEFAULT NULL,
  `rot_z` float DEFAULT NULL,
  `scale_x` float DEFAULT NULL,
  `scale_y` float DEFAULT NULL,
  `scale_z` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `crates`
--

CREATE TABLE `crates` (
  `id` int(11) NOT NULL,
  `cbObject` int(11) DEFAULT '964',
  `Facility` int(11) NOT NULL DEFAULT '0',
  `Group` int(11) NOT NULL DEFAULT '-1',
  `CrateX` float(20,5) NOT NULL DEFAULT '0.00000',
  `CrateY` float(20,5) NOT NULL DEFAULT '0.00000',
  `CrateZ` float(20,5) NOT NULL DEFAULT '0.00000',
  `InVehicle` int(11) NOT NULL DEFAULT '-1',
  `OnVehicle` int(11) NOT NULL DEFAULT '-1',
  `Int` int(11) NOT NULL DEFAULT '0',
  `VW` int(11) NOT NULL DEFAULT '0',
  `Materials` int(11) NOT NULL DEFAULT '0',
  `Gun1` int(11) NOT NULL DEFAULT '0',
  `GunAmount1` int(11) NOT NULL DEFAULT '0',
  `Gun2` int(11) NOT NULL DEFAULT '0',
  `GunAmount2` int(11) NOT NULL DEFAULT '0',
  `Gun3` int(11) NOT NULL DEFAULT '0',
  `GunAmount3` int(11) NOT NULL DEFAULT '0',
  `Gun4` int(11) NOT NULL DEFAULT '0',
  `GunAmount4` int(11) NOT NULL DEFAULT '0',
  `Gun5` int(11) NOT NULL DEFAULT '0',
  `GunAmount5` int(11) NOT NULL DEFAULT '0',
  `Gun6` int(11) NOT NULL DEFAULT '0',
  `GunAmount6` int(11) NOT NULL DEFAULT '0',
  `Gun7` int(11) NOT NULL DEFAULT '0',
  `GunAmount7` int(11) NOT NULL DEFAULT '0',
  `Gun8` int(11) NOT NULL DEFAULT '0',
  `GunAmount8` int(11) NOT NULL DEFAULT '0',
  `Gun9` int(11) NOT NULL DEFAULT '0',
  `GunAmount9` int(11) NOT NULL DEFAULT '0',
  `Gun10` int(11) NOT NULL DEFAULT '0',
  `GunAmount10` int(11) NOT NULL DEFAULT '0',
  `Gun11` int(11) NOT NULL DEFAULT '0',
  `GunAmount11` int(11) NOT NULL DEFAULT '0',
  `Gun12` int(11) NOT NULL DEFAULT '0',
  `GunAmount12` int(11) NOT NULL DEFAULT '0',
  `Gun13` int(11) NOT NULL DEFAULT '0',
  `GunAmount13` int(11) NOT NULL DEFAULT '0',
  `Gun14` int(11) NOT NULL DEFAULT '0',
  `GunAmount14` int(11) NOT NULL DEFAULT '0',
  `Gun15` int(11) NOT NULL DEFAULT '0',
  `GunAmount16` int(11) NOT NULL DEFAULT '0',
  `GunAmount15` int(11) NOT NULL DEFAULT '0',
  `Gun16` int(11) NOT NULL DEFAULT '0',
  `PlacedBy` varchar(24) NOT NULL DEFAULT 'Unknown',
  `Lifespan` int(11) NOT NULL DEFAULT '0',
  `Transfer` int(1) NOT NULL DEFAULT '0',
  `DoorID` int(11) NOT NULL DEFAULT '-1',
  `DoorType` int(11) NOT NULL DEFAULT '-1',
  `Price` int(11) NOT NULL DEFAULT '0',
  `Paid` int(1) NOT NULL DEFAULT '0',
  `Active` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `crews`
--

CREATE TABLE `crews` (
  `id` tinyint(2) NOT NULL,
  `crewid` tinyint(2) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

-- --------------------------------------------------------

--
-- Structure de la table `criminals`
--

CREATE TABLE `criminals` (
  `ID` int(11) NOT NULL,
  `player` varchar(24) NOT NULL,
  `officer` varchar(24) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `crime` text NOT NULL,
  `served` int(11) NOT NULL,
  `minutes` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `divisions`
--

CREATE TABLE `divisions` (
  `id` tinyint(2) DEFAULT NULL,
  `divisionid` tinyint(2) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `divisions`
--

INSERT INTO `divisions` (`id`, `divisionid`, `name`) VALUES
(2, 2, 'Training and Recruitment'),
(2, 3, 'Fire Department'),
(2, 0, 'Surgeon'),
(2, 1, 'Healer'),
(2, 4, 'Dispatcher'),
(4, 0, 'HEAD MECHANIC'),
(4, 1, 'MANAGER '),
(4, 2, 'ASSISTANT MANAGER'),
(4, 3, 'MECHANIC'),
(4, 4, 'TRAINER'),
(1, 0, 'Field Training Officer'),
(1, 1, 'S.W.A.T'),
(1, 2, 'Air Support'),
(1, 3, 'Normal Traffic'),
(1, 4, 'High Commanders');

-- --------------------------------------------------------

--
-- Structure de la table `entrances`
--

CREATE TABLE `entrances` (
  `id` int(10) NOT NULL,
  `ownerid` int(10) DEFAULT '0',
  `owner` varchar(24) DEFAULT NULL,
  `name` varchar(40) DEFAULT NULL,
  `iconid` smallint(5) DEFAULT '1239',
  `locked` tinyint(1) DEFAULT '0',
  `radius` float DEFAULT '3',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `int_x` float DEFAULT '0',
  `int_y` float DEFAULT '0',
  `int_z` float DEFAULT '0',
  `int_a` float DEFAULT '0',
  `interior` tinyint(2) DEFAULT '0',
  `world` int(10) DEFAULT '0',
  `outsideint` tinyint(2) DEFAULT '0',
  `outsidevw` int(10) DEFAULT '0',
  `adminlevel` tinyint(2) DEFAULT '0',
  `factiontype` tinyint(2) DEFAULT '0',
  `vip` tinyint(2) DEFAULT '0',
  `vehicles` tinyint(1) DEFAULT '0',
  `freeze` tinyint(1) DEFAULT '0',
  `password` varchar(64) DEFAULT 'None',
  `label` tinyint(1) DEFAULT '1',
  `gang` tinyint(1) DEFAULT '-1',
  `type` tinyint(1) DEFAULT '0',
  `mapicon` tinyint(2) NOT NULL DEFAULT '-1',
  `color` int(10) NOT NULL DEFAULT '-256'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `entrances`
--

INSERT INTO `entrances` (`id`, `ownerid`, `owner`, `name`, `iconid`, `locked`, `radius`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `int_x`, `int_y`, `int_z`, `int_a`, `interior`, `world`, `outsideint`, `outsidevw`, `adminlevel`, `factiontype`, `vip`, `vehicles`, `freeze`, `password`, `label`, `gang`, `type`, `mapicon`, `color`) VALUES
(417, 0, NULL, 'Los Santos Driving Schol', 1318, 0, 3, 1219.1, -1811.7, 16.594, -179.061, -2029.61, -119.624, 1035.17, 7.332, 3, 1, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, 0, 53, -256),
(420, 0, NULL, 'Los Santos Police Departaments', 1318, 0, 3, 1555.39, -1675.55, 16.194, 90.095, 2411.62, 2453.4, 1569.48, 357.517, 1, 1, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, 0, 30, -256),
(424, 0, NULL, 'Drug House', 1318, 0, 3, 2160.98, -1700.86, 15.086, 277.586, 2352.85, -1180.85, 1027.98, 119.271, 5, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, 23, -256),
(425, 0, NULL, 'Burger Shot', 1318, 0, 3, 2042.29, -1883.8, 13.6, 185.374, 362.749, -75.047, 1001.51, 136.644, 10, 0, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, 0, -1, 4690431),
(432, 0, NULL, 'Recycle', 1313, 0, 3, -2093.53, -2417.59, 30.625, -46.148, -118.42, -315.712, 1001.09, 7.657, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, 0, -1, -256),
(434, 0, NULL, 'Grove Street HQ', 1313, 0, 3, 2495.37, -1691.13, 14.766, 181.864, 1966.6, 1321.65, 966.395, 93.962, 1, 1, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 0, 0, 62, -256),
(437, 0, NULL, 'Los Santos Fedral', 1318, 1, 3, 332.329, -1506.73, 36.039, -131.806, 349.318, -1485.93, 76.539, 36.335, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, 0, 30, 16777215),
(438, 0, NULL, 'Ballas HQ', 1318, 0, 3, 2650.7, -2021.82, 14.177, 268.397, 1797.51, 722.686, 1072.56, 91.578, 0, 1, 0, 0, 0, 0, 0, 0, 1, 'None', 1, 2, 0, -1, -256),
(443, 0, NULL, 'Los Santos Vip Lounge', 1318, 0, 3, 1308.77, -1366.8, 13.504, -174.689, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 'None', 1, -1, 0, 23, -256),
(447, 0, NULL, 'Los Santos Transport Files', 1318, 0, 3, 2487.39, -1526.46, 24.166, 86.169, 692.438, -825.518, 1501.09, 182.147, 5, 8, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, 0, 55, -256),
(448, 0, NULL, 'Los Santos News', 1239, 0, 3, 648.92, -1352.33, 13.553, -89.821, 2848.78, 1080.6, 1052.57, 89.216, 2, 1, 0, 0, 0, 0, 0, 0, 1, 'None', 1, -1, 0, -1, -256),
(449, 0, NULL, 'Front Yard Ballas', 1313, 0, 3, 2233.12, -1160.01, 25.891, 89.69, 2324.39, -1148.88, 1050.71, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, 0, -256),
(450, 0, NULL, 'Los Santos Bikers', 1313, 0, 3, 1933.94, -2073.82, 13.55, 91.531, 446.987, 1397.18, 1084.31, 342.959, 2, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(454, 0, NULL, 'MAFIA', 1313, 0, 3, -2281.95, 2288.44, 4.98, -75.179, 1298.87, -796.205, 1084.01, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(470, 0, NULL, 'Red Zone Bloods', 1313, 0, 3, 1767.84, -2112.83, 13.383, 88.843, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 3, -1, -256),
(471, 0, NULL, 'Los Santos Bloods', 1313, 0, 3, 1804.4, -2136.38, 13.547, 178.6, 2218.4, -1076.14, 1050.48, 265.69, 1, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(475, 0, NULL, 'LOS SANTOS HOSPITAL', 1239, 0, 3, 1172.08, -1323.21, 15.401, 92.352, -2330.16, 111.331, -5.394, 257.878, 1, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(482, 0, NULL, 'GARAGE', 1239, 0, 3, 2420.59, 2475.25, 1569.48, 109.723, 1568.53, -1690.44, 5.891, 201.785, 0, 0, 1, 1, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(487, 0, NULL, 'Red Zone Blancos', 1313, 0, 3, 962.438, -1447.74, 13.432, 88.82, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 3, -1, -256),
(488, 0, NULL, 'BLANCOSBlancos house', 1313, 0, 3, 1004.16, -1430.89, 13.547, 171.255, 226.585, 1239.96, 1082.14, 85.52, 2, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 0, -1, 0, -1, -256),
(492, 0, NULL, 'EXIT', 1239, 0, 3, -2329.65, 111.403, -5.394, -104.371, 1143.97, -1327.54, 13.594, 80.93, 0, 0, 1, 1, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(507, 0, NULL, 'GROVE STREET ', 1313, 0, 3, 2461.44, -1658.94, 13.305, 253.643, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 3, -1, -256),
(509, 0, NULL, 'LOS SANTOS BIKERS', 1313, 0, 3, 1953.22, -2082.77, 13.547, 102.308, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 3, -1, -256),
(515, 0, NULL, 'LOS SANTOS BALLAS', 1313, 0, 3, 2222.35, -1142.76, 25.797, 155.896, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, 2, 3, -1, -256),
(516, 1, 'psiko_boukhris', 'PSIKO', 1239, 0, 3, 1495.69, 2027, 14.74, -78.349, 244.902, 304.883, 999.148, 240.193, 1, 0, 0, 0, 7, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(517, 7, 'Vini_Edrian', 'vini', 1239, 0, 3, 1503.23, 2026.83, 14.74, 95.414, 2259.76, -1135.88, 1050.63, 270, 10, 0, 0, 0, 7, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(520, 0, NULL, 'VAGOS', 1313, 0, 3, 2770.67, -1628.34, 12.172, 185.932, 2317.87, -1026.6, 1050.21, 191.614, 9, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(521, 0, NULL, 'LOS VAGOS', 1313, 0, 3, 2799.1, -1589.94, 10.931, 169.038, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(522, 0, NULL, 'LOS SANTOS BANK', 1239, 0, 3, 593.568, -1250.96, 18.252, 1.076, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 0, -1, 0, 34, -256),
(528, 0, NULL, 'LOS SANTOS CRIPS ', 1313, 0, 3, 2185.49, -1781.97, 13.364, 179.218, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 3, -1, -256),
(529, 0, NULL, 'CRIPS HOUSE', 1313, 0, 3, 2141.39, -1802.03, 16.141, 240.308, -260.485, 1456.87, 1084.37, 351.764, 4, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256),
(530, 0, NULL, 'city hall ', 1239, 0, 3, 1480.77, -1771.55, 18.789, -11.802, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'None', 1, -1, 0, -1, -256);

-- --------------------------------------------------------

--
-- Structure de la table `factionlockers`
--

CREATE TABLE `factionlockers` (
  `id` int(11) NOT NULL,
  `factionid` int(2) NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `interior` int(11) NOT NULL,
  `world` int(11) NOT NULL,
  `iconid` int(11) NOT NULL DEFAULT '1239',
  `label` int(11) NOT NULL DEFAULT '1',
  `weapon_kevlar` int(1) NOT NULL DEFAULT '1',
  `weapon_medkit` int(1) NOT NULL DEFAULT '1',
  `weapon_nitestick` int(1) NOT NULL DEFAULT '0',
  `weapon_mace` int(1) NOT NULL DEFAULT '0',
  `weapon_deagle` int(1) NOT NULL DEFAULT '1',
  `weapon_shotgun` int(1) NOT NULL DEFAULT '1',
  `weapon_mp5` int(1) NOT NULL DEFAULT '1',
  `weapon_m4` int(1) NOT NULL DEFAULT '1',
  `weapon_spas12` int(1) NOT NULL DEFAULT '1',
  `weapon_sniper` int(1) NOT NULL DEFAULT '1',
  `weapon_camera` int(1) NOT NULL DEFAULT '0',
  `weapon_fire_extinguisher` int(1) NOT NULL DEFAULT '0',
  `weapon_painkillers` int(1) NOT NULL DEFAULT '0',
  `price_kevlar` int(10) NOT NULL DEFAULT '100',
  `price_medkit` int(10) NOT NULL DEFAULT '50',
  `price_nitestick` int(10) NOT NULL DEFAULT '0',
  `price_mace` int(10) NOT NULL DEFAULT '0',
  `price_deagle` int(10) NOT NULL DEFAULT '850',
  `price_shotgun` int(10) NOT NULL DEFAULT '1000',
  `price_mp5` int(10) NOT NULL DEFAULT '1500',
  `price_m4` int(10) NOT NULL DEFAULT '2500',
  `price_spas12` int(10) NOT NULL DEFAULT '3500',
  `price_sniper` int(10) NOT NULL DEFAULT '5000',
  `price_camera` int(10) NOT NULL DEFAULT '0',
  `price_fire_extinguisher` int(10) NOT NULL DEFAULT '0',
  `price_painkillers` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `factionlockers`
--

INSERT INTO `factionlockers` (`id`, `factionid`, `pos_x`, `pos_y`, `pos_z`, `interior`, `world`, `iconid`, `label`, `weapon_kevlar`, `weapon_medkit`, `weapon_nitestick`, `weapon_mace`, `weapon_deagle`, `weapon_shotgun`, `weapon_mp5`, `weapon_m4`, `weapon_spas12`, `weapon_sniper`, `weapon_camera`, `weapon_fire_extinguisher`, `weapon_painkillers`, `price_kevlar`, `price_medkit`, `price_nitestick`, `price_mace`, `price_deagle`, `price_shotgun`, `price_mp5`, `price_m4`, `price_spas12`, `price_sniper`, `price_camera`, `price_fire_extinguisher`, `price_painkillers`) VALUES
(97, 0, 1468.35, -1790.55, 2342.15, 0, 0, 1242, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(98, 5, -2461.99, 522.656, 3002.17, 0, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(100, 3, 1803.57, -1110.65, 24.086, 0, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(106, 2, 2831.73, 1089.28, 1052.57, 2, 1, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(114, 2, 750.838, -1358.35, 13.5, 0, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(115, 0, 2395.36, 2479.25, 1569.48, 1, 1, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(116, 1, -2287.78, 88.808, -5.304, 1, 1, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(117, 0, 2395.26, 2480.65, 1569.48, 1, 1, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(119, 4, 248.817, 303.871, 999.148, 1, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(120, 6, 248.818, 303.888, 999.148, 1, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(121, 2, 2260.39, -1139.24, 1050.63, 10, 0, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0),
(122, 0, 2396.64, 2475.64, 1569.48, 1, 1, 1239, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 100, 50, 0, 0, 850, 1000, 1500, 2500, 3500, 5000, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `factionpay`
--

CREATE TABLE `factionpay` (
  `id` tinyint(2) DEFAULT NULL,
  `rank` tinyint(2) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `factionpay`
--

INSERT INTO `factionpay` (`id`, `rank`, `amount`) VALUES
(0, 17, 70000),
(0, 16, 65000),
(0, 15, 60000),
(0, 14, 20000),
(0, 13, 16500),
(0, 12, 15000),
(0, 11, 40000),
(0, 10, 35000),
(0, 9, 30000),
(0, 8, 26500),
(0, 7, 24500),
(0, 6, 20500),
(0, 5, 18500),
(0, 4, 15000),
(0, 3, 15000),
(0, 2, 15000),
(0, 1, 13000),
(0, 0, 10000),
(1, 5, 50000),
(1, 2, 20000),
(1, 4, 40000),
(1, 3, 30000),
(1, 1, 10000),
(1, 0, 5000),
(4, 5, 100000);

-- --------------------------------------------------------

--
-- Structure de la table `factionranks`
--

CREATE TABLE `factionranks` (
  `id` tinyint(2) DEFAULT NULL,
  `rank` tinyint(2) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `factionranks`
--

INSERT INTO `factionranks` (`id`, `rank`, `name`) VALUES
(1, 0, 'STAGER'),
(1, 1, 'head medic'),
(1, 2, 'unspecified'),
(1, 3, 'special medic'),
(1, 4, 'co chef medic'),
(1, 5, 'chef medic'),
(0, 0, 'TRAINEE'),
(0, 1, 'OFFICER 1'),
(0, 2, 'OFFICER 2'),
(0, 3, 'OFFICER 3'),
(0, 4, 'MAJOR OFFICER'),
(0, 5, 'SERGEANT'),
(0, 6, 'SERGEANT 2'),
(0, 7, 'LEAD SERGEANT'),
(0, 8, 'DETECTIVE'),
(0, 9, 'CAPTAIN'),
(0, 10, 'CAPTAIN 2'),
(0, 11, 'COMMANDER'),
(0, 12, 'BIKER 1'),
(0, 13, 'BIKER 2'),
(0, 14, 'LEAD BIKER'),
(0, 15, 'TRAINEE CHIEF'),
(0, 16, 'ASSISTANT CHIEF'),
(0, 17, 'CHIEF'),
(4, 5, 'BIG CHEF'),
(4, 4, 'CAISE MAN'),
(4, 3, 'FISHER MAN'),
(4, 2, 'SERBAY'),
(4, 1, 'KAYGHL MWA3N');

-- --------------------------------------------------------

--
-- Structure de la table `factions`
--

CREATE TABLE `factions` (
  `id` tinyint(2) DEFAULT NULL,
  `name` varchar(48) DEFAULT NULL,
  `shortname` tinytext,
  `leader` varchar(24) DEFAULT 'No-one',
  `motd` varchar(64) DEFAULT 'None',
  `budget` tinyint(2) DEFAULT '0',
  `type` tinyint(2) DEFAULT '0',
  `color` int(10) DEFAULT '-1',
  `rankcount` tinyint(2) DEFAULT '6',
  `lockerx` float DEFAULT '0',
  `lockery` float DEFAULT '0',
  `lockerz` float DEFAULT '0',
  `lockerinterior` tinyint(2) DEFAULT '0',
  `lockerworld` int(10) DEFAULT '0',
  `turftokens` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `factions`
--

INSERT INTO `factions` (`id`, `name`, `shortname`, `leader`, `motd`, `budget`, `type`, `color`, `rankcount`, `lockerx`, `lockery`, `lockerz`, `lockerinterior`, `lockerworld`, `turftokens`) VALUES
(0, 'Police Los Santos', NULL, 'No-one', 'None', 0, 1, 324636672, 18, 0, 0, 0, 0, 0, 3),
(1, 'Medical Los Santos', NULL, 'No-one', 'None', 0, 2, -595860992, 6, 0, 0, 0, 0, 0, 0),
(2, 'News Los Santos', NULL, 'No-one', 'None', 0, 3, 143292928, 6, 0, 0, 0, 0, 0, 0),
(3, 'Mechanic Los Santos', NULL, 'Microb_Zeussex', 'None', 0, 9, 301807616, 6, 0, 0, 0, 0, 0, 0),
(4, 'Burger Shot Los Santos', NULL, 'No-one', 'None', 0, 10, -40955648, 6, 0, 0, 0, 0, 0, 0),
(5, 'Federal Fbi Los Santos', NULL, 'No-one', 'None', 0, 6, 18176, 6, 0, 0, 0, 0, 0, 3),
(6, 'MKHZN', NULL, 'No-one', 'None', 0, 1, 8598272, 13, 0, 0, 0, 0, 0, 3);

-- --------------------------------------------------------

--
-- Structure de la table `factionskins`
--

CREATE TABLE `factionskins` (
  `id` tinyint(2) DEFAULT NULL,
  `slot` tinyint(2) DEFAULT NULL,
  `skinid` smallint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `factionskins`
--

INSERT INTO `factionskins` (`id`, `slot`, `skinid`) VALUES
(0, 0, 71),
(0, 1, 281),
(0, 2, 265),
(0, 3, 266),
(0, 4, 267),
(0, 5, 284),
(0, 6, 285),
(0, 7, 286),
(0, 8, 303),
(0, 9, 304),
(1, 0, 70),
(1, 1, 308),
(1, 2, 274),
(1, 3, 276),
(1, 4, 275);

-- --------------------------------------------------------

--
-- Structure de la table `flags`
--

CREATE TABLE `flags` (
  `id` int(10) NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `flaggedby` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `flags`
--

INSERT INTO `flags` (`id`, `uid`, `flaggedby`, `date`, `description`) VALUES
(1, 63, 'psiko_boukhris', '2023-03-16 03:31:05', '1'),
(2, 13, 'psiko_boukhris', '2023-03-16 03:32:13', '1'),
(3, 13, 'psiko_boukhris', '2023-03-16 03:33:18', '12'),
(4, 13, 'psiko_boukhris', '2023-03-16 03:36:49', '5');

-- --------------------------------------------------------

--
-- Structure de la table `gangranks`
--

CREATE TABLE `gangranks` (
  `id` tinyint(2) DEFAULT NULL,
  `rank` tinyint(2) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `gangranks`
--

INSERT INTO `gangranks` (`id`, `rank`, `name`) VALUES
(5, 4, 'CO UNDER OG BLOODS'),
(5, 6, 'OG BLOODS'),
(8, 6, 'BOSS'),
(8, 5, 'CO BOSS'),
(1, 0, 'DABDOB TRABYA'),
(1, 1, 'DABDOB SGHIR '),
(1, 2, 'DABDOB MORAHI9'),
(1, 3, 'DABDOB BASL'),
(1, 4, 'DABDOB KHATER'),
(1, 5, 'CO DOB'),
(1, 6, 'BABA DOB'),
(5, 0, 'TEST'),
(5, 1, 'NADY BLOODS'),
(5, 2, 'M9WED BLOODS'),
(5, 3, 'CO UNDER BLOODS'),
(5, 5, 'UNDER OG BLOODS');

-- --------------------------------------------------------

--
-- Structure de la table `gangs`
--

CREATE TABLE `gangs` (
  `id` tinyint(2) DEFAULT NULL,
  `name` varchar(32) DEFAULT 'None',
  `motd` varchar(128) DEFAULT 'None',
  `leader` varchar(24) DEFAULT 'No-one',
  `color` int(10) DEFAULT '-256',
  `strikes` tinyint(1) DEFAULT '0',
  `level` tinyint(2) DEFAULT '1',
  `points` int(10) DEFAULT '0',
  `turftokens` int(10) DEFAULT '0',
  `stash_x` float DEFAULT '0',
  `stash_y` float DEFAULT '0',
  `stash_z` float DEFAULT '0',
  `stashinterior` tinyint(2) DEFAULT '0',
  `stashworld` int(10) DEFAULT '0',
  `cash` int(10) DEFAULT '0',
  `materials` int(10) DEFAULT '0',
  `pot` int(10) DEFAULT '0',
  `crack` int(10) DEFAULT '0',
  `meth` int(10) DEFAULT '0',
  `painkillers` int(10) DEFAULT '0',
  `pistolammo` int(10) DEFAULT '0',
  `shotgunammo` int(10) DEFAULT '0',
  `smgammo` int(10) DEFAULT '0',
  `arammo` int(10) DEFAULT '0',
  `rifleammo` int(10) DEFAULT '0',
  `hpammo` int(10) DEFAULT '0',
  `poisonammo` int(10) DEFAULT '0',
  `fmjammo` int(10) DEFAULT '0',
  `weapon_9mm` int(10) DEFAULT '0',
  `weapon_sdpistol` int(10) DEFAULT '0',
  `weapon_deagle` int(10) DEFAULT '0',
  `weapon_shotgun` int(10) DEFAULT '0',
  `weapon_spas12` int(10) DEFAULT '0',
  `weapon_sawnoff` int(10) DEFAULT '0',
  `weapon_tec9` int(10) DEFAULT '0',
  `weapon_uzi` int(10) DEFAULT '0',
  `weapon_mp5` int(10) DEFAULT '0',
  `weapon_ak47` int(10) DEFAULT '0',
  `weapon_m4` int(10) DEFAULT '0',
  `weapon_rifle` int(10) DEFAULT '0',
  `weapon_sniper` int(10) DEFAULT '0',
  `weapon_molotov` int(10) DEFAULT '0',
  `armsdealer` tinyint(1) DEFAULT '0',
  `drugdealer` tinyint(1) DEFAULT '0',
  `arms_x` float DEFAULT '0',
  `arms_y` float DEFAULT '0',
  `arms_z` float DEFAULT '0',
  `arms_a` float DEFAULT '0',
  `drug_x` float DEFAULT '0',
  `drug_y` float DEFAULT '0',
  `drug_z` float DEFAULT '0',
  `drug_a` float DEFAULT '0',
  `armsworld` int(10) DEFAULT '0',
  `drugworld` int(10) DEFAULT '0',
  `drugpot` int(10) DEFAULT '0',
  `drugcrack` int(10) DEFAULT '0',
  `drugmeth` int(10) DEFAULT '0',
  `armsmaterials` int(10) DEFAULT '0',
  `armsprice_1` int(10) DEFAULT '0',
  `armsprice_2` int(10) DEFAULT '0',
  `armsprice_3` int(10) DEFAULT '0',
  `armsprice_4` int(10) DEFAULT '0',
  `armsprice_5` int(10) DEFAULT '0',
  `armsprice_6` int(10) DEFAULT '0',
  `armsprice_7` int(10) DEFAULT '0',
  `armsprice_8` int(10) DEFAULT '0',
  `armsprice_9` int(10) NOT NULL DEFAULT '0',
  `armsprice_10` int(10) NOT NULL DEFAULT '0',
  `armsprice_11` int(10) NOT NULL DEFAULT '0',
  `armsprice_12` tinyint(2) NOT NULL DEFAULT '0',
  `pot_price` int(10) DEFAULT '0',
  `crack_price` int(10) DEFAULT '0',
  `meth_price` int(10) DEFAULT '0',
  `armshpammo` int(10) DEFAULT '0',
  `armspoisonammo` int(10) DEFAULT '0',
  `armsfmjammo` int(10) DEFAULT '0',
  `alliance` int(10) NOT NULL DEFAULT '-1',
  `matlevel` int(10) DEFAULT '0',
  `gunlevel` int(10) DEFAULT '0',
  `rank_9mm` int(10) DEFAULT '0',
  `rank_sdpistol` int(10) DEFAULT '0',
  `rank_deagle` int(10) DEFAULT '0',
  `rank_shotgun` int(10) DEFAULT '0',
  `rank_tec9` int(10) DEFAULT '0',
  `rank_uzi` int(10) DEFAULT '0',
  `rank_mp5` int(10) DEFAULT '0',
  `rank_ak47` int(10) DEFAULT '0',
  `rank_rifle` int(10) DEFAULT '0',
  `rank_vest` int(10) DEFAULT '0',
  `drugweed` int(10) DEFAULT '0',
  `drugcocaine` int(10) DEFAULT '0',
  `weed_price` int(10) DEFAULT '0',
  `weed` int(10) DEFAULT '0',
  `cocaine_price` int(10) DEFAULT '0',
  `cocaine` int(10) DEFAULT '0',
  `weapon_bat` int(10) DEFAULT '0',
  `rank_bat` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `gangs`
--

INSERT INTO `gangs` (`id`, `name`, `motd`, `leader`, `color`, `strikes`, `level`, `points`, `turftokens`, `stash_x`, `stash_y`, `stash_z`, `stashinterior`, `stashworld`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `weapon_9mm`, `weapon_sdpistol`, `weapon_deagle`, `weapon_shotgun`, `weapon_spas12`, `weapon_sawnoff`, `weapon_tec9`, `weapon_uzi`, `weapon_mp5`, `weapon_ak47`, `weapon_m4`, `weapon_rifle`, `weapon_sniper`, `weapon_molotov`, `armsdealer`, `drugdealer`, `arms_x`, `arms_y`, `arms_z`, `arms_a`, `drug_x`, `drug_y`, `drug_z`, `drug_a`, `armsworld`, `drugworld`, `drugpot`, `drugcrack`, `drugmeth`, `armsmaterials`, `armsprice_1`, `armsprice_2`, `armsprice_3`, `armsprice_4`, `armsprice_5`, `armsprice_6`, `armsprice_7`, `armsprice_8`, `armsprice_9`, `armsprice_10`, `armsprice_11`, `armsprice_12`, `pot_price`, `crack_price`, `meth_price`, `armshpammo`, `armspoisonammo`, `armsfmjammo`, `alliance`, `matlevel`, `gunlevel`, `rank_9mm`, `rank_sdpistol`, `rank_deagle`, `rank_shotgun`, `rank_tec9`, `rank_uzi`, `rank_mp5`, `rank_ak47`, `rank_rifle`, `rank_vest`, `drugweed`, `drugcocaine`, `weed_price`, `weed`, `cocaine_price`, `cocaine`, `weapon_bat`, `rank_bat`) VALUES
(0, 'Grove Stret Families', 'None', 'No-one', 394013696, 0, 1, 45, 10, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1, 'Los Santos Vagos', 'None', 'PEDRO ', -136505600, 0, 1, 138, 10, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 'Front Yard Ballas', 'None', 'No-one', 1980821248, 0, 1, 220, 10, 1916.31, 1423.52, 72.606, 0, 0, 87000, 600, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 'Los Santos crips', 'None', 'No-one', 13434624, 0, 1, 35, 10, 1919.86, 1423.25, 72.606, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0),
(4, 'Los Santos Bikers', 'None', 'No-one', 1714618368, 0, 1, 2, 10, 438.563, 1406.83, 1084.31, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 'Los Santos Bloods', 'None', 'No-one', -872415232, 0, 1, 16, 10, 2205.03, -1071.41, 1050.48, 1, 0, 0, 750, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 'X ', 'None', 'No-one', 0, 0, 1, 3, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 'MAFIA', '-1', 'No-one', 0, 0, 1, 76, 10, 1303.7, -789.886, 1084.01, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 'BLANCOS', 'None', 'No-one', -256, 0, 1, 12, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `gangskins`
--

CREATE TABLE `gangskins` (
  `id` tinyint(2) DEFAULT NULL,
  `slot` tinyint(2) DEFAULT NULL,
  `skinid` smallint(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `gangskins`
--

INSERT INTO `gangskins` (`id`, `slot`, `skinid`) VALUES
(5, 0, 19),
(5, 1, 180),
(5, 2, 190),
(5, 3, 97),
(5, 4, 217);

-- --------------------------------------------------------

--
-- Structure de la table `garages`
--

CREATE TABLE `garages` (
  `id` int(10) NOT NULL,
  `ownerid` int(10) DEFAULT '0',
  `owner` varchar(24) DEFAULT NULL,
  `type` tinyint(1) DEFAULT '0',
  `price` int(10) DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `timestamp` int(10) DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `exit_x` float DEFAULT '0',
  `exit_y` float DEFAULT '0',
  `exit_z` float DEFAULT '0',
  `exit_a` float DEFAULT '0',
  `world` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `garages`
--

INSERT INTO `garages` (`id`, `ownerid`, `owner`, `type`, `price`, `locked`, `timestamp`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `exit_x`, `exit_y`, `exit_z`, `exit_a`, `world`) VALUES
(4, 1, 'psiko_boukhris', 2, 350000, 0, 1679358954, 1254.67, -800.886, 84.141, 349.623, 1254.13, -803.837, 84.141, 169.623, 2000004),
(5, 1, 'psiko_boukhris', 2, 350000, 1, 1679358782, 1249.01, -800.886, 84.141, 13.061, 1249.68, -803.808, 84.141, -166.939, 2000005),
(6, 1, 'psiko_boukhris', 2, 350000, 1, 1679358746, 1242.98, -800.898, 84.141, 14.134, 1243.71, -803.807, 84.141, -165.866, 2000006),
(9, 1, 'psiko_boukhris', 0, 125000, 1, 1679358754, 1355.1, -629.401, 109.133, 22.548, 1356.25, -632.172, 109.133, -157.452, 2000009),
(10, 0, NULL, 2, 350000, 0, 0, 1298.59, -798.399, 84.141, 5.714, 1298.89, -801.384, 84.141, -174.286, 2000010);

-- --------------------------------------------------------

--
-- Structure de la table `gates`
--

CREATE TABLE `gates` (
  `gateID` int(12) NOT NULL,
  `gateModel` int(12) DEFAULT '980',
  `gateSpeed` float DEFAULT '0',
  `gateTime` int(12) DEFAULT '0',
  `gateX` float DEFAULT '0',
  `gateY` float DEFAULT '0',
  `gateZ` float DEFAULT '0',
  `gateRX` float DEFAULT '0',
  `gateRY` float DEFAULT '0',
  `gateRZ` float DEFAULT '0',
  `gateInterior` int(12) DEFAULT '0',
  `gateWorld` int(12) DEFAULT '0',
  `gateMoveX` float DEFAULT '0',
  `gateMoveY` float DEFAULT '0',
  `gateMoveZ` float DEFAULT '0',
  `gateMoveRX` float DEFAULT '0',
  `gateMoveRY` float DEFAULT '0',
  `gateMoveRZ` float DEFAULT '0',
  `gateLinkID` int(12) DEFAULT '0',
  `gateFaction` int(12) DEFAULT '0',
  `gatePass` varchar(32) DEFAULT NULL,
  `gateRadius` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `gates`
--

INSERT INTO `gates` (`gateID`, `gateModel`, `gateSpeed`, `gateTime`, `gateX`, `gateY`, `gateZ`, `gateRX`, `gateRY`, `gateRZ`, `gateInterior`, `gateWorld`, `gateMoveX`, `gateMoveY`, `gateMoveZ`, `gateMoveRX`, `gateMoveRY`, `gateMoveRZ`, `gateLinkID`, `gateFaction`, `gatePass`, `gateRadius`) VALUES
(119, 19913, 3, 0, 2480.77, -1708.54, 13.5344, 0, 0, 0, 0, 0, 2478.73, -1706.56, 5.464, -1000, -1000, -1000, -1, -1, 'grv', 5),
(120, 19913, 3, 0, 2525.53, -1707.69, 13.3796, 0, 0, 182.519, 0, 0, 2522.89, -1708.34, 3.3908, -1000, -1000, -1000, -1, -1, 'grv', 5),
(122, 19913, 3, 0, 964.906, -1448.94, 13.4447, 0, 0, 90.221, 0, 0, 965.368, -1446.94, 3.4652, -1000, -1000, -1000, -1, -1, '999', 5),
(131, 980, 3, 0, 1033.78, -1459.91, 15.3268, 0, 0, 267.449, 0, 0, 1033.82, -1459.76, 3.5638, -1000, -1000, -1000, -1, -1, '999', 5),
(144, 19913, 3, 0, -315.054, -1340.21, 8.6785, 0, 0, 92.6271, 0, 0, -315.054, -1340.21, -1.3214, -1000, -1000, -1000, -1, -1, 'jajakaka', 5),
(145, 980, 3, 0, -320.883, -1366.34, 10.2852, 0, 0, 1.367, 0, 0, -320.883, -1366.34, 0.2852, -1000, -1000, -1000, -1, -1, '7#)#(', 5),
(146, 19913, 3, 0, -328.316, -1346, 11.5718, 0, 0, 270.432, 0, 0, -328.316, -1346, 1.5718, -1000, -1000, -1000, -1, -1, 'kkkkjs', 5),
(147, 980, 3, 0, -323.89, -1317.84, 9.4978, 0, 0, 180.501, 0, 0, -323.89, -1317.84, -0.5021, -1000, -1000, -1000, -1, -1, '991818', 5),
(148, 980, 3, 0, -327.578, -1318.99, 11.094, 0, 0, 280.918, 0, 0, -327.578, -1318.99, 1.094, -1000, -1000, -1000, -1, -1, '10982', 5),
(152, 19913, 3, 0, 2463.77, -1665.78, 13.4754, 0, 0, 274.656, 0, 0, 2464.9, -1661.89, 3.3046, -1000, -1000, -1000, -1, -1, 'grv', 10),
(153, 19913, 3, 0, -372.217, -1359.09, 22.5516, 0, 0, 256.525, 0, 0, -372.217, -1359.09, 12.5516, -1000, -1000, -1000, -1, -1, '199', 5),
(154, 980, 3, 0, -365.233, -1337.74, 22.4307, 0, 0, 164.618, 0, 0, -365.233, -1337.74, 12.4307, -1000, -1000, -1000, -1, -1, '199', 5),
(155, 19913, 3, 0, -362.53, -1360.77, 19.2351, 0, 0, 83.9002, 0, 0, -361.285, -1340.39, 10.665, -1000, -1000, -1000, -1, -1, '199', 5),
(156, 980, 3, 0, -369.498, -1381.61, 22.0865, 0, 0, 356.771, 0, 0, -369.498, -1381.61, 12.0865, -1000, -1000, -1000, -1, -1, '199', 5),
(157, 980, 3, 0, -373.651, -1380.62, 22.7227, 0, 0, 13.4914, 0, 0, -373.651, -1380.62, 12.7227, -1000, -1000, -1000, -1, -1, '199', 5),
(158, 19913, 3, 0, -366.259, -1409.06, 25.0499, 0, 0, 200.894, 0, 0, -366.342, -1411.92, 15.7265, -1000, -1000, -1000, -1, -1, '188', 5),
(159, 19913, 3, 0, -359.661, -1417.38, 24.7547, 0, 0, 91.1559, 0, 0, -360.794, -1417.03, 15.5254, -1000, -1000, -1000, -1, -1, '199', 5),
(160, 19913, 3, 0, -371.574, -1439.14, 25.7265, 0, 0, 352.07, 0, 0, -371.574, -1439.14, 15.7265, -1000, -1000, -1000, -1, -1, '199', 5),
(161, 19913, 3, 0, -389.878, -1417.96, 25.7265, 0, 0, 279.245, 0, 0, -389.878, -1417.96, 15.7265, -1000, -1000, -1000, -1, -1, '199', 5),
(164, 19913, 3, 0, -395.595, -1439.97, 29.399, 0, 0, 166.951, 0, 0, -395.595, -1439.97, 19.399, -1000, -1000, -1000, -1, -1, '199', 5),
(165, 980, 3, 0, -403.806, -1435.72, 29.6599, 0, 0, 82.4109, 0, 0, -403.806, -1435.72, 19.6599, -1000, -1000, -1000, -1, -1, '199', 5),
(166, 980, 3, 0, -403.115, -1435.36, 25.7265, 0, 0, 272.534, 0, 0, -403.115, -1435.36, 15.7265, -1000, -1000, -1000, -1, -1, '199', 5),
(176, 971, 3, 0, 2758.34, -1596.5, 13.6048, 0, 0, 83.4736, 0, 0, 2758.34, -1596.5, 3.6048, -1000, -1000, -1000, -1, -1, 'LSVGSPV', 5),
(182, 19913, 3, 0, 2795.54, -1596.19, 10.9289, 0, 0, 351.996, 0, 0, 2795.54, -1596.19, 0.9289, -1000, -1000, -1000, -1, -1, 'LSVGSPV', 5),
(184, 19913, 3, 0, 2170.05, -1783.4, 13.5134, 0, 0, 357.65, 0, 0, 2173.1, -1783.57, 3.5141, -1000, -1000, -1000, -1, -1, 'MBN', 17),
(185, 980, 3, 0, 2461.47, -1635.02, 14.7435, 0, 0, 271.832, 0, 0, 2461.94, -1635.61, 3.4043, -1000, -1000, -1000, -1, -1, 'grv', 5),
(186, 19913, 3, 0, 1766.16, -2113.05, 13.3828, 0, 0, 271.806, 0, 0, 1766.16, -2113.05, 3.3828, -1000, -1000, -1000, -1, -1, '', 5);

-- --------------------------------------------------------

--
-- Structure de la table `graffiti`
--

CREATE TABLE `graffiti` (
  `graffitiID` int(12) DEFAULT NULL,
  `graffitiX` float DEFAULT '0',
  `graffitiY` float DEFAULT '0',
  `graffitiZ` float DEFAULT '0',
  `graffitiAngle` float DEFAULT '0',
  `graffitiColor` int(12) DEFAULT '0',
  `graffitiText` varchar(64) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Contenu de la table `graffiti`
--

INSERT INTO `graffiti` (`graffitiID`, `graffitiX`, `graffitiY`, `graffitiZ`, `graffitiAngle`, `graffitiColor`, `graffitiText`) VALUES
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL),
(NULL, 0, 0, 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `gunracks`
--

CREATE TABLE `gunracks` (
  `rackID` int(12) NOT NULL,
  `rackHouse` int(12) DEFAULT '0',
  `rackX` float DEFAULT '0',
  `rackY` float DEFAULT '0',
  `rackZ` float DEFAULT '0',
  `rackA` float DEFAULT '0',
  `rackInterior` int(12) DEFAULT '0',
  `rackWorld` int(12) DEFAULT '0',
  `rackWeapon1` int(12) DEFAULT '0',
  `rackAmmo1` int(12) DEFAULT '0',
  `rackWeapon2` int(12) DEFAULT '0',
  `rackAmmo2` int(12) DEFAULT '0',
  `rackWeapon3` int(12) DEFAULT '0',
  `rackAmmo3` int(12) DEFAULT '0',
  `rackWeapon4` int(12) DEFAULT '0',
  `rackAmmo4` int(12) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `houses`
--

CREATE TABLE `houses` (
  `id` int(10) NOT NULL,
  `ownerid` int(10) DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `type` tinyint(2) DEFAULT '0',
  `price` int(10) DEFAULT '0',
  `rentprice` int(10) DEFAULT '0',
  `level` tinyint(2) DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `timestamp` int(10) DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `int_x` float DEFAULT '0',
  `int_y` float DEFAULT '0',
  `int_z` float DEFAULT '0',
  `int_a` float DEFAULT '0',
  `interior` tinyint(2) DEFAULT '0',
  `world` int(10) DEFAULT '0',
  `outsideint` int(10) DEFAULT '0',
  `outsidevw` int(10) DEFAULT '0',
  `cash` int(10) DEFAULT '0',
  `materials` int(10) DEFAULT '0',
  `pot` int(10) DEFAULT '0',
  `crack` int(10) DEFAULT '0',
  `weed` int(10) DEFAULT '0',
  `cocaine` int(10) DEFAULT '0',
  `delivery` int(10) DEFAULT '0',
  `lights` int(10) DEFAULT '0',
  `meth` int(10) DEFAULT '0',
  `painkillers` int(10) DEFAULT '0',
  `weapon_1` tinyint(2) DEFAULT '0',
  `weapon_2` tinyint(2) DEFAULT '0',
  `weapon_3` tinyint(2) DEFAULT '0',
  `weapon_4` tinyint(2) DEFAULT '0',
  `weapon_5` tinyint(2) DEFAULT '0',
  `weapon_6` tinyint(2) DEFAULT '0',
  `weapon_7` tinyint(2) DEFAULT '0',
  `weapon_8` tinyint(2) DEFAULT '0',
  `weapon_9` tinyint(2) DEFAULT '0',
  `weapon_10` tinyint(2) DEFAULT '0',
  `ammo_1` smallint(5) DEFAULT '0',
  `ammo_2` smallint(5) DEFAULT '0',
  `ammo_3` smallint(5) DEFAULT '0',
  `ammo_4` smallint(5) DEFAULT '0',
  `ammo_5` smallint(5) DEFAULT '0',
  `ammo_6` tinyint(2) DEFAULT '0',
  `ammo_7` tinyint(2) DEFAULT '0',
  `ammo_8` tinyint(2) DEFAULT '0',
  `ammo_9` tinyint(2) DEFAULT '0',
  `ammo_10` tinyint(2) DEFAULT '0',
  `pistolammo` smallint(5) DEFAULT '0',
  `shotgunammo` smallint(5) DEFAULT '0',
  `smgammo` smallint(5) DEFAULT '0',
  `arammo` smallint(5) DEFAULT '0',
  `rifleammo` smallint(5) DEFAULT '0',
  `hpammo` smallint(5) DEFAULT '0',
  `poisonammo` smallint(5) DEFAULT '0',
  `fmjammo` smallint(5) DEFAULT '0',
  `robbed` smallint(6) NOT NULL DEFAULT '3',
  `robbing` smallint(6) NOT NULL DEFAULT '3'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `impoundlots`
--

CREATE TABLE `impoundlots` (
  `impoundID` int(12) NOT NULL,
  `impoundLotX` float DEFAULT '0',
  `impoundLotY` float DEFAULT '0',
  `impoundLotZ` float DEFAULT '0',
  `impoundReleaseX` float DEFAULT '0',
  `impoundReleaseY` float DEFAULT '0',
  `impoundReleaseZ` float DEFAULT '0',
  `impoundReleaseA` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `kills`
--

CREATE TABLE `kills` (
  `id` int(10) NOT NULL,
  `killer_uid` int(10) DEFAULT NULL,
  `target_uid` int(10) DEFAULT NULL,
  `killer` varchar(24) DEFAULT NULL,
  `target` varchar(24) DEFAULT NULL,
  `reason` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `kills`
--

INSERT INTO `kills` (`id`, `killer_uid`, `target_uid`, `killer`, `target`, `reason`, `date`) VALUES
(3, 1243, 1256, 'Karam_Billionaire', 'Reda_Tazi', 'Desert Eagle', '2023-02-16 20:04:00'),
(4, 1243, 1256, 'Karam_Billionaire', 'Reda_Tazi', 'Desert Eagle', '2023-02-17 12:23:07'),
(5, 1265, 1270, 'Karam_Billionaire', 'Ahmed_Benani', 'Sniper Rifle', '2023-02-18 12:33:11'),
(6, 1265, 1269, 'Karam_Billionaire', 'flooqi_bby', 'Knife', '2023-02-18 12:35:08'),
(7, 1265, 1269, 'Karam_Billionaire', 'flooqi_bby', 'Knife', '2023-02-18 12:35:24'),
(8, 1265, 1270, 'Karam_Billionaire', 'Ahmed_Benani', 'Knife', '2023-02-18 12:35:52'),
(9, 1265, 1269, 'Karam_Billionaire', 'flooqi_bby', 'Knife', '2023-02-18 12:36:06'),
(10, 1269, 1265, 'flooqi_bby', 'Karam_Billionaire', 'Rifle', '2023-02-18 12:36:33'),
(11, 1269, 1265, 'flooqi_bby', 'Karam_Billionaire', 'Rifle', '2023-02-18 12:37:15'),
(12, 1265, 1269, 'Karam_Billionaire', 'flooqi_bby', 'Knife', '2023-02-18 12:37:26'),
(13, 1269, 1265, 'flooqi_bby', 'Karam_Billionaire', 'Rifle', '2023-02-18 12:38:07'),
(14, 1265, 1269, 'Michael_Zodiac', 'flooqi_bby', 'Knife', '2023-02-18 19:40:43'),
(15, 1265, 1269, 'Michael_Zodiac', 'flooqi_bby', 'Desert Eagle', '2023-02-18 19:41:40'),
(16, 1265, 1270, 'Michael_Zodiac', 'Ahmed_Benani', 'Desert Eagle', '2023-02-18 20:15:12'),
(17, 1290, 1283, 'Nicholas_Democritus', 'Philo_Democritus', 'Fists', '2023-02-20 12:24:29'),
(18, 1290, 1283, 'Nicholas_Democritus', 'Philo_Democritus', 'Fists', '2023-02-20 12:26:25'),
(19, 1297, 1271, 'LKHRAZ_ML', 'HAMOCHI_SIROM', 'Fists', '2023-02-21 02:02:34'),
(20, 1297, 1296, 'LKHRAZ_ML', 'maikey_gos', 'Vehicle', '2023-02-21 02:21:42'),
(21, 1296, 1271, 'maikey_gos', 'HAMOCHI_SIROM', 'Fists', '2023-02-22 01:36:09'),
(22, 1271, 1296, 'HAMOCHI_SIROM', 'maikey_gos', 'Helicopter Blades', '2023-02-22 01:55:16'),
(23, 2, 1, 'PEDRO_ADMIN', 'Alex_Cobra', 'Silenced Pistol', '2023-03-14 12:34:43'),
(24, 1, 5, 'Alex_Cobra', 'Reda_Tazi', 'Silenced Pistol', '2023-03-14 13:03:51'),
(25, 4, 2, 'Smoke_Jigo', 'PEDRO_ADMIN', 'Desert Eagle', '2023-03-14 13:06:44'),
(26, 2, 4, 'PEDRO_ADMIN', 'Smoke_Jigo', 'Fists', '2023-03-14 13:07:33'),
(27, 2, 6, 'PEDRO_ADMIN', 'Young_Houssam', 'Silenced Pistol', '2023-03-14 13:33:06'),
(28, 51, 2, 'Bar9al_Admin', 'PEDRO_ADMIN', 'Fists', '2023-03-14 15:58:24'),
(29, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Silenced Pistol', '2023-03-14 16:39:56'),
(30, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 16:40:42'),
(31, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 16:41:01'),
(32, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Silenced Pistol', '2023-03-14 16:41:58'),
(33, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Silenced Pistol', '2023-03-14 16:42:07'),
(34, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Silenced Pistol', '2023-03-14 16:42:29'),
(35, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 16:42:57'),
(36, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'AK47', '2023-03-14 16:43:19'),
(37, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Katana', '2023-03-14 16:44:49'),
(38, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Katana', '2023-03-14 16:45:21'),
(39, 24, 64, 'LilD_Kingos', 'LilD_whiskey', 'Fists', '2023-03-14 16:47:44'),
(40, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'Fists', '2023-03-14 16:49:21'),
(41, 40, 54, 'LUCAS_GUANTANAMO', 'psiko_boukhris', 'Fists', '2023-03-14 16:51:22'),
(42, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'AK47', '2023-03-14 16:52:39'),
(43, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 16:52:46'),
(44, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Knife', '2023-03-14 16:55:02'),
(45, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Knife', '2023-03-14 16:55:17'),
(46, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Knife', '2023-03-14 16:55:29'),
(47, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Knife', '2023-03-14 16:55:36'),
(48, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Knife', '2023-03-14 16:56:15'),
(49, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'Colt 45', '2023-03-14 17:02:39'),
(50, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 17:03:27'),
(51, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 17:03:39'),
(52, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 17:04:30'),
(53, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 17:04:58'),
(54, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 17:05:33'),
(55, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'TEC9', '2023-03-14 17:06:27'),
(56, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'TEC9', '2023-03-14 17:06:31'),
(57, 40, 54, 'LUCAS_GUANTANAMO', 'psiko_boukhris', 'TEC9', '2023-03-14 17:07:32'),
(58, 40, 54, 'LUCAS_GUANTANAMO', 'psiko_boukhris', 'TEC9', '2023-03-14 17:07:55'),
(59, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'TEC9', '2023-03-14 17:07:57'),
(60, 40, 54, 'LUCAS_GUANTANAMO', 'psiko_boukhris', 'TEC9', '2023-03-14 17:09:09'),
(61, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'UZI', '2023-03-14 17:09:13'),
(62, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'UZI', '2023-03-14 17:09:48'),
(63, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'UZI', '2023-03-14 17:10:00'),
(64, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 17:11:19'),
(65, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Explosion', '2023-03-14 17:11:24'),
(66, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'AK47', '2023-03-14 17:11:44'),
(67, 8, 50, 'Limbo_sinyore', 'AJAXX_SIPO', 'Fists', '2023-03-14 17:24:05'),
(68, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'Silenced Pistol', '2023-03-14 18:08:50'),
(69, 79, 40, 'Keyhell_GUANTANAMO', 'LUCAS_GUANTANAMO', 'Desert Eagle', '2023-03-14 18:09:22'),
(70, 34, 82, 'POCO_LOCO', 'JUNIOR_VINICUIS', 'Katana', '2023-03-14 18:18:35'),
(71, 34, 56, 'POCO_LOCO', 'X_Mafia', 'AK47', '2023-03-14 18:20:52'),
(72, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 18:22:28'),
(73, 56, 54, 'X_Mafia', 'psiko_boukhris', 'Desert Eagle', '2023-03-14 18:25:41'),
(74, 34, 56, 'POCO_LOCO', 'X_Mafia', 'AK47', '2023-03-14 18:26:30'),
(75, 40, 56, 'LUCAS_GUANTANAMO', 'X_Mafia', 'Silenced Pistol', '2023-03-14 18:26:38'),
(76, 34, 40, 'POCO_LOCO', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 18:26:38'),
(77, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 18:26:58'),
(78, 82, 54, 'JUNIOR_VINICUIS', 'psiko_boukhris', 'AK47', '2023-03-14 18:27:26'),
(79, 54, 82, 'psiko_boukhris', 'JUNIOR_VINICUIS', 'AK47', '2023-03-14 18:34:50'),
(80, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Katana', '2023-03-14 18:36:42'),
(81, 3, 23, 'Felix_Jigo', 'Vini_Edrian', 'Fists', '2023-03-14 18:36:42'),
(82, 34, 82, 'POCO_LOCO', 'JUNIOR_VINICUIS', 'Silenced Pistol', '2023-03-14 18:39:47'),
(83, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Silenced Pistol', '2023-03-14 18:40:02'),
(84, 54, 40, 'psiko_boukhris', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-14 18:40:39'),
(85, 34, 82, 'POCO_LOCO', 'JUNIOR_VINICUIS', 'TEC9', '2023-03-14 18:43:22'),
(86, 34, 56, 'POCO_LOCO', 'X_Mafia', 'Silenced Pistol', '2023-03-14 19:06:01'),
(87, 34, 56, 'POCO_LOCO', 'X_Mafia', 'AK47', '2023-03-14 19:11:11'),
(88, 34, 56, 'POCO_LOCO', 'X_Mafia', 'Silenced Pistol', '2023-03-14 19:17:19'),
(89, 34, 54, 'POCO_LOCO', 'psiko_boukhris', 'Fists', '2023-03-14 21:21:26'),
(90, 34, 56, 'POCO_LOCO', 'X_Mafia', 'Katana', '2023-03-14 21:34:03'),
(91, 34, 99, 'POCO_LOCO', 'TONIKE_BIMO', 'AK47', '2023-03-14 22:04:08'),
(92, 34, 98, '', 'Felix_Jigo', 'Silenced Pistol', '2023-03-14 22:24:02'),
(93, 8, 113, 'Limbo_sinyore', 'SALIM_LUCAS', 'Fists', '2023-03-15 00:04:40'),
(94, 91, 106, 'Ayoub_Jasm', 'Darwin_Watirson', 'Fists', '2023-03-15 00:07:00'),
(95, 91, 106, 'Ayoub_Jasm', 'Darwin_Watirson', 'Fists', '2023-03-15 00:07:14'),
(96, 117, 28, 'Kwika_Sriwila', 'AYMEN_LME3DAWI', 'Fists', '2023-03-15 00:20:50'),
(97, 88, 117, 'salto_bikit', 'Kwika_Sriwila', 'Fists', '2023-03-15 01:14:59'),
(98, 56, 117, 'X_Mafia', 'Kwika_Sriwila', 'Desert Eagle', '2023-03-15 01:21:37'),
(99, 54, 8, 'psiko_boukhris', 'Limbo_sinyore', 'AK47', '2023-03-15 01:24:54'),
(100, 88, 117, 'salto_bikit', 'Kwika_Sriwila', 'Fists', '2023-03-15 01:24:57'),
(101, 45, 28, 'dob_lghaba', 'AYMEN_LME3DAWI', 'Vehicle', '2023-03-15 01:58:12'),
(102, 23, 70, 'Vini_Edrian', 'Dyablo_Dr3awi', 'Fists', '2023-03-15 02:07:41'),
(103, 63, 49, 'Anas_Tali', 'Selfx_Tchapo', 'Fists', '2023-03-15 02:26:35'),
(104, 28, 45, 'AYMEN_LME3DAWI', 'dob_lghaba', 'Fists', '2023-03-15 02:28:01'),
(105, 63, 28, 'Anas_Tali', 'AYMEN_LME3DAWI', 'Fists', '2023-03-15 02:28:24'),
(106, 45, 54, 'dob_lghaba', 'psiko_boukhris', 'Fists', '2023-03-15 02:33:12'),
(107, 45, 49, 'dob_lghaba', 'Selfx_Tchapo', 'Fists', '2023-03-15 02:34:50'),
(108, 45, 63, 'dob_lghaba', 'Anas_Tali', 'Fists', '2023-03-15 02:35:30'),
(109, 54, 49, 'psiko_boukhris', 'Selfx_Tchapo', 'Silenced Pistol', '2023-03-15 03:44:18'),
(110, 49, 13, 'Selfx_Tchapo', 'ANAS_RAID', 'Fists', '2023-03-15 03:45:07'),
(111, 48, 49, 'STEVAW_MARTINEZ', 'Selfx_Tchapo', 'Vehicle', '2023-03-15 04:16:43'),
(112, 110, 14, 'Chliha_Olmhjob', 'abdollah_algnawi', 'Silenced Pistol', '2023-03-15 10:01:03'),
(113, 110, 75, 'Chliha_Olmhjob', 'ALVARO_MORATA', 'Silenced Pistol', '2023-03-15 10:09:12'),
(114, 34, 14, 'POCO_LOCO', 'abdollah_algnawi', 'Katana', '2023-03-15 10:10:23'),
(115, 121, 122, 'matouss_clean', 'yasser_elallawi', 'Fists', '2023-03-15 10:46:31'),
(116, 110, 28, 'Chliha_Olmhjob', 'AYMEN_LME3DAWI', 'Silenced Pistol', '2023-03-15 11:10:59'),
(117, 110, 123, 'Chliha_Olmhjob', 'Comi_Escobar', 'Silenced Pistol', '2023-03-15 11:13:15'),
(118, 14, 87, 'abdollah_algnawi', 'Mohamed_gostavo', 'Vehicle', '2023-03-15 11:30:58'),
(119, 40, 14, 'LUCAS_GUANTANAMO', 'abdollah_algnawi', 'AK47', '2023-03-15 12:08:10'),
(120, 34, 98, 'POCO_LOCO', 'Felix_Jigo', 'Silenced Pistol', '2023-03-15 12:50:02'),
(121, 34, 98, 'POCO_LOCO', 'Felix_Jigo', 'Silenced Pistol', '2023-03-15 12:50:11'),
(122, 56, 34, 'X_Mafia', 'POCO_LOCO', 'Silenced Pistol', '2023-03-15 12:52:40'),
(123, 100, 116, 'Eazy_Gaviria', 'WASSIM_LUCAS', 'Fists', '2023-03-15 13:23:26'),
(124, 106, 28, 'Darwin_Watirson', 'AYMEN_LME3DAWI', 'Fists', '2023-03-15 14:11:26'),
(125, 106, 90, 'Darwin_Watirson', 'Carlos_Messi', 'Vehicle', '2023-03-15 14:28:22'),
(126, 106, 90, 'Darwin_Watirson', 'Carlos_Messi', 'Fists', '2023-03-15 14:28:47'),
(127, 91, 123, 'Ayoub_Jasm', 'Comi_Escobar', 'Fists', '2023-03-15 15:21:25'),
(128, 90, 114, 'Carlos_Messi', 'Robert_Carlos', 'Fists', '2023-03-15 15:43:45'),
(129, 121, 114, 'matouss_clean', 'Robert_Carlos', 'Fists', '2023-03-15 15:49:20'),
(130, 121, 112, 'matouss_clean', 'Snop_Doge', 'Fists', '2023-03-15 15:49:20'),
(131, 121, 114, 'matouss_clean', 'Robert_Carlos', 'Fists', '2023-03-15 16:01:25'),
(132, 121, 132, 'matouss_clean', 'Pitcho_Dasilva', 'Fists', '2023-03-15 16:04:17'),
(133, 118, 90, 'AMINE_RANCHO', 'Carlos_Messi', 'Helicopter Blades', '2023-03-15 16:16:31'),
(134, 123, 90, 'Comi_Escobar', 'Carlos_Messi', 'Fists', '2023-03-15 16:17:37'),
(135, 56, 80, 'X_Mafia', 'Tropa_Williams', 'Silenced Pistol', '2023-03-15 18:15:33'),
(136, 143, 145, 'NMS_FLIX', 'moha_moro', 'Silenced Pistol', '2023-03-15 19:18:48'),
(137, 30, 28, 'Nfha_Doo', 'AYMEN_LME3DAWI', 'Fists', '2023-03-15 21:22:14'),
(138, 90, 125, 'Carlos_Messi', 'GOD_TIPO', 'Fists', '2023-03-15 21:25:15'),
(139, 38, 28, 'Dyablo_Edrian', 'AYMEN_LME3DAWI', 'Fists', '2023-03-15 21:27:28'),
(140, 36, 14, 'James_Edrian', 'abdollah_algnawi', 'Fists', '2023-03-15 21:33:19'),
(141, 38, 28, 'Dyablo_Edrian', 'AYMEN_LME3DAWI', 'Fists', '2023-03-15 21:34:42'),
(142, 38, 28, 'Dyablo_Edrian', 'AYMEN_LME3DAWI', 'Fists', '2023-03-15 21:34:45'),
(143, 149, 23, 'Dyablo_Sbar', 'Vini_Edrian', 'Fists', '2023-03-15 22:03:19'),
(144, 36, 149, 'James_Edrian', 'Dyablo_Sbar', 'Fists', '2023-03-15 22:03:59'),
(145, 135, 74, 'Yassir_sancho', 'bababoy_Edrian', 'Silenced Pistol', '2023-03-15 22:09:37'),
(146, 94, 109, 'Unknown_', 'ROCH_PRAN', 'Silenced Pistol', '2023-03-15 22:13:22'),
(147, 49, 63, 'Selfx_Tchapo', 'Anas_Tali', 'Fists', '2023-03-15 22:44:07'),
(148, 131, 150, 'hmed_twil', 'RAMZI__HAMO', 'Fists', '2023-03-15 22:54:44'),
(149, 150, 75, 'RAMZI__HAMO', 'ALVARO_MORATA', 'Silenced Pistol', '2023-03-15 23:12:54'),
(150, 150, 159, 'RAMZI__HAMO', 'HICHAM_PEDRI', 'Silenced Pistol', '2023-03-15 23:13:07'),
(151, 56, 76, 'X_Mafia', 'Lmour_pholoko', 'Silenced Pistol', '2023-03-15 23:14:50'),
(152, 56, 155, 'X_Mafia', 'Leo_Garcia', 'AK47', '2023-03-15 23:16:57'),
(153, 54, 122, 'psiko_boukhris', 'yasser_elallawi', 'AK47', '2023-03-15 23:16:58'),
(154, 54, 29, 'psiko_boukhris', 'Kaspre_Edrian', 'AK47', '2023-03-15 23:17:41'),
(155, 76, 122, 'Lmour_pholoko', 'yasser_elallawi', 'Katana', '2023-03-15 23:24:56'),
(156, 2, 54, 'Pedro_Admin', 'psiko_boukhris', 'M4', '2023-03-15 23:28:06'),
(157, 2, 49, 'Pedro_Admin', 'Selfx_Tchapo', 'M4', '2023-03-15 23:28:17'),
(158, 5, 160, 'Reda_Tazi', 'Farouk_Lhrba', 'AK47', '2023-03-15 23:32:54'),
(159, 5, 40, 'Reda_Tazi', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-15 23:33:35'),
(160, 2, 156, 'Pedro_Admin', 'Hamdi_johnson', 'Combat Shotgun', '2023-03-15 23:39:30'),
(161, 100, 63, 'Eazy_Gaviria', 'Anas_Tali', 'Fists', '2023-03-15 23:46:27'),
(162, 2, 113, 'Pedro_Admin', 'SALIM_LUCAS', 'Combat Shotgun', '2023-03-15 23:53:59'),
(163, 157, 13, 'POP_SMOKE', 'ANAS_RAID', 'Fists', '2023-03-15 23:54:12'),
(164, 2, 113, 'Pedro_Admin', 'SALIM_LUCAS', 'Combat Shotgun', '2023-03-15 23:54:12'),
(165, 5, 155, 'Reda_Tazi', 'Leo_Garcia', 'AK47', '2023-03-15 23:56:11'),
(166, 56, 155, 'X_Mafia', 'Leo_Garcia', 'AK47', '2023-03-15 23:56:32'),
(167, 110, 122, 'Chliha_Olmhjob', 'yasser_elallawi', 'Flamethrower', '2023-03-15 23:57:21'),
(168, 56, 35, 'X_Mafia', 'JAIMSE_PALACIO', 'AK47', '2023-03-15 23:57:44'),
(169, 106, 122, 'Darwin_Watirson', 'yasser_elallawi', 'Fists', '2023-03-15 23:57:56'),
(170, 2, 37, 'Pedro_Admin', 'Tyson_Choppa', 'Flamethrower', '2023-03-15 23:58:12'),
(171, 155, 113, 'Leo_Garcia', 'SALIM_LUCAS', 'Fists', '2023-03-15 23:58:28'),
(172, 147, 63, 'Lucas_Morinio', 'Anas_Tali', 'Fists', '2023-03-15 23:58:33'),
(173, 56, 35, 'X_Mafia', 'JAIMSE_PALACIO', 'AK47', '2023-03-15 23:58:45'),
(174, 100, 37, 'Eazy_Gaviria', 'Tyson_Choppa', 'Fists', '2023-03-15 23:58:47'),
(175, 131, 8, 'hmed_twil', 'Limbo_sinyore', 'Fists', '2023-03-15 23:59:20'),
(176, 131, 40, 'hmed_twil', 'LUCAS_GUANTANAMO', 'Fists', '2023-03-15 23:59:21'),
(177, 157, 147, 'POP_SMOKE', 'Lucas_Morinio', 'Flamethrower', '2023-03-15 23:59:29'),
(178, 2, 48, 'Pedro_Admin', 'STEVAW_MARTINEZ', 'Desert Eagle', '2023-03-15 23:59:53'),
(179, 2, 48, 'Pedro_Admin', 'STEVAW_MARTINEZ', 'Desert Eagle', '2023-03-15 23:59:59'),
(180, 112, 109, 'Snop_Doge', 'ROCH_PRAN', 'Fists', '2023-03-16 00:00:12'),
(181, 56, 112, 'X_Mafia', 'Snop_Doge', 'AK47', '2023-03-16 00:00:23'),
(182, 56, 109, 'X_Mafia', 'ROCH_PRAN', 'AK47', '2023-03-16 00:00:26'),
(183, 56, 112, 'X_Mafia', 'Snop_Doge', 'AK47', '2023-03-16 00:00:27'),
(184, 131, 28, 'hmed_twil', 'AYMEN_LME3DAWI', 'Fists', '2023-03-16 00:00:36'),
(185, 155, 113, 'Leo_Garcia', 'SALIM_LUCAS', 'Fists', '2023-03-16 00:00:42'),
(186, 122, 155, 'yasser_elallawi', 'Leo_Garcia', 'Fists', '2023-03-16 00:00:43'),
(187, 2, 135, 'Pedro_Admin', 'Yassir_sancho', 'Explosion', '2023-03-16 00:00:48'),
(188, 131, 93, 'hmed_twil', 'Jlabanda_MDFK', 'Fists', '2023-03-16 00:01:07'),
(189, 56, 8, 'X_Mafia', 'Limbo_sinyore', 'AK47', '2023-03-16 00:01:10'),
(190, 56, 28, 'X_Mafia', 'AYMEN_LME3DAWI', 'AK47', '2023-03-16 00:01:17'),
(191, 76, 135, 'Lmour_pholoko', 'Yassir_sancho', 'Fists', '2023-03-16 00:01:21'),
(192, 2, 76, 'Pedro_Admin', 'Lmour_pholoko', 'Explosion', '2023-03-16 00:01:28'),
(193, 56, 150, 'X_Mafia', 'RAMZI__HAMO', 'AK47', '2023-03-16 00:01:35'),
(194, 2, 156, 'Pedro_Admin', 'Hamdi_johnson', 'Desert Eagle', '2023-03-16 00:01:36'),
(195, 2, 91, 'Pedro_Admin', 'Ayoub_Jasm', 'Explosion', '2023-03-16 00:01:52'),
(196, 2, 149, 'Pedro_Admin', 'Dyablo_Sbar', 'Explosion', '2023-03-16 00:01:52'),
(197, 56, 40, 'X_Mafia', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-16 00:01:52'),
(198, 56, 156, 'X_Mafia', 'Hamdi_johnson', 'AK47', '2023-03-16 00:02:05'),
(199, 2, 149, 'Pedro_Admin', 'Dyablo_Sbar', 'Explosion', '2023-03-16 00:02:15'),
(200, 2, 62, 'Pedro_Admin', 'Andrew_Tate', 'Explosion', '2023-03-16 00:02:15'),
(201, 56, 150, 'X_Mafia', 'RAMZI__HAMO', 'AK47', '2023-03-16 00:02:19'),
(202, 131, 54, 'hmed_twil', 'psiko_boukhris', 'Fists', '2023-03-16 00:02:23'),
(203, 100, 63, 'Eazy_Gaviria', 'Anas_Tali', 'Fists', '2023-03-16 00:02:31'),
(204, 2, 100, 'Pedro_Admin', 'Eazy_Gaviria', 'Explosion', '2023-03-16 00:02:40'),
(205, 56, 62, 'X_Mafia', 'Andrew_Tate', 'AK47', '2023-03-16 00:02:46'),
(206, 2, 131, 'Pedro_Admin', 'hmed_twil', 'Combat Shotgun', '2023-03-16 00:02:47'),
(207, 135, 28, 'Yassir_sancho', 'AYMEN_LME3DAWI', 'Fists', '2023-03-16 00:02:54'),
(208, 2, 76, 'Pedro_Admin', 'Lmour_pholoko', 'Combat Shotgun', '2023-03-16 00:02:57'),
(209, 2, 100, 'Pedro_Admin', 'Eazy_Gaviria', 'Combat Shotgun', '2023-03-16 00:03:08'),
(210, 122, 155, 'yasser_elallawi', 'Leo_Garcia', 'Fists', '2023-03-16 00:03:12'),
(211, 2, 54, 'Pedro_Admin', 'psiko_boukhris', 'Combat Shotgun', '2023-03-16 00:03:16'),
(212, 2, 91, 'Pedro_Admin', 'Ayoub_Jasm', 'Combat Shotgun', '2023-03-16 00:03:21'),
(213, 2, 93, 'Pedro_Admin', 'Jlabanda_MDFK', 'Combat Shotgun', '2023-03-16 00:03:25'),
(214, 2, 147, 'Pedro_Admin', 'Lucas_Morinio', 'Combat Shotgun', '2023-03-16 00:03:30'),
(215, 131, 63, 'hmed_twil', 'Anas_Tali', 'Fists', '2023-03-16 00:03:32'),
(216, 135, 109, 'Yassir_sancho', 'ROCH_PRAN', 'Silenced Pistol', '2023-03-16 00:03:32'),
(217, 56, 36, 'X_Mafia', 'James_Edrian', 'AK47', '2023-03-16 00:03:37'),
(218, 2, 13, 'Pedro_Admin', 'ANAS_RAID', 'Explosion', '2023-03-16 00:03:40'),
(219, 2, 23, 'Pedro_Admin', 'Vini_Edrian', 'Explosion', '2023-03-16 00:03:46'),
(220, 135, 100, 'Yassir_sancho', 'Eazy_Gaviria', 'Fists', '2023-03-16 00:04:04'),
(221, 91, 122, 'Ayoub_Jasm', 'yasser_elallawi', 'Fists', '2023-03-16 00:04:12'),
(222, 150, 76, 'RAMZI__HAMO', 'Lmour_pholoko', 'Silenced Pistol', '2023-03-16 00:04:15'),
(223, 2, 45, 'Pedro_Admin', 'dob_lghaba', 'Explosion', '2023-03-16 00:04:22'),
(224, 56, 13, 'X_Mafia', 'ANAS_RAID', 'AK47', '2023-03-16 00:04:23'),
(225, 56, 23, 'X_Mafia', 'Vini_Edrian', 'AK47', '2023-03-16 00:04:25'),
(226, 56, 23, 'X_Mafia', 'Vini_Edrian', 'AK47', '2023-03-16 00:04:28'),
(227, 135, 91, 'Yassir_sancho', 'Ayoub_Jasm', 'Fists', '2023-03-16 00:05:08'),
(228, 13, 156, 'ANAS_RAID', 'Hamdi_johnson', 'Fists', '2023-03-16 00:05:09'),
(229, 135, 13, 'Yassir_sancho', 'ANAS_RAID', 'Silenced Pistol', '2023-03-16 00:05:31'),
(230, 131, 93, 'hmed_twil', 'Jlabanda_MDFK', 'Silenced Pistol', '2023-03-16 00:05:38'),
(231, 2, 62, 'Pedro_Admin', 'Andrew_Tate', 'Explosion', '2023-03-16 00:05:42'),
(232, 2, 17, 'Pedro_Admin', 'Rachid_ekambi', 'Explosion', '2023-03-16 00:06:00'),
(233, 56, 62, 'X_Mafia', 'Andrew_Tate', 'AK47', '2023-03-16 00:06:01'),
(234, 135, 109, 'Yassir_sancho', 'ROCH_PRAN', 'Silenced Pistol', '2023-03-16 00:06:34'),
(235, 150, 76, 'RAMZI__HAMO', 'Lmour_pholoko', 'Silenced Pistol', '2023-03-16 00:06:35'),
(236, 63, 135, 'Anas_Tali', 'Yassir_sancho', 'Fists', '2023-03-16 00:06:38'),
(237, 106, 17, 'Darwin_Watirson', 'Rachid_ekambi', 'Fists', '2023-03-16 00:06:53'),
(238, 56, 23, 'X_Mafia', 'Vini_Edrian', 'AK47', '2023-03-16 00:06:59'),
(239, 56, 110, 'X_Mafia', 'Chliha_Olmhjob', 'AK47', '2023-03-16 00:06:59'),
(240, 76, 93, 'Lmour_pholoko', 'Jlabanda_MDFK', 'Fists', '2023-03-16 00:07:00'),
(241, 2, 110, 'Pedro_Admin', 'Chliha_Olmhjob', 'Desert Eagle', '2023-03-16 00:07:27'),
(242, 2, 45, 'Pedro_Admin', 'dob_lghaba', 'Desert Eagle', '2023-03-16 00:07:30'),
(243, 2, 88, 'Pedro_Admin', 'salto_bikit', 'M4', '2023-03-16 00:07:47'),
(244, 2, 88, 'Pedro_Admin', 'salto_bikit', 'M4', '2023-03-16 00:07:53'),
(245, 2, 48, 'Pedro_Admin', 'STEVAW_MARTINEZ', 'Explosion', '2023-03-16 00:09:12'),
(246, 2, 106, 'Pedro_Admin', 'Darwin_Watirson', 'Explosion', '2023-03-16 00:09:50'),
(247, 2, 14, 'Pedro_Admin', 'abdollah_algnawi', 'Explosion', '2023-03-16 00:09:59'),
(248, 2, 14, 'Pedro_Admin', 'abdollah_algnawi', 'Desert Eagle', '2023-03-16 00:10:18'),
(249, 2, 106, 'Pedro_Admin', 'Darwin_Watirson', 'Desert Eagle', '2023-03-16 00:10:29'),
(250, 2, 48, 'Pedro_Admin', 'STEVAW_MARTINEZ', 'Desert Eagle', '2023-03-16 00:10:34'),
(251, 76, 88, 'Lmour_pholoko', 'salto_bikit', 'Fists', '2023-03-16 00:10:50'),
(252, 157, 23, 'POP_SMOKE', 'Vini_Edrian', 'Fists', '2023-03-16 00:11:15'),
(253, 93, 35, 'Jlabanda_MDFK', 'JAIMSE_PALACIO', 'Fists', '2023-03-16 00:11:47'),
(254, 2, 8, 'Pedro_Admin', 'Limbo_sinyore', 'Explosion', '2023-03-16 00:12:42'),
(255, 2, 113, 'Pedro_Admin', 'SALIM_LUCAS', 'Explosion', '2023-03-16 00:12:42'),
(256, 63, 113, 'Anas_Tali', 'SALIM_LUCAS', 'Fists', '2023-03-16 00:13:28'),
(257, 63, 76, 'Anas_Tali', 'Lmour_pholoko', 'Fists', '2023-03-16 00:17:54'),
(258, 23, 93, 'Vini_Edrian', 'Jlabanda_MDFK', 'Fists', '2023-03-16 00:28:14'),
(259, 35, 154, 'JAIMSE_PALACIO', 'SHARLOC_SMOKERS', 'Vehicle', '2023-03-16 01:12:16'),
(260, 17, 56, 'Rachid_ekambi', 'X_Mafia', 'AK47', '2023-03-16 01:18:51'),
(261, 17, 56, 'Rachid_ekambi', 'X_Mafia', 'AK47', '2023-03-16 01:21:38'),
(262, 17, 54, 'Rachid_ekambi', 'psiko_boukhris', 'AK47', '2023-03-16 01:21:55'),
(263, 17, 54, 'Rachid_ekambi', 'psiko_boukhris', 'AK47', '2023-03-16 01:22:17'),
(264, 23, 100, 'Vini_Edrian', 'Eazy_Gaviria', 'Fists', '2023-03-16 01:30:09'),
(265, 17, 54, 'Rachid_ekambi', 'psiko_boukhris', 'Silenced Pistol', '2023-03-16 01:33:24'),
(266, 100, 88, 'Eazy_Gaviria', 'salto_bikit', 'Katana', '2023-03-16 02:14:19'),
(267, 13, 63, 'ANAS_RAID', 'Anas_Tali', 'Fists', '2023-03-16 02:56:25'),
(268, 56, 62, 'X_Mafia', 'ADMIN_BO3O', 'Desert Eagle', '2023-03-16 03:08:48'),
(269, 62, 56, 'ADMIN_BO3O', 'X_Mafia', 'AK47', '2023-03-16 03:09:26'),
(270, 56, 62, 'X_Mafia', 'ADMIN_BO3O', 'Desert Eagle', '2023-03-16 03:13:44'),
(271, 56, 62, 'X_Mafia', 'ADMIN_BO3O', 'Desert Eagle', '2023-03-16 03:14:02'),
(272, 56, 62, 'X_Mafia', 'ADMIN_BO3O', 'Desert Eagle', '2023-03-16 03:14:08'),
(273, 139, 63, 'dizzy_dros', 'Anas_Tali', 'Silenced Pistol', '2023-03-16 04:31:07'),
(274, 139, 48, 'dizzy_dros', 'STEVAW_MARTINEZ', 'Silenced Pistol', '2023-03-16 04:33:50'),
(275, 139, 63, 'dizzy_dros', 'Anas_Tali', 'Silenced Pistol', '2023-03-16 04:40:55'),
(276, 17, 63, 'Rachid_ekambi', 'Anas_Tali', 'Silenced Pistol', '2023-03-16 04:45:00'),
(277, 17, 63, 'Rachid_ekambi', 'Anas_Tali', 'Silenced Pistol', '2023-03-16 04:45:43'),
(278, 17, 63, 'Rachid_ekambi', 'Anas_Tali', 'Silenced Pistol', '2023-03-16 04:45:56'),
(279, 139, 48, 'dizzy_dros', 'STEVAW_MARTINEZ', 'Silenced Pistol', '2023-03-16 05:19:06'),
(280, 48, 63, 'STEVAW_MARTINEZ', 'Anas_Tali', 'Fists', '2023-03-16 05:27:56'),
(281, 63, 139, 'Anas_Tali', 'dizzy_dros', 'Fists', '2023-03-16 05:34:09'),
(282, 94, 167, 'Unknown_', 'Ayman_Pedro', 'Silenced Pistol', '2023-03-16 13:53:38'),
(283, 145, 173, 'moha_moro', 'JERRY_SMOKER', 'Fists', '2023-03-16 14:24:14'),
(284, 145, 173, 'moha_moro', 'JERRY_SMOKER', 'Fists', '2023-03-16 14:25:05'),
(285, 154, 173, 'SHARLOC_SMOKERS', 'JERRY_SMOKER', 'Fists', '2023-03-16 15:02:35'),
(286, 88, 117, 'salto_bikit', 'Kwika_Sriwila', 'Flamethrower', '2023-03-16 15:10:01'),
(287, 148, 93, 'Ahmed_Sfriwi', 'Jlabanda_MDFK', 'Fists', '2023-03-16 15:12:24'),
(288, 154, 179, 'SHARLOC_SMOKERS', 'Pagero_Wang', 'Fists', '2023-03-16 15:18:45'),
(289, 173, 154, 'JERRY_SMOKER', 'SHARLOC_SMOKERS', 'Fists', '2023-03-16 15:18:54'),
(290, 133, 75, 'anuar_oustora', 'ALVARO_MORATA', 'Silenced Pistol', '2023-03-16 15:21:01'),
(291, 133, 75, 'anuar_oustora', 'ALVARO_MORATA', 'Silenced Pistol', '2023-03-16 15:23:47'),
(292, 100, 141, 'Eazy_Gaviria', 'zamora_chadi', 'Katana', '2023-03-16 15:41:54'),
(293, 100, 141, 'Eazy_Gaviria', 'zamora_chadi', 'Katana', '2023-03-16 15:43:25'),
(294, 139, 182, 'dizzy_dros', 'BADR_PEDRI', 'Silenced Pistol', '2023-03-16 15:52:46'),
(295, 30, 4, 'Nfha_Doo', 'Smoke_Jigo', 'Fists', '2023-03-16 16:46:34'),
(296, 154, 175, 'SHARLOC_SMOKERS', 'Ismail_Sanch', 'Fists', '2023-03-16 16:47:16'),
(297, 154, 167, 'SHARLOC_SMOKERS', 'Ayman_Pedro', 'Fists', '2023-03-16 16:48:00'),
(298, 154, 167, 'SHARLOC_SMOKERS', 'Ayman_Pedro', 'Fists', '2023-03-16 16:52:21'),
(299, 173, 175, 'JERRY_SMOKER', 'Ismail_Sanch', 'Fists', '2023-03-16 16:52:30'),
(300, 173, 86, 'JERRY_SMOKER', 'DRISS_ESCOBAR', 'Fists', '2023-03-16 16:57:45'),
(301, 13, 17, 'ANAS_RAID', 'Rachid_ekambi', 'Fists', '2023-03-16 17:02:23'),
(302, 182, 173, 'BADR_PEDRI', 'JERRY_SMOKER', 'Katana', '2023-03-16 17:05:23'),
(303, 157, 182, 'POP_SMOKE', 'BADR_PEDRI', 'Fists', '2023-03-16 17:08:02'),
(304, 110, 167, 'Chliha_Olmhjob', 'Ayman_Pedro', 'Vehicle', '2023-03-16 17:40:52'),
(305, 110, 175, 'Chliha_Olmhjob', 'Ismail_Sanch', 'Fists', '2023-03-16 17:42:24'),
(306, 167, 175, 'Ayman_Pedro', 'Ismail_Sanch', 'Fists', '2023-03-16 17:48:49'),
(307, 163, 54, 'X_Mafia', 'psiko_boukhris', 'Silenced Pistol', '2023-03-16 17:56:20'),
(308, 163, 54, 'X_Mafia', 'psiko_boukhris', 'Silenced Pistol', '2023-03-16 17:56:29'),
(309, 154, 178, 'SHARLOC_SMOKERS', 'HADES_SMOKERS', 'Fists', '2023-03-16 17:59:32'),
(310, 100, 14, 'Eazy_Gaviria', 'abdollah_algnawi', 'Katana', '2023-03-16 18:00:34'),
(311, 175, 167, 'Ismail_Sanch', 'Ayman_Pedro', 'Fists', '2023-03-16 18:18:12'),
(312, 100, 14, 'Eazy_Gaviria', 'abdollah_algnawi', 'Katana', '2023-03-16 18:21:13'),
(313, 175, 197, 'Ismail_Sanch', 'FAYO_SMOKERS', 'Fists', '2023-03-16 18:31:39'),
(314, 150, 154, 'RAMZI__HAMO', 'SHARLOC_SMOKERS', 'Silenced Pistol', '2023-03-16 18:34:47'),
(315, 4, 94, 'Smoke_Jigo', 'Unknown_', 'Vehicle', '2023-03-16 18:47:39'),
(316, 163, 147, 'X_Mafia', 'Lucas_Morinio', 'Silenced Pistol', '2023-03-16 18:51:33'),
(317, 178, 163, 'HADES_SMOKERS', 'X_Mafia', 'Fists', '2023-03-16 19:00:00'),
(318, 147, 163, 'Lucas_Morinio', 'X_Mafia', 'Silenced Pistol', '2023-03-16 19:36:43'),
(319, 163, 147, 'X_Mafia', 'Lucas_Morinio', 'AK47', '2023-03-16 19:37:04'),
(320, 98, 36, 'Felix_Jigo', 'James_Edrian', 'Fists', '2023-03-16 19:40:35'),
(321, 147, 98, 'Lucas_Morinio', 'Felix_Jigo', 'Silenced Pistol', '2023-03-16 19:44:22'),
(322, 157, 158, 'POP_SMOKE', 'GOJO_ALGAHTANI', 'Fists', '2023-03-16 19:58:05'),
(323, 86, 158, 'DRISS_ESCOBAR', 'GOJO_ALGAHTANI', 'Fists', '2023-03-16 20:07:43'),
(324, 135, 86, 'Yassir_sancho', 'DRISS_ESCOBAR', 'Fists', '2023-03-16 20:16:53'),
(325, 135, 158, 'Yassir_sancho', 'GOJO_ALGAHTANI', 'Fists', '2023-03-16 20:19:05'),
(326, 177, 135, 'PAOLO_SMOKERS', 'Yassir_sancho', 'Fists', '2023-03-16 20:19:16'),
(327, 106, 168, 'Darwin_Watirson', 'Lucas_Garcia', 'Fists', '2023-03-16 20:28:55'),
(328, 177, 154, 'PAOLO_SMOKERS', 'SHARLOC_SMOKERS', 'Vehicle', '2023-03-16 20:30:18'),
(329, 178, 154, 'HADES_SMOKERS', 'SHARLOC_SMOKERS', 'Fists', '2023-03-16 20:34:09'),
(330, 158, 154, 'GOJO_ALGAHTANI', 'SHARLOC_SMOKERS', 'Fists', '2023-03-16 20:36:55'),
(331, 147, 177, 'Lucas_Morinio', 'PAOLO_SMOKERS', 'Silenced Pistol', '2023-03-16 20:38:02'),
(332, 147, 178, 'Lucas_Morinio', 'HADES_SMOKERS', 'Silenced Pistol', '2023-03-16 20:38:11'),
(333, 158, 154, 'GOJO_ALGAHTANI', 'SHARLOC_SMOKERS', 'Fists', '2023-03-16 20:39:11'),
(334, 177, 158, 'PAOLO_SMOKERS', 'GOJO_ALGAHTANI', 'Fists', '2023-03-16 20:40:46'),
(335, 157, 177, 'POP_SMOKE', 'PAOLO_SMOKERS', 'Fists', '2023-03-16 20:41:17'),
(336, 157, 154, 'POP_SMOKE', 'SHARLOC_SMOKERS', 'Fists', '2023-03-16 20:41:46'),
(337, 147, 178, 'Lucas_Morinio', 'HADES_SMOKERS', 'Silenced Pistol', '2023-03-16 20:44:43'),
(338, 182, 183, 'BADR_PEDRI', 'PABLO_PICASO', 'Katana', '2023-03-16 20:56:53'),
(339, 182, 183, 'BADR_PEDRI', 'PABLO_PICASO', 'Katana', '2023-03-16 20:58:27'),
(340, 85, 156, 'Oualid_Jackson', 'Hamdi_johnson', 'Fists', '2023-03-16 21:23:57'),
(341, 76, 2, 'Lmour_pholoko', 'Pedro_Admin', 'Katana', '2023-03-17 13:10:05'),
(342, 2, 188, 'Pedro_Admin', 'MIKHAEL_RODRIGUEZ', 'Desert Eagle', '2023-03-17 13:12:29'),
(343, 2, 158, 'Pedro_Admin', 'GOJO_ALGAHTANI', 'Combat Shotgun', '2023-03-17 13:15:50'),
(344, 2, 36, 'Pedro_Admin', 'James_Edrian', 'Combat Shotgun', '2023-03-17 13:15:53'),
(345, 2, 36, 'Pedro_Admin', 'James_Edrian', 'Desert Eagle', '2023-03-17 13:16:20'),
(346, 52, 158, 'Sami_Alpatchino', 'GOJO_ALGAHTANI', 'Fists', '2023-03-17 13:17:30'),
(347, 52, 158, 'Sami_Alpatchino', 'GOJO_ALGAHTANI', 'Fists', '2023-03-17 13:17:55'),
(348, 2, 36, 'Pedro_Admin', 'James_Edrian', 'M4', '2023-03-17 13:18:07'),
(349, 2, 36, 'Pedro_Admin', 'James_Edrian', 'Desert Eagle', '2023-03-17 13:18:40'),
(350, 91, 135, 'Ayoub_Jasm', 'Yassir_sancho', 'Baseball Bat', '2023-03-17 13:20:35'),
(351, 91, 135, 'Ayoub_Jasm', 'Yassir_sancho', 'Baseball Bat', '2023-03-17 13:20:41'),
(352, 2, 36, 'Pedro_Admin', 'James_Edrian', 'Silenced Pistol', '2023-03-17 13:22:22'),
(353, 2, 158, 'Pedro_Admin', 'GOJO_ALGAHTANI', 'Silenced Pistol', '2023-03-17 13:22:33'),
(354, 83, 88, 'LMCH_NATAZI', 'salto_bikit', 'Silenced Pistol', '2023-03-17 13:27:25'),
(355, 42, 76, 'Mistro_Roberto', 'Lmour_pholoko', 'Baseball Bat', '2023-03-17 14:48:37'),
(356, 163, 54, 'X_Mafia', 'psiko_boukhris', 'AK47', '2023-03-17 16:01:42'),
(357, 163, 135, 'X_Mafia', 'Yassir_sancho', 'AK47', '2023-03-17 16:23:34'),
(358, 163, 135, 'X_Mafia', 'Yassir_sancho', 'Silenced Pistol', '2023-03-17 16:27:04'),
(359, 49, 135, 'Selfx_Tchapo', 'Yassir_sancho', 'Katana', '2023-03-17 17:38:43'),
(360, 49, 135, 'Selfx_Tchapo', 'Yassir_sancho', 'Katana', '2023-03-17 17:39:15'),
(361, 37, 35, 'Tyson_Choppa', 'JAIMSE_PALACIO', 'Silenced Pistol', '2023-03-17 18:16:29'),
(362, 62, 49, 'ADMIN_BO3O', 'Selfx_Tchapo', 'Silenced Pistol', '2023-03-17 18:17:21'),
(363, 94, 14, 'Unknown_', 'abdollah_algnawi', 'Silenced Pistol', '2023-03-17 18:23:56'),
(364, 94, 135, 'Unknown_', 'Yassir_sancho', 'Silenced Pistol', '2023-03-17 18:24:03'),
(365, 150, 35, 'RAMZI__HAMO', 'JAIMSE_PALACIO', 'Silenced Pistol', '2023-03-17 18:28:51'),
(366, 163, 40, 'X_Mafia', 'LUCAS_GUANTANAMO', 'Silenced Pistol', '2023-03-17 18:51:52'),
(367, 163, 40, 'X_Mafia', 'LUCAS_GUANTANAMO', 'AK47', '2023-03-17 18:52:00'),
(368, 14, 205, 'abdollah_algnawi', 'islam_lmango', 'Silenced Pistol', '2023-03-17 19:01:10'),
(369, 54, 131, 'psiko_boukhris', 'hmed_twil', 'AK47', '2023-03-17 21:04:58'),
(370, 54, 147, 'psiko_boukhris', 'Lucas_Morinio', 'AK47', '2023-03-17 21:05:00'),
(371, 54, 147, 'psiko_boukhris', 'Lucas_Morinio', 'Fists', '2023-03-17 21:06:01'),
(372, 131, 54, 'hmed_twil', 'psiko_boukhris', 'Silenced Pistol', '2023-03-17 21:08:05'),
(373, 147, 131, 'Lucas_Morinio', 'hmed_twil', 'Silenced Pistol', '2023-03-17 21:08:08'),
(374, 147, 131, 'Lucas_Morinio', 'hmed_twil', 'Silenced Pistol', '2023-03-17 21:08:23'),
(375, 54, 147, 'psiko_boukhris', 'Lucas_Morinio', 'AK47', '2023-03-17 21:08:23'),
(376, 131, 147, 'hmed_twil', 'Lucas_Morinio', 'Silenced Pistol', '2023-03-17 21:09:42'),
(377, 54, 147, 'psiko_boukhris', 'Lucas_Morinio', 'AK47', '2023-03-17 21:10:20'),
(378, 54, 131, 'psiko_boukhris', 'hmed_twil', 'AK47', '2023-03-17 21:10:25'),
(379, 54, 147, 'psiko_boukhris', 'Lucas_Morinio', 'AK47', '2023-03-17 21:12:11'),
(380, 131, 147, 'hmed_twil', 'Lucas_Morinio', 'Silenced Pistol', '2023-03-17 21:15:28'),
(381, 131, 147, 'hmed_twil', 'Lucas_Morinio', 'Silenced Pistol', '2023-03-17 21:44:31'),
(382, 131, 147, 'hmed_twil', 'Lucas_Morinio', 'Silenced Pistol', '2023-03-17 21:47:03'),
(383, 143, 45, 'NMS_FLIX', 'dob_lghaba', 'Silenced Pistol', '2023-03-17 22:23:52'),
(384, 45, 48, 'dob_lghaba', 'STEVAW_MARTINEZ', 'Fists', '2023-03-17 22:26:04'),
(385, 70, 125, 'Dyablo_Dr3awi', 'GOD_TIPO', 'Fists', '2023-03-18 14:31:50'),
(386, 14, 143, 'abdollah_algnawi', 'NMS_FLIX', 'Silenced Pistol', '2023-03-18 15:53:50'),
(387, 143, 14, 'NMS_FLIX', 'abdollah_algnawi', 'AK47', '2023-03-18 15:55:26'),
(388, 143, 70, 'NMS_FLIX', 'Dyablo_Dr3awi', 'Desert Eagle', '2023-03-18 15:58:09'),
(389, 143, 70, 'NMS_FLIX', 'Dyablo_Dr3awi', 'Desert Eagle', '2023-03-18 15:58:33'),
(390, 143, 70, 'NMS_FLIX', 'Dyablo_Dr3awi', 'Desert Eagle', '2023-03-18 15:58:41'),
(391, 143, 14, 'NMS_FLIX', 'abdollah_algnawi', 'Desert Eagle', '2023-03-18 15:59:05'),
(392, 163, 207, 'X_Mafia', 'Pablo_Walid', 'Silenced Pistol', '2023-03-18 16:14:15'),
(393, 163, 207, 'X_Mafia', 'Pablo_Walid', 'AK47', '2023-03-18 16:14:27'),
(394, 14, 70, 'abdollah_algnawi', 'Dyablo_Dr3awi', 'Silenced Pistol', '2023-03-18 16:16:08'),
(395, 70, 14, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'Silenced Pistol', '2023-03-18 16:17:04'),
(396, 14, 75, 'abdollah_algnawi', 'ALVARO_MORATA', 'Silenced Pistol', '2023-03-18 16:34:27'),
(397, 14, 75, 'abdollah_algnawi', 'ALVARO_MORATA', 'Silenced Pistol', '2023-03-18 16:35:36'),
(398, 70, 14, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'Fists', '2023-03-18 16:49:27'),
(399, 4, 5, 'Pablo_Walid', 'yasser_elallawi', 'AK47', '2023-03-19 21:22:53'),
(400, 4, 5, 'Pablo_Walid', 'yasser_elallawi', 'AK47', '2023-03-19 21:23:59'),
(401, 1, 13, 'psiko_boukhris', 'NMS_FLIX', 'Desert Eagle', '2023-03-19 22:28:44'),
(402, 13, 1, 'NMS_FLIX', 'psiko_boukhris', 'Silenced Pistol', '2023-03-19 22:29:30'),
(403, 13, 1, 'NMS_FLIX', 'psiko_boukhris', 'Silenced Pistol', '2023-03-19 22:31:40'),
(404, 13, 1, 'NMS_FLIX', 'psiko_boukhris', 'Silenced Pistol', '2023-03-19 22:33:41'),
(405, 13, 1, 'NMS_FLIX', 'psiko_boukhris', 'Silenced Pistol', '2023-03-19 22:34:35'),
(406, 1, 13, 'psiko_boukhris', 'NMS_FLIX', 'AK47', '2023-03-19 22:35:12'),
(407, 11, 1, 'GOD_TIPO', 'psiko_boukhris', 'AK47', '2023-03-19 22:36:17'),
(408, 11, 1, 'GOD_TIPO', 'psiko_boukhris', 'AK47', '2023-03-19 22:36:27'),
(409, 7, 13, 'Vini_Edrian', 'NMS_FLIX', 'Desert Eagle', '2023-03-19 22:38:59'),
(410, 1, 7, 'psiko_boukhris', 'Vini_Edrian', 'AK47', '2023-03-19 22:39:01'),
(411, 1, 7, 'psiko_boukhris', 'Vini_Edrian', 'AK47', '2023-03-19 22:43:22'),
(412, 1, 5, 'psiko_boukhris', 'yasser_elallawi', 'AK47', '2023-03-20 00:20:01'),
(413, 28, 1, 'Dyablo_Dr3awi', 'psiko_boukhris', 'Fists', '2023-03-20 00:44:41'),
(414, 1, 16, 'psiko_boukhris', 'James_Edrian', 'Desert Eagle', '2023-03-20 01:23:48'),
(415, 1, 16, 'psiko_boukhris', 'James_Edrian', 'Desert Eagle', '2023-03-20 01:24:17'),
(416, 1, 16, 'psiko_boukhris', 'James_Edrian', 'Desert Eagle', '2023-03-20 01:25:00'),
(417, 28, 16, 'Dyablo_Dr3awi', 'James_Edrian', 'Silenced Pistol', '2023-03-20 01:28:06'),
(418, 7, 16, 'Vini_Edrian', 'James_Edrian', 'Sawn-off Shotgun', '2023-03-20 01:28:37'),
(419, 7, 16, 'Vini_Edrian', 'James_Edrian', 'Sawn-off Shotgun', '2023-03-20 01:28:49'),
(420, 28, 7, 'Dyablo_Dr3awi', 'Vini_Edrian', 'TEC9', '2023-03-20 01:28:50'),
(421, 1, 16, 'psiko_boukhris', 'James_Edrian', 'Desert Eagle', '2023-03-20 01:31:34'),
(422, 1, 16, 'psiko_boukhris', 'James_Edrian', 'Desert Eagle', '2023-03-20 01:31:43'),
(423, 1, 16, 'psiko_boukhris', 'James_Edrian', 'AK47', '2023-03-20 01:33:11'),
(424, 1, 16, 'psiko_boukhris', 'James_Edrian', 'AK47', '2023-03-20 01:33:22'),
(425, 1, 16, 'psiko_boukhris', 'James_Edrian', 'AK47', '2023-03-20 01:33:30'),
(426, 1, 16, 'psiko_boukhris', 'James_Edrian', 'AK47', '2023-03-20 01:34:05'),
(427, 1, 16, 'psiko_boukhris', 'James_Edrian', 'AK47', '2023-03-20 01:34:13'),
(428, 1, 26, 'psiko_boukhris', 'Marroki_Crazy', 'Desert Eagle', '2023-03-20 01:53:25'),
(429, 1, 26, 'psiko_boukhris', 'Marroki_Crazy', 'Desert Eagle', '2023-03-20 01:53:57'),
(430, 1, 26, 'psiko_boukhris', 'Marroki_Crazy', 'Desert Eagle', '2023-03-20 01:54:19'),
(431, 1, 28, 'psiko_boukhris', 'Dyablo_Dr3awi', 'AK47', '2023-03-20 01:54:30'),
(432, 1, 26, 'psiko_boukhris', 'Marroki_Crazy', 'AK47', '2023-03-20 01:54:41'),
(433, 1, 26, 'psiko_boukhris', 'Marroki_Crazy', 'Desert Eagle', '2023-03-20 01:56:58'),
(434, 1, 29, 'psiko_boukhris', 'dob_lghaba', 'Silenced Pistol', '2023-03-20 05:15:12'),
(435, 1, 30, 'psiko_boukhris', 'CORLO_NEGRO', 'AK47', '2023-03-20 17:31:49'),
(436, 1, 30, 'psiko_boukhris', 'CORLO_NEGRO', 'AK47', '2023-03-20 17:32:40'),
(437, 1, 30, 'psiko_boukhris', 'CORLO_NEGRO', 'AK47', '2023-03-20 17:32:48'),
(438, 11, 4, 'GOD_TIPO', 'Pablo_Walid', 'Desert Eagle', '2023-03-20 18:18:21'),
(439, 12, 28, 'abdollah_algnawi', 'Dyablo_Dr3awi', 'Silenced Pistol', '2023-03-20 20:48:09'),
(440, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'TEC9', '2023-03-20 20:48:45'),
(441, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'Silenced Pistol', '2023-03-20 20:52:41'),
(442, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'Silenced Pistol', '2023-03-20 20:54:08'),
(443, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'Silenced Pistol', '2023-03-20 20:54:52'),
(444, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'Silenced Pistol', '2023-03-20 20:55:22'),
(445, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'TEC9', '2023-03-20 20:55:41'),
(446, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'AK47', '2023-03-20 21:18:28'),
(447, 1, 12, 'psiko_boukhris', 'abdollah_algnawi', 'AK47', '2023-03-20 21:18:42'),
(448, 8, 1, 'X_Mafia', 'psiko_boukhris', 'AK47', '2023-03-20 21:18:45'),
(449, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'AK47', '2023-03-20 21:21:52'),
(450, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'AK47', '2023-03-20 21:22:19'),
(451, 1, 12, 'psiko_boukhris', 'abdollah_algnawi', 'AK47', '2023-03-20 21:42:55'),
(452, 1, 12, 'psiko_boukhris', 'abdollah_algnawi', 'AK47', '2023-03-20 21:44:54'),
(453, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'AK47', '2023-03-20 21:48:48'),
(454, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'AK47', '2023-03-20 22:04:23'),
(455, 1, 12, 'psiko_boukhris', 'abdollah_algnawi', 'AK47', '2023-03-20 22:12:07'),
(456, 13, 33, 'NMS_FLIX', 'COROMBO_PABLO', 'AK47', '2023-03-20 23:04:25'),
(457, 1, 33, 'psiko_boukhris', 'COROMBO_PABLO', 'AK47', '2023-03-20 23:06:57'),
(458, 13, 12, 'NMS_FLIX', 'abdollah_algnawi', 'AK47', '2023-03-20 23:07:25'),
(459, 33, 12, 'COROMBO_PABLO', 'abdollah_algnawi', 'AK47', '2023-03-20 23:07:36'),
(460, 1, 12, 'psiko_boukhris', 'abdollah_algnawi', 'AK47', '2023-03-20 23:08:23'),
(461, 13, 33, 'NMS_FLIX', 'COROMBO_PABLO', 'AK47', '2023-03-20 23:08:45'),
(462, 13, 1, 'NMS_FLIX', 'psiko_boukhris', 'AK47', '2023-03-20 23:08:49'),
(463, 33, 12, 'COROMBO_PABLO', 'abdollah_algnawi', 'AK47', '2023-03-20 23:11:46'),
(464, 33, 12, 'COROMBO_PABLO', 'abdollah_algnawi', 'AK47', '2023-03-20 23:15:18'),
(465, 11, 12, 'GOD_TIPO', 'abdollah_algnawi', 'AK47', '2023-03-21 00:57:41'),
(466, 28, 12, 'Dyablo_Dr3awi', 'abdollah_algnawi', 'Fists', '2023-03-21 13:08:40'),
(467, 7, 28, 'Vini_Edrian', 'Dyablo_Dr3awi', 'Sawn-off Shotgun', '2023-03-21 18:40:05'),
(468, 28, 11, 'Dyablo_Dr3awi', 'GOD_TIPO', 'Knife', '2023-03-21 20:41:49'),
(469, 17, 1, 'JAIMSE_PALACIO', 'psiko_boukhris', 'Fists', '2023-03-22 05:08:46'),
(470, 1, 17, 'psiko_boukhris', 'JAIMSE_PALACIO', 'Fists', '2023-03-22 05:10:38'),
(471, 8, 5, 'X_Mafia', 'yasser_elallawi', 'Desert Eagle', '2023-03-22 13:39:16'),
(472, 8, 5, 'X_Mafia', 'yasser_elallawi', 'Desert Eagle', '2023-03-22 13:40:48'),
(473, 8, 5, 'X_Mafia', 'yasser_elallawi', 'AK47', '2023-03-22 14:01:37'),
(474, 8, 5, 'X_Mafia', 'yasser_elallawi', 'AK47', '2023-03-22 14:05:07'),
(475, 8, 5, 'X_Mafia', 'yasser_elallawi', 'AK47', '2023-03-22 14:06:41'),
(476, 8, 5, 'X_Mafia', 'yasser_elallawi', 'Desert Eagle', '2023-03-22 14:06:53'),
(477, 8, 19, 'X_Mafia', 'LAMAR_PABLOX', 'AK47', '2023-03-22 19:46:41'),
(478, 8, 28, 'X_Mafia', 'Dyablo_Dr3awi', 'AK47', '2023-03-22 20:20:10'),
(479, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'AK47', '2023-03-22 20:38:41'),
(480, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'AK47', '2023-03-22 20:38:53'),
(481, 28, 33, 'Dyablo_Dr3awi', 'COROMBO_PABLO', 'AK47', '2023-03-22 20:38:59'),
(482, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'Desert Eagle', '2023-03-22 20:39:43'),
(483, 12, 8, 'abdollah_algnawi', 'X_Mafia', 'Silenced Pistol', '2023-03-22 20:40:01'),
(484, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'Desert Eagle', '2023-03-22 20:40:17'),
(485, 8, 12, 'X_Mafia', 'abdollah_algnawi', 'AK47', '2023-03-22 20:40:37'),
(486, 11, 28, 'GOD_TIPO', 'Dyablo_Dr3awi', 'AK47', '2023-03-22 22:17:07'),
(487, 11, 28, 'GOD_TIPO', 'Dyablo_Dr3awi', 'AK47', '2023-03-22 22:17:53'),
(488, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 00:55:12'),
(489, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'AK47', '2023-03-23 00:57:41'),
(490, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Colt 45', '2023-03-23 01:05:51'),
(491, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Desert Eagle', '2023-03-23 01:06:39'),
(492, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 01:07:21'),
(493, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 01:07:54'),
(494, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Desert Eagle', '2023-03-23 01:08:24'),
(495, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 01:08:25'),
(496, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 01:08:44'),
(497, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Desert Eagle', '2023-03-23 01:08:45'),
(498, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Desert Eagle', '2023-03-23 01:09:02'),
(499, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 01:09:20'),
(500, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 01:09:34'),
(501, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Desert Eagle', '2023-03-23 01:10:05'),
(502, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Desert Eagle', '2023-03-23 01:10:14'),
(503, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-23 01:10:32'),
(504, 8, 28, 'X_Mafia', 'Dyablo_Dr3awi', 'Silenced Pistol', '2023-03-23 22:47:52'),
(505, 8, 23, 'X_Mafia', 'Felix_Jigo', 'Silenced Pistol', '2023-03-23 22:54:33'),
(506, 8, 23, 'X_Mafia', 'Felix_Jigo', 'Silenced Pistol', '2023-03-23 23:06:05'),
(507, 8, 28, 'X_Mafia', 'Dyablo_Dr3awi', 'Silenced Pistol', '2023-03-23 23:06:19'),
(508, 8, 5, 'X_Mafia', 'yasser_elallawi', 'Silenced Pistol', '2023-03-23 23:06:32'),
(509, 28, 23, 'Dyablo_Dr3awi', 'Felix_Jigo', 'Silenced Pistol', '2023-03-23 23:06:46'),
(510, 8, 57, 'X_Mafia', 'AMRO_MINE', 'Silenced Pistol', '2023-03-24 19:54:50'),
(511, 8, 57, 'X_Mafia', 'AMRO_MINE', 'Silenced Pistol', '2023-03-24 19:55:43'),
(512, 57, 8, 'AMRO_MINE', 'X_Mafia', 'Silenced Pistol', '2023-03-24 19:58:06'),
(513, 57, 8, 'AMRO_MINE', 'X_Mafia', 'Silenced Pistol', '2023-03-24 19:58:22'),
(514, 8, 57, 'X_Mafia', 'AMRO_MINE', 'Fists', '2023-03-24 20:02:50'),
(515, 57, 8, 'AMRO_MINE', 'X_Mafia', 'Silenced Pistol', '2023-03-24 20:03:17'),
(516, 8, 57, 'X_Mafia', 'AMRO_MINE', 'Silenced Pistol', '2023-03-24 20:03:59'),
(517, 57, 8, 'AMRO_MINE', 'X_Mafia', 'AK47', '2023-03-24 20:16:55'),
(518, 1, 57, 'psiko_boukhris', 'AMRO_MINE', 'AK47', '2023-03-25 00:42:29'),
(519, 1, 61, 'psiko_boukhris', 'Aymane_tobo', 'AK47', '2023-03-25 00:42:32'),
(520, 1, 61, 'psiko_boukhris', 'Aymane_tobo', 'AK47', '2023-03-25 00:56:54'),
(521, 8, 11, 'X_Mafia', 'GOD_TIPO', 'AK47', '2023-03-25 11:26:10'),
(522, 8, 11, 'X_Mafia', 'GOD_TIPO', 'AK47', '2023-03-25 11:27:19'),
(523, 8, 11, 'X_Mafia', 'GOD_TIPO', 'AK47', '2023-03-25 11:27:28'),
(524, 8, 11, 'X_Mafia', 'GOD_TIPO', 'AK47', '2023-03-25 11:31:59'),
(525, 24, 71, 'ROCH_PRAN', 'benzz_lcasawi', 'Desert Eagle', '2023-03-25 15:51:02'),
(526, 11, 71, 'GOD_TIPO', 'benzz_lcasawi', 'Desert Eagle', '2023-03-25 16:47:07'),
(527, 11, 71, 'GOD_TIPO', 'benzz_lcasawi', 'Desert Eagle', '2023-03-25 16:47:32'),
(528, 11, 71, 'GOD_TIPO', 'benzz_lcasawi', 'AK47', '2023-03-25 16:49:08'),
(529, 24, 11, 'ROCH_PRAN', 'GOD_TIPO', 'Desert Eagle', '2023-03-25 16:50:32'),
(530, 11, 24, 'GOD_TIPO', 'ROCH_PRAN', 'Desert Eagle', '2023-03-25 16:50:44'),
(531, 1, 77, 'psiko_boukhris', 'X_Mafia', 'Silenced Pistol', '2023-03-26 03:48:43'),
(532, 77, 24, 'X_Mafia', 'ROCH_PRAN', 'AK47', '2023-03-26 03:49:14'),
(533, 77, 1, 'X_Mafia', 'psiko_boukhris', 'AK47', '2023-03-26 03:49:14'),
(534, 77, 1, 'X_Mafia', 'psiko_boukhris', 'AK47', '2023-03-26 03:49:37'),
(535, 24, 77, 'ROCH_PRAN', 'X_Mafia', 'Explosion', '2023-03-26 03:49:38'),
(536, 77, 1, 'X_Mafia', 'psiko_boukhris', 'AK47', '2023-03-26 03:49:51'),
(537, 77, 24, 'X_Mafia', 'ROCH_PRAN', 'AK47', '2023-03-26 03:49:54'),
(538, 77, 24, 'X_Mafia', 'ROCH_PRAN', 'AK47', '2023-03-26 03:50:08'),
(539, 77, 1, 'X_Mafia', 'psiko_boukhris', 'AK47', '2023-03-26 04:00:07'),
(540, 77, 28, 'X_Mafia', 'Dyablo_Dr3awi', 'AK47', '2023-03-26 22:10:31'),
(541, 86, 67, 'Kvara_escobar', 'Cryston_Robert', 'Katana', '2023-03-26 22:54:08'),
(542, 28, 67, 'Dyablo_Dr3awi', 'Cryston_Robert', 'Silenced Pistol', '2023-03-26 22:56:17'),
(543, 1, 76, 'psiko_boukhris', 'AMRO_JOBINO', 'Silenced Pistol', '2023-03-27 17:04:00'),
(544, 1, 4, 'psiko_boukhris', 'Pablo_Walid', 'Silenced Pistol', '2023-03-27 17:14:58'),
(545, 1, 4, 'psiko_boukhris', 'Pablo_Walid', 'Silenced Pistol', '2023-03-27 17:16:43'),
(546, 4, 86, 'Pablo_Walid', 'Kvara_escobar', 'Katana', '2023-03-27 17:30:17'),
(547, 86, 4, 'Kvara_escobar', 'Pablo_Walid', 'Katana', '2023-03-27 17:35:41');

-- --------------------------------------------------------

--
-- Structure de la table `landobjects`
--

CREATE TABLE `landobjects` (
  `id` int(10) NOT NULL,
  `landid` int(10) DEFAULT NULL,
  `modelid` smallint(5) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `price` int(10) DEFAULT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `rot_x` float DEFAULT NULL,
  `rot_y` float DEFAULT NULL,
  `rot_z` float DEFAULT NULL,
  `door_opened` tinyint(1) DEFAULT '0',
  `door_locked` tinyint(1) DEFAULT '0',
  `move_x` float DEFAULT '0',
  `move_y` float DEFAULT '0',
  `move_z` float DEFAULT '0',
  `move_rx` float DEFAULT '0',
  `move_ry` float DEFAULT '0',
  `move_rz` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `lands`
--

CREATE TABLE `lands` (
  `id` int(10) NOT NULL,
  `ownerid` int(10) DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `price` int(10) DEFAULT '0',
  `level` int(10) DEFAULT '0',
  `min_x` float DEFAULT '0',
  `min_y` float DEFAULT '0',
  `max_x` float DEFAULT '0',
  `max_y` float DEFAULT '0',
  `height` float DEFAULT '0',
  `heighty` float DEFAULT '0',
  `heightx` float DEFAULT '0',
  `heightz` float DEFAULT '0',
  `lx` float NOT NULL,
  `ly` float NOT NULL,
  `lz` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `locations`
--

CREATE TABLE `locations` (
  `id` int(4) NOT NULL,
  `name` varchar(64) NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Contenu de la table `locations`
--

INSERT INTO `locations` (`id`, `name`, `pos_x`, `pos_y`, `pos_z`) VALUES
(1, 'Los Santos Police', 1553.1, -1675.32, 16.195);

-- --------------------------------------------------------

--
-- Structure de la table `log_admin`
--

CREATE TABLE `log_admin` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_admin`
--

INSERT INTO `log_admin` (`id`, `date`, `description`) VALUES
(5465, '2023-02-01 19:12:41', 'Kakashi_Johnson (uid: 1242) has made Kakashi_Johnson (uid: 1242) a gang moderator.'),
(5466, '2023-02-01 19:31:03', 'Karam_Billionaire (uid: 1243) has given Karam_Billionaire (uid: 1243) their own Bullet.'),
(5467, '2023-02-04 17:53:59', 'Uzi_Admin (uid: 1249) changed Uzi_Admin\'s (uid: 1249) name to Jason_Castellano.'),
(5468, '2023-02-06 11:11:21', 'Karam_Billionaire (uid: 1243) has made Karam_Billionaire (uid: 1243) a developer.'),
(5469, '2023-02-12 17:29:55', 'Reda_Tazi (uid: 1256) has made Reda_Tazi (uid: 1256) a faction moderator.'),
(5470, '2023-02-12 17:34:15', 'Reda_Tazi (uid: 1256) has used /givemoney to give $100000 to Karam_Billionaire1 (uid: 1258).'),
(5471, '2023-02-12 17:34:24', 'Reda_Tazi (uid: 1256) has used /givemoney to give $1000000 to Reda_Tazi (uid: 1256).'),
(5472, '2023-02-13 10:47:27', 'BOTI_LABANDA (uid: 1259) has made BOTI_LABANDA (uid: 1259) admin perosnnel.'),
(5473, '2023-02-13 10:50:31', 'AZIZOS_LM3ALEM (uid: 1260) has used /givemoney to give $10000000 to AZIZOS_LM3ALEM (uid: 1260).'),
(5474, '2023-02-13 13:05:16', 'KIRA_33 (uid: 1261) has made KIRA_33 (uid: 1261) a faction moderator.'),
(5475, '2023-02-15 20:07:47', 'Reda_Tazi (uid: 1256) set Reda_Tazi\'s (uid: 1256) phone number to 555'),
(5476, '2023-02-16 20:04:44', 'Reda_Tazi (uid: 1256) has given Reda_Tazi (uid: 1256) their own NRG-500.'),
(5477, '2023-02-17 09:06:48', 'Pablo_Hero (uid: 1264) has used /givemoney to give $5000000 to Pablo_Hero (uid: 1264).'),
(5478, '2023-02-17 15:20:40', 'Karam_Billionaire (uid: 1243) has used /givemoney to give $-500000000 to Karam_Billionaire (uid: 1243).'),
(5479, '2023-02-17 15:23:58', 'Karam_Billionaire (uid: 1243) has used /givemoney to give $300000 to Karam_Billionaire (uid: 1243).'),
(5480, '2023-02-17 15:24:02', 'Karam_Billionaire (uid: 1243) has used /givemoney to give $300000 to Karam_Billionaire (uid: 1243).'),
(5481, '2023-02-17 16:08:05', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $200 to Karam_Billionaire (uid: 1265).'),
(5482, '2023-02-17 16:09:53', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $300000 to Karam_Billionaire (uid: 1265).'),
(5483, '2023-02-17 16:10:50', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $300000 to Karam_Billionaire (uid: 1265).'),
(5484, '2023-02-17 16:12:59', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $300000 to Karam_Billionaire (uid: 1265).'),
(5485, '2023-02-17 19:21:23', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $24 to Karam_Billionaire (uid: 1265).'),
(5486, '2023-02-17 22:30:21', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $244444 to Karam_Billionaire (uid: 1265).'),
(5487, '2023-02-18 12:02:22', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $20000 to flooqi_bby (uid: 1269).'),
(5488, '2023-02-18 12:02:50', 'Karam_Billionaire (uid: 1265) has used /givemoney to give $20000 to Error_Herandez (uid: 1268).'),
(5489, '2023-02-18 12:06:19', 'Reda_Tazi (uid: 1266) has used /givemoney to give $10000 to Reda_Tazi (uid: 1266).'),
(5490, '2023-02-18 12:10:45', 'Reda_Tazi (uid: 1266) has made Reda_Tazi (uid: 1266) a faction moderator.'),
(5491, '2023-02-18 12:11:08', 'Reda_Tazi (uid: 1266) has used /givemoney to give $10000 to Reda_Tazi (uid: 1266).'),
(5492, '2023-02-18 12:15:16', 'Reda_Tazi (uid: 1266) has used /givemoney to give $1000000 to Reda_Tazi (uid: 1266).'),
(5493, '2023-02-18 18:47:49', 'KIRA_33 (uid: 1261) has made KIRA_33 (uid: 1261) a faction moderator.'),
(5494, '2023-02-18 19:13:45', 'Karam_Billionaire (uid: 1265) changed Karam_Billionaire\'s (uid: 1265) name to Michael_Zodiac.'),
(5495, '2023-02-18 19:42:53', 'ayoub_chlahbiy (uid: 1262) has used /givemoney to give $200000 to Ahmed_Benani (uid: 1270).'),
(5496, '2023-02-18 19:43:03', 'ayoub_chlahbiy (uid: 1262) has used /givemoney to give $200000 to ayoub_chlahbiy (uid: 1262).'),
(5497, '2023-02-18 19:57:45', 'HAMOCHI_SIROM (uid: 1271) has made HAMOCHI_SIROM (uid: 1271) a faction moderator.'),
(5498, '2023-02-19 14:10:05', 'Michael_Zodiac (uid: 1265) set Michael_Zodiac\'s (uid: 1265) phone number to 1'),
(5499, '2023-02-19 15:16:29', 'Reda_Tazi (uid: 1266) set Michael_Zodiac\'s (uid: 1265) phone number to 555'),
(5500, '2023-02-19 15:16:45', 'Reda_Tazi (uid: 1266) set Reda_Tazi\'s (uid: 1266) phone number to 999'),
(5501, '2023-02-19 17:35:58', 'Reda_Tazi (uid: 1266) has made Reda_Tazi (uid: 1266) a gang moderator.'),
(5502, '2023-02-20 14:59:49', 'Michael_Zodiac (uid: 1265) has made Michael_Zodiac (uid: 1265) a gang moderator.'),
(5503, '2023-02-20 15:00:03', 'Michael_Zodiac (uid: 1265) has made Michael_Zodiac (uid: 1265) a dynamic admin.'),
(5504, '2023-02-20 19:02:36', 'Pablo_Hero (uid: 1294) has used /givemoney to give $5000000 to Pablo_Hero (uid: 1294).'),
(5505, '2023-02-20 19:39:38', 'Michael_Zodiac (uid: 1265) has used /givemoney to give $2000000 to Michael_Zodiac (uid: 1265).'),
(5506, '2023-03-14 08:18:27', 'PEDRO_ADMIN (uid: 2) has given PEDRO_ADMIN (uid: 2) their own Sultan.'),
(5507, '2023-03-14 08:18:49', 'PEDRO_ADMIN (uid: 2) set PEDRO_ADMIN\'s (uid: 2) phone number to 1'),
(5508, '2023-03-14 10:58:11', 'PEDRO_ADMIN (uid: 2) has made PEDRO_ADMIN (uid: 2) a faction moderator.'),
(5509, '2023-03-14 10:58:19', 'PEDRO_ADMIN (uid: 2) has made PEDRO_ADMIN (uid: 2) a gang moderator.'),
(5510, '2023-03-14 15:26:54', 'Reda_Tazi (uid: 5) has made Reda_Tazi (uid: 5) a gang moderator.'),
(5511, '2023-03-14 15:33:18', 'PEDRO_ADMIN (uid: 2) has made POCO_LOCO (uid: 34) a gang moderator.'),
(5512, '2023-03-14 15:34:17', 'PEDRO_ADMIN (uid: 2) has used /givemoney to give $200000 to LilD_Kingos (uid: 24).'),
(5513, '2023-03-14 15:37:51', 'Reda_Tazi (uid: 5) has made Reda_Tazi (uid: 5) a faction moderator.'),
(5514, '2023-03-14 15:47:41', 'Smoke_Jigo (uid: 4) has made Bar9al_Admin (uid: 51) a gang moderator.'),
(5515, '2023-03-14 15:56:50', 'Young_Houssam (uid: 6) changed Young_Houssam\'s (uid: 6) name to X__2.'),
(5516, '2023-03-14 16:01:48', 'PEDRO_ADMIN (uid: 2) has used /givemoney to give $-500 to Joussi_Eltchapo (uid: 32).'),
(5517, '2023-03-14 16:04:52', 'PEDRO_ADMIN (uid: 2) has used /givemoney to give $-500 to Joussi_Eltchapo (uid: 32).'),
(5518, '2023-03-14 21:16:52', 'Unknown_ (uid: 94) has given Unknown_ (uid: 94) their own Super GT.'),
(5519, '2023-03-15 06:02:51', 'Alex_Cobra (uid: 1) has used /givemoney to give $400000 to Alex_Cobra (uid: 1).'),
(5520, '2023-03-15 12:09:12', 'Pedro_Admin (uid: 2) has used /givemoney to give $-500 to matouss_clean (uid: 121).'),
(5521, '2023-03-15 12:47:03', 'OUSSAMA_HARAKAT (uid: 68) has made OUSSAMA_HARAKAT (uid: 68) a faction moderator.'),
(5522, '2023-03-15 15:02:55', 'Reda_Tazi (uid: 5) has given Reda_Tazi (uid: 5) their own Whoopee.'),
(5523, '2023-03-15 22:10:52', 'Andrew_Tate (uid: 62) changed Andrew_Tate\'s (uid: 62) name to BO3O_ADMIN.'),
(5524, '2023-03-15 22:12:45', 'BO3O_ADMIN (uid: 62) changed BO3O_ADMIN\'s (uid: 62) name to Andrew_Tate.'),
(5525, '2023-03-15 23:18:31', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Jlabanda_MDFK (uid: 93).'),
(5526, '2023-03-15 23:18:41', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Felix_Jigo (uid: 98).'),
(5527, '2023-03-15 23:18:44', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to GOJO_ALGAHTANI (uid: 158).'),
(5528, '2023-03-15 23:18:47', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to GOJO_ALGAHTANI (uid: 158).'),
(5529, '2023-03-15 23:18:56', 'Pedro_Admin (uid: 2) has used /givemoney to give $-50000 to GOJO_ALGAHTANI (uid: 158).'),
(5530, '2023-03-15 23:18:58', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to abdollah_algnawi (uid: 14).'),
(5531, '2023-03-15 23:19:01', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Andrew_Tate (uid: 62).'),
(5532, '2023-03-15 23:19:05', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Vini_Edrian (uid: 23).'),
(5533, '2023-03-15 23:19:08', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Tyson_Choppa (uid: 37).'),
(5534, '2023-03-15 23:19:14', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Chliha_Olmhjob (uid: 110).'),
(5535, '2023-03-15 23:19:23', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to ALVARO_MORATA (uid: 75).'),
(5536, '2023-03-15 23:19:29', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Darwin_Watirson (uid: 106).'),
(5537, '2023-03-15 23:19:33', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Lmour_pholoko (uid: 76).'),
(5538, '2023-03-15 23:19:38', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Selfx_Tchapo (uid: 49).'),
(5539, '2023-03-15 23:19:41', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to SHARLOC_SMOKERS (uid: 154).'),
(5540, '2023-03-15 23:19:49', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to ROCH_PRAN (uid: 109).'),
(5541, '2023-03-15 23:20:21', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to ANAS_RAID (uid: 13).'),
(5542, '2023-03-15 23:20:35', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Limbo_sinyore (uid: 8).'),
(5543, '2023-03-15 23:20:41', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to hmed_twil (uid: 131).'),
(5544, '2023-03-15 23:20:50', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Nfha_Doo (uid: 30).'),
(5545, '2023-03-15 23:20:51', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to AYMEN_LME3DAWI (uid: 28).'),
(5546, '2023-03-15 23:20:56', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Jack_Hunter (uid: 120).'),
(5547, '2023-03-15 23:20:57', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Reda_Tazi (uid: 5).'),
(5548, '2023-03-15 23:21:00', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Yassir_sancho (uid: 135).'),
(5549, '2023-03-15 23:21:05', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Dyablo_Sbar (uid: 149).'),
(5550, '2023-03-15 23:21:07', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Pedro_Admin (uid: 2).'),
(5551, '2023-03-15 23:21:08', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Oualid_Jackson (uid: 85).'),
(5552, '2023-03-15 23:21:12', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to RAMZI__HAMO (uid: 150).'),
(5553, '2023-03-15 23:21:15', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to psiko_boukhris (uid: 54).'),
(5554, '2023-03-15 23:21:17', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to yasser_elallawi (uid: 122).'),
(5555, '2023-03-15 23:21:18', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Tyson_Choppa (uid: 37).'),
(5556, '2023-03-15 23:21:19', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to X_Mafia (uid: 56).'),
(5557, '2023-03-15 23:21:24', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Eazy_Gaviria (uid: 100).'),
(5558, '2023-03-15 23:21:32', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Lucas_Morinio (uid: 147).'),
(5559, '2023-03-15 23:21:59', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Leo_Garcia (uid: 155).'),
(5560, '2023-03-15 23:22:23', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Eazy_Gaviria (uid: 100).'),
(5561, '2023-03-15 23:22:24', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Jlabanda_MDFK (uid: 93).'),
(5562, '2023-03-15 23:22:30', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Nfha_Doo (uid: 30).'),
(5563, '2023-03-15 23:22:32', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Anas_Tali (uid: 63).'),
(5564, '2023-03-15 23:22:38', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to James_Edrian (uid: 36).'),
(5565, '2023-03-15 23:22:50', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Hamdi_johnson (uid: 156).'),
(5566, '2023-03-15 23:22:56', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to dob_lghaba (uid: 45).'),
(5567, '2023-03-15 23:23:05', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to Rachid_ekambi (uid: 17).'),
(5568, '2023-03-15 23:23:26', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to POP_SMOKE (uid: 157).'),
(5569, '2023-03-15 23:24:26', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to STEVAW_MARTINEZ (uid: 48).'),
(5570, '2023-03-15 23:25:34', 'Pedro_Admin (uid: 2) has used /givemoney to give $50000 to LUCAS_GUANTANAMO (uid: 40).'),
(5571, '2023-03-16 01:12:35', 'Andrew_Tate (uid: 62) changed Andrew_Tate\'s (uid: 62) name to ADMIN_BO3O.'),
(5572, '2023-03-16 02:57:15', 'ADMIN_BO3O (uid: 62) changed ADMIN_BO3O\'s (uid: 62) name to khadoj_.'),
(5573, '2023-03-16 02:58:45', 'khadoj_ (uid: 62) changed khadoj_\'s (uid: 62) name to ADMIN_BO3O.'),
(5574, '2023-03-16 03:01:24', 'Rachid_ekambi (uid: 17) fined Anas_Tali (uid: 63) for $500, reason: dyal midec'),
(5575, '2023-03-16 03:28:46', 'X_Mafia (uid: 56) changed X_Mafia\'s (uid: 56) name to Jason_Morinio.'),
(5576, '2023-03-16 13:04:57', 'Smoke_Jigo (uid: 4) has used /givemoney to give $800000 to Felix_Jigo (uid: 98).'),
(5577, '2023-03-16 13:10:45', 'GOD_TIPO (uid: 125) has made GOD_TIPO (uid: 125) a faction moderator.'),
(5578, '2023-03-16 13:43:49', 'Unknown_ (uid: 94) has used /givemoney to give $10000 to Unknown_ (uid: 94).'),
(5579, '2023-03-16 16:44:29', 'Smoke_Jigo (uid: 4) has given Felix_Jigo (uid: 98) their own Super GT.'),
(5580, '2023-03-16 16:46:07', 'Smoke_Jigo (uid: 4) has used /givemoney to give $150000 to Nfha_Doo (uid: 30).'),
(5581, '2023-03-16 16:46:24', 'Smoke_Jigo (uid: 4) has used /givemoney to give $50000 to Nfha_Doo (uid: 30).'),
(5582, '2023-03-16 16:47:23', 'Smoke_Jigo (uid: 4) has given Nfha_Doo (uid: 30) their own Flash.'),
(5583, '2023-03-17 16:58:08', 'X_Mafia (uid: 163) has given psiko_boukhris (uid: 54) their own Bullet.'),
(5584, '2023-03-17 18:05:28', 'Unknown_ (uid: 94) has used /givemoney to give $100000 to ADMIN_BO3O (uid: 62).'),
(5585, '2023-03-17 18:06:32', 'Unknown_ (uid: 94) has used /givemoney to give $-100000 to ADMIN_BO3O (uid: 62).'),
(5586, '2023-03-17 18:06:40', 'Unknown_ (uid: 94) has used /givemoney to give $100000 to Tyson_Choppa (uid: 37).'),
(5587, '2023-03-17 18:07:33', 'Unknown_ (uid: 94) has used /givemoney to give $50000 to Tyson_Choppa (uid: 37).'),
(5588, '2023-03-17 20:36:24', 'ADMIN_BO3O (uid: 62) changed ADMIN_BO3O\'s (uid: 62) name to andrew_Tat.'),
(5589, '2023-03-17 20:37:05', 'andrew_Tat (uid: 62) changed andrew_Tat\'s (uid: 62) name to Yuri_Mercedes.'),
(5590, '2023-03-17 22:37:37', 'X_Mafia (uid: 163) has used /givemoney to give $300 to X_Mafia (uid: 163).'),
(5591, '2023-03-18 15:08:11', 'GOD_TIPO (uid: 125) has used /givemoney to give $10000 to MADARA_33 (uid: 196).'),
(5592, '2023-03-18 15:08:16', 'GOD_TIPO (uid: 125) has used /givemoney to give $10000 to MADARA_33 (uid: 196).'),
(5593, '2023-03-18 16:52:58', 'X_Mafia (uid: 163) has used /givemoney to give $-1000 to X_Mafia (uid: 163).'),
(5594, '2023-03-18 16:53:09', 'X_Mafia (uid: 163) has used /givemoney to give $1000 to X_Mafia (uid: 163).'),
(5595, '2023-03-18 17:03:30', 'GOD_TIPO (uid: 125) has made GOD_TIPO (uid: 125) a dynamic admin.'),
(5596, '2023-03-18 17:21:09', 'X_Mafia (uid: 163) has used /givemoney to give $-100000 to Pablo_Walid (uid: 207).'),
(5597, '2023-03-19 21:57:03', 'X_Mafia (uid: 8) has given psiko_boukhris (uid: 1) their own Bullet.'),
(5598, '2023-03-19 22:09:11', 'GOD_TIPO (uid: 11) has made GOD_TIPO (uid: 11) a gang moderator.'),
(5599, '2023-03-19 22:10:09', 'GOD_TIPO (uid: 11) has made GOD_TIPO (uid: 11) a faction moderator.'),
(5600, '2023-03-19 22:10:28', 'GOD_TIPO (uid: 11) has made GOD_TIPO (uid: 11) admin perosnnel.'),
(5601, '2023-03-19 22:10:44', 'GOD_TIPO (uid: 11) has made GOD_TIPO (uid: 11) a developer.'),
(5602, '2023-03-19 22:38:24', 'Vini_Edrian (uid: 7) has made Vini_Edrian (uid: 7) a gang moderator.'),
(5603, '2023-03-19 22:50:54', 'Vini_Edrian (uid: 7) has given STEVAW_MARTINEZ (uid: 9) their own Huntley.'),
(5604, '2023-03-19 22:51:15', 'Vini_Edrian (uid: 7) has used /givemoney to give $400000 to STEVAW_MARTINEZ (uid: 9).'),
(5605, '2023-03-19 22:55:17', 'Vini_Edrian (uid: 7) has used /givemoney to give $2250000 to Vini_Edrian (uid: 7).'),
(5606, '2023-03-19 23:39:30', 'Vini_Edrian (uid: 7) has used /givemoney to give $1800000 to Vini_Edrian (uid: 7).'),
(5607, '2023-03-20 00:18:24', 'Vini_Edrian (uid: 7) has used /givemoney to give $175000 to psiko_boukhris (uid: 1).'),
(5608, '2023-03-20 00:21:11', 'Vini_Edrian (uid: 7) has used /givemoney to give $1000000 to psiko_boukhris (uid: 1).'),
(5609, '2023-03-20 00:30:22', 'Vini_Edrian (uid: 7) has used /givemoney to give $300000 to Dyablo_Dr3awi (uid: 28).'),
(5610, '2023-03-20 01:43:34', 'Vini_Edrian (uid: 7) has used /givemoney to give $100000 to Vini_Edrian (uid: 7).'),
(5611, '2023-03-20 01:43:51', 'Vini_Edrian (uid: 7) has used /givemoney to give $1000000 to Vini_Edrian (uid: 7).'),
(5612, '2023-03-20 01:49:00', 'Vini_Edrian (uid: 7) has used /givemoney to give $2000000 to psiko_boukhris (uid: 1).'),
(5613, '2023-03-20 14:50:54', 'GOD_TIPO (uid: 11) has used /givemoney to give $600000 to GOD_TIPO (uid: 11).'),
(5614, '2023-03-20 14:59:15', 'GOD_TIPO (uid: 11) has made GOD_TIPO (uid: 11) a dynamic admin.'),
(5615, '2023-03-20 15:23:54', 'GOD_TIPO (uid: 11) has given GOD_TIPO (uid: 11) their own Sultan.'),
(5616, '2023-03-20 18:38:46', 'GOD_TIPO (uid: 11) has given GOD_TIPO (uid: 11) their own Turismo.'),
(5617, '2023-03-20 18:48:17', 'GOD_TIPO (uid: 11) has given GOD_TIPO (uid: 11) their own Euros.'),
(5618, '2023-03-21 00:46:37', 'GOD_TIPO (uid: 11) set abdollah_algnawi\'s (uid: 12) phone number to 112'),
(5619, '2023-03-21 18:33:42', 'Vini_Edrian (uid: 7) has given Vini_Edrian (uid: 7) their own Bullet.'),
(5620, '2023-03-22 13:34:40', 'X_Mafia (uid: 8) has removed X_Mafia\'s (uid: 8) gang moderator status.'),
(5621, '2023-03-22 13:34:45', 'X_Mafia (uid: 8) has made X_Mafia (uid: 8) a gang moderator.'),
(5622, '2023-03-22 13:37:59', 'X_Mafia (uid: 8) has used /givemoney to give $-50000 to yasser_elallawi (uid: 5).'),
(5623, '2023-03-22 19:30:06', 'X_Mafia (uid: 8) has made X_Mafia (uid: 8) a gang moderator.'),
(5624, '2023-03-22 19:43:08', 'X_Mafia (uid: 8) has made X_Mafia (uid: 8) a gang moderator.'),
(5625, '2023-03-22 22:19:29', 'GOD_TIPO (uid: 11) has made Dyablo_Dr3awi (uid: 28) a gang moderator.'),
(5626, '2023-03-22 22:29:22', 'GOD_TIPO (uid: 11) has made Dyablo_Dr3awi (uid: 28) a developer.'),
(5627, '2023-03-23 19:23:40', 'X_Mafia (uid: 8) has used /givemoney to give $-100000000 to X_Mafia (uid: 8).'),
(5628, '2023-03-23 19:23:52', 'X_Mafia (uid: 8) has used /givemoney to give $-100000000 to X_Mafia (uid: 8).'),
(5629, '2023-03-23 19:23:56', 'X_Mafia (uid: 8) has used /givemoney to give $-1215752192 to X_Mafia (uid: 8).'),
(5630, '2023-03-23 19:27:34', 'X_Mafia (uid: 8) has used /givemoney to give $100000 to X_Mafia (uid: 8).'),
(5631, '2023-03-23 19:27:36', 'X_Mafia (uid: 8) has used /givemoney to give $100000 to X_Mafia (uid: 8).'),
(5632, '2023-03-23 19:27:38', 'X_Mafia (uid: 8) has used /givemoney to give $100000 to X_Mafia (uid: 8).'),
(5633, '2023-03-23 19:27:41', 'X_Mafia (uid: 8) has used /givemoney to give $10000000 to X_Mafia (uid: 8).'),
(5634, '2023-03-23 19:27:49', 'X_Mafia (uid: 8) has used /givemoney to give $100000000 to X_Mafia (uid: 8).'),
(5635, '2023-03-23 19:27:56', 'X_Mafia (uid: 8) has used /givemoney to give $50000000 to X_Mafia (uid: 8).'),
(5636, '2023-03-23 19:28:01', 'X_Mafia (uid: 8) has used /givemoney to give $50000000 to X_Mafia (uid: 8).'),
(5637, '2023-03-23 19:28:08', 'X_Mafia (uid: 8) has used /givemoney to give $500000000 to X_Mafia (uid: 8).'),
(5638, '2023-03-23 19:28:22', 'X_Mafia (uid: 8) has used /givemoney to give $-500000 to X_Mafia (uid: 8).'),
(5639, '2023-03-23 19:29:25', 'X_Mafia (uid: 8) has used /givemoney to give $-500000 to X_Mafia (uid: 8).'),
(5640, '2023-03-23 19:29:32', 'X_Mafia (uid: 8) has used /givemoney to give $-500000 to X_Mafia (uid: 8).'),
(5641, '2023-03-23 19:29:41', 'X_Mafia (uid: 8) has used /givemoney to give $-5000000 to X_Mafia (uid: 8).'),
(5642, '2023-03-23 19:29:53', 'X_Mafia (uid: 8) has used /givemoney to give $-5000000 to X_Mafia (uid: 8).'),
(5643, '2023-03-23 19:30:03', 'X_Mafia (uid: 8) has used /givemoney to give $-5000000 to X_Mafia (uid: 8).'),
(5644, '2023-03-23 19:30:07', 'X_Mafia (uid: 8) has used /givemoney to give $-5000000 to X_Mafia (uid: 8).'),
(5645, '2023-03-23 19:30:14', 'X_Mafia (uid: 8) has used /givemoney to give $-50000000 to X_Mafia (uid: 8).'),
(5646, '2023-03-23 19:31:23', 'X_Mafia (uid: 8) has used /givemoney to give $-50000000 to X_Mafia (uid: 8).'),
(5647, '2023-03-23 19:31:46', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5648, '2023-03-23 19:31:50', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5649, '2023-03-23 19:31:57', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5650, '2023-03-23 19:31:58', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5651, '2023-03-23 19:32:01', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5652, '2023-03-23 19:32:13', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5653, '2023-03-23 19:32:30', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5654, '2023-03-23 19:32:48', 'X_Mafia (uid: 8) has used /givemoney to give $5000000 to X_Mafia (uid: 8).'),
(5655, '2023-03-23 21:10:31', 'Pedro_Admin (uid: 54) has made Pedro_Admin (uid: 54) a faction moderator.'),
(5656, '2023-03-23 23:02:21', 'X_Mafia (uid: 8) has given X_Mafia (uid: 8) their own Bullet.'),
(5657, '2023-03-24 14:31:16', 'Dyablo_Dr3awi (uid: 28) has given Dyablo_Dr3awi (uid: 28) their own NRG-500.'),
(5658, '2023-03-24 14:32:44', 'Dyablo_Dr3awi (uid: 28) has given Dyablo_Dr3awi (uid: 28) their own NRG-500.'),
(5659, '2023-03-25 01:36:03', 'X_Mafia (uid: 8) has made X_Mafia (uid: 8) a gang moderator.'),
(5660, '2023-03-25 14:13:38', 'X_Mafia (uid: 8) has made X_Mafia (uid: 8) a gang moderator.'),
(5661, '2023-03-25 15:40:38', 'ROCH_PRAN (uid: 24) has used /givemoney to give $1661992960 to ROCH_PRAN (uid: 24).'),
(5662, '2023-03-25 16:33:21', 'ROCH_PRAN (uid: 24) has used /givemoney to give $600000 to benzz_lcasawi (uid: 71).'),
(5663, '2023-03-25 17:05:53', 'GOD_TIPO (uid: 11) locked benzz_lcasawi\'s account.'),
(5664, '2023-03-25 17:06:47', 'GOD_TIPO (uid: 11) unlocked benzz_lcasawi\'s account.'),
(5665, '2023-03-25 20:46:46', 'X_Mafia (uid: 8) has used /givemoney to give $10000 to Cheblyyy_Baggio (uid: 73).'),
(5666, '2023-03-26 01:41:25', 'X_Mafia (uid: 8) has made X_Mafia (uid: 8) a gang moderator.'),
(5667, '2023-03-26 02:08:29', 'X_Mafia (uid: 8) changed X_Mafia\'s (uid: 8) name to X_Mafiat.'),
(5668, '2023-03-26 16:14:20', 'Dyablo_Dr3awi (uid: 28) has used /givemoney to give $-810000000 to Dyablo_Dr3awi (uid: 28).'),
(5669, '2023-03-26 16:14:40', 'Dyablo_Dr3awi (uid: 28) has used /givemoney to give $-810000000 to Dyablo_Dr3awi (uid: 28).'),
(5670, '2023-03-26 16:15:22', 'Dyablo_Dr3awi (uid: 28) has used /givemoney to give $810000000 to Dyablo_Dr3awi (uid: 28).'),
(5671, '2023-03-26 21:33:19', 'X_Mafia (uid: 77) has used /givemoney to give $10000 to Kvara_escobar (uid: 86).'),
(5672, '2023-03-26 21:46:52', 'X_Mafia (uid: 77) has used /givemoney to give $100000 to GREN_BTRIK (uid: 87).'),
(5673, '2023-03-26 21:51:00', 'X_Mafia (uid: 77) has used /givemoney to give $100000 to GREN_BTRIK (uid: 87).'),
(5674, '2023-03-26 21:52:19', 'X_Mafia (uid: 77) has used /givemoney to give $100000 to GREN_BTRIK (uid: 87).'),
(5675, '2023-03-27 17:55:45', 'X_Mafia (uid: 77) has used /givemoney to give $1000 to AMRO_JOBINO (uid: 76).');

-- --------------------------------------------------------

--
-- Structure de la table `log_bans`
--

CREATE TABLE `log_bans` (
  `id` int(10) NOT NULL,
  `uid` int(10) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_bans`
--

INSERT INTO `log_bans` (`id`, `uid`, `date`, `description`) VALUES
(1, 142, '2023-03-15 17:47:04', 'X__2 (IP: 41.250.123.41) was banned by Rex, reason: Airbreak'),
(2, 153, '2023-03-15 22:08:29', 'Yasser_Zineddine (IP: 41.250.121.97) was banned by Rex, reason: Airbreak'),
(3, 45, '2023-03-16 00:16:25', 'dob_lghaba (IP: 196.89.38.66) was banned by psiko_boukhris, reason: DM (3/3 warnings)'),
(4, 48, '2023-03-16 08:08:05', 'STEVAW_MARTINEZ (IP: 196.74.232.227) was banned by Rex, reason: Teleport hacks'),
(5, 166, '2023-03-16 12:07:52', 'White_Flash (IP: 105.71.147.148) was banned by Rex, reason: Weapon hacks (Silenced Pistol)'),
(6, 153, '2023-03-16 12:32:25', 'Yasser_Zineddine (IP: 89.95.108.188) was banned by Rex, reason: Airbreak'),
(7, 157, '2023-03-16 13:11:09', 'POP_SMOKE (IP: 196.64.223.8) was banned by Rex, reason: Weapon hacks (Silenced Pistol)'),
(8, 169, '2023-03-16 16:04:10', 'HOUSSAM_KABBACHE (IP: 41.143.55.8) was banned by Rex, reason: Weapon hacks (M4)'),
(9, 49, '2023-03-16 16:51:37', 'Selfx_Tchapo (IP: 196.115.46.208) was banned by X_Mafia, reason: hack'),
(10, 187, '2023-03-16 20:22:17', 'Vigas_Omerta (IP: 105.72.59.250) was banned by Rex, reason: Weapon hacks (Colt 45)'),
(11, 178, '2023-03-16 20:45:37', 'HADES_SMOKERS (IP: 196.65.166.188) was banned by psiko_boukhris, reason: DM (3/3 warnings)'),
(12, 121, '2023-03-17 13:03:27', 'matouss_clean (IP: 197.253.198.21) was banned by Rex, reason: Airbreak'),
(13, 8, '2023-03-17 15:02:38', 'Limbo_sinyore (IP: 196.117.3.94) was banned by psiko_boukhris, reason: DM (3/3 warnings)'),
(14, 6, '2023-03-20 15:19:40', 'PABLO_PICASO (IP: 41.249.150.0) was banned by Rex, reason: Teleport hacks'),
(15, 43, '2023-03-21 13:35:06', 'SALIM_LUCAS (IP: 196.112.130.116) was banned by Rex, reason: Weapon hacks (Silenced Pistol)'),
(16, 47, '2023-03-22 05:03:53', 'Snop_Amar (IP: 105.66.128.235) was banned by psiko_boukhris, reason: DM (3/3 warnings)'),
(17, 72, '2023-03-25 16:56:46', 'hmed_twil (IP: 196.118.102.132) was banned by Rex, reason: Weapon hacks (Rocket Launcher)'),
(18, 88, '2023-03-27 01:59:57', 'BADR_PEDRI (IP: 105.155.18.50) was banned by Rex, reason: Teleport hacks');

-- --------------------------------------------------------

--
-- Structure de la table `log_cheat`
--

CREATE TABLE `log_cheat` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_cheat`
--

INSERT INTO `log_cheat` (`id`, `date`, `description`) VALUES
(1, '2023-02-17 16:05:22', 'Karam_Billionaire (uid: 1265) possibly teleport hacked (distance: 521.4)'),
(2, '2023-02-17 22:50:06', 'Sirom_draga (uid: 1267) possibly teleport hacked (distance: 521.6)'),
(3, '2023-02-17 22:55:53', 'Sirom_draga (uid: 0) possibly teleport hacked (distance: 705.5)'),
(4, '2023-02-18 20:18:14', 'wolf_kim (uid: 1272) possibly hacked armor. (old: 0.00, new: 100.00)'),
(5, '2023-02-19 14:09:10', 'Michael_Zodiac (uid: 0) possibly teleport hacked (distance: 1130.2)'),
(6, '2023-02-19 20:24:26', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 1170.5)'),
(7, '2023-02-19 20:47:32', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 729.5)'),
(8, '2023-02-19 21:31:39', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 720.5)'),
(9, '2023-02-19 21:49:54', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 587.3)'),
(10, '2023-02-19 22:27:01', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 800.0)'),
(11, '2023-02-20 01:23:26', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 707.4)'),
(12, '2023-02-20 01:32:51', 'Bahim_Qimroun (uid: 1280) possibly teleport hacked (distance: 126.3)'),
(13, '2023-02-20 01:36:08', 'Bahim_Qimroun (uid: 1280) possibly teleport hacked (distance: 1929.0)'),
(14, '2023-02-20 01:36:25', 'Bahim_Qimroun (uid: 1280) possibly teleport hacked (distance: 2406.9)'),
(15, '2023-02-20 07:31:10', 'Michael_Zodiac (uid: 0) possibly teleport hacked (distance: 720.5)'),
(16, '2023-02-20 10:56:59', 'Michael_Zodiac (uid: 0) possibly teleport hacked (distance: 3533.8)'),
(17, '2023-02-20 11:03:55', 'Enzo_Gabo (uid: 0) possibly teleport hacked (distance: 593.2)'),
(18, '2023-02-20 11:07:51', 'Enzo_Gabo (uid: 0) possibly teleport hacked (distance: 3533.8)'),
(19, '2023-02-20 11:11:05', 'Josuke_Higashikata (uid: 0) possibly teleport hacked (distance: 707.2)'),
(20, '2023-02-20 12:23:16', 'POP_SMOKE (uid: 1291) possibly teleport hacked (distance: 3873.4)'),
(21, '2023-02-20 12:29:54', 'Nicholas_Democritus (uid: 0) possibly teleport hacked (distance: 4041.2)'),
(22, '2023-02-20 17:14:06', 'Enzo_Gabo (uid: 0) possibly teleport hacked (distance: 932.8)'),
(23, '2023-02-20 17:16:31', 'Enzo_Gabo (uid: 0) possibly teleport hacked (distance: 780.8)'),
(24, '2023-02-20 17:17:56', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 776.3)'),
(25, '2023-02-20 17:23:46', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 4679.4)'),
(26, '2023-02-20 17:28:35', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 4689.4)'),
(27, '2023-02-20 18:12:45', 'AYMANE_TOBO (uid: 0) possibly teleport hacked (distance: 707.1)'),
(28, '2023-02-20 18:20:32', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 4679.4)'),
(29, '2023-02-20 18:21:51', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 4672.1)'),
(30, '2023-02-20 18:24:35', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 581.2)'),
(31, '2023-02-20 18:28:44', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 555.5)'),
(32, '2023-02-20 18:58:43', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 4039.0)'),
(33, '2023-02-20 19:14:05', 'Bahim_Qimroun (uid: 1280) possibly teleport hacked (distance: 2885.7)'),
(34, '2023-02-21 01:18:34', 'HAMOCHI_SIROM (uid: 0) possibly teleport hacked (distance: 4039.1)'),
(35, '2023-02-21 01:19:40', 'LKHRAZ_ML (uid: 0) possibly teleport hacked (distance: 4035.5)'),
(36, '2023-02-21 01:31:33', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 3538.8)'),
(37, '2023-02-21 01:37:17', 'Bahim_Qimroun (uid: 0) possibly teleport hacked (distance: 3433.6)'),
(38, '2023-02-21 01:37:45', 'LKHRAZ_ML (uid: 1297) possibly teleport hacked (distance: 114.9)'),
(39, '2023-02-21 01:37:49', 'LKHRAZ_ML (uid: 1297) possibly teleport hacked (distance: 115.6)'),
(40, '2023-02-21 01:37:53', 'LKHRAZ_ML (uid: 1297) possibly teleport hacked (distance: 115.7)'),
(41, '2023-02-21 01:39:03', 'LKHRAZ_ML (uid: 1297) possibly teleport hacked (distance: 115.3)'),
(42, '2023-02-21 01:45:13', 'LKHRAZ_ML (uid: 1297) possibly used airbreak.'),
(43, '2023-02-21 01:48:33', 'LKHRAZ_ML (uid: 0) possibly teleport hacked (distance: 564.5)'),
(44, '2023-02-21 01:48:33', 'HAMOCHI_SIROM (uid: 0) possibly teleport hacked (distance: 504.1)'),
(45, '2023-02-21 01:51:00', 'HAMOCHI_SIROM (uid: 0) possibly teleport hacked (distance: 503.0)'),
(46, '2023-02-21 01:51:46', 'LKHRAZ_ML (uid: 0) possibly teleport hacked (distance: 4932.7)'),
(47, '2023-02-21 01:53:37', 'LKHRAZ_ML (uid: 0) possibly teleport hacked (distance: 580.4)'),
(48, '2023-02-21 02:18:47', 'LKHRAZ_ML (uid: 0) possibly teleport hacked (distance: 863.0)'),
(49, '2023-02-21 02:24:25', 'HAMOCHI_SIROM (uid: 0) possibly teleport hacked (distance: 711.1)'),
(50, '2023-02-22 15:40:03', 'DX_Padrio (uid: 1299) possibly used airbreak.'),
(51, '2023-02-22 15:40:29', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 629.3)'),
(52, '2023-02-22 15:42:20', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 473.5)'),
(53, '2023-02-22 15:47:25', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 641.9)'),
(54, '2023-02-22 15:54:03', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 562.5)'),
(55, '2023-02-22 17:53:44', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 644.3)'),
(56, '2023-02-22 17:57:06', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 2559.9)'),
(57, '2023-02-22 19:36:58', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 940.3)'),
(58, '2023-02-22 19:38:34', 'DX_Padrio (uid: 0) possibly teleport hacked (distance: 2559.6)'),
(59, '2023-03-14 15:22:42', 'Jimmy_Holmes (uid: 16) possibly used airbreak.'),
(60, '2023-03-14 15:26:17', 'LilD_Kingos (uid: 24) possibly teleport hacked (distance: 128.0)'),
(61, '2023-03-14 15:38:53', 'ZIZWAR_7M7 (uid: 26) possibly teleport hacked (distance: 1928.6)'),
(62, '2023-03-14 15:39:53', 'BOB_PABLO (uid: 0) possibly teleport hacked (distance: 485.0)'),
(63, '2023-03-14 15:40:45', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 753.3)'),
(64, '2023-03-14 15:42:51', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 417.0)'),
(65, '2023-03-14 15:42:58', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 288.6)'),
(66, '2023-03-14 15:46:44', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 772.1)'),
(67, '2023-03-14 15:47:35', 'YASSINE_GUZMAN (uid: 53) possibly teleport hacked (distance: 974.2)'),
(68, '2023-03-14 15:52:16', 'Nfha_Doo (uid: 30) possibly teleport hacked (distance: 3802.1)'),
(69, '2023-03-14 15:56:19', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 767.3)'),
(70, '2023-03-14 15:59:11', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 814.1)'),
(71, '2023-03-14 16:03:21', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2102.2)'),
(72, '2023-03-14 16:07:49', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2347.3)'),
(73, '2023-03-14 16:12:11', 'Kaspre_Edrian (uid: 0) possibly teleport hacked (distance: 560.7)'),
(74, '2023-03-14 16:13:32', 'PROF_TIMSA7 (uid: 59) possibly teleport hacked (distance: 3038.2)'),
(75, '2023-03-14 16:14:22', 'LilD_Kingos (uid: 24) possibly used airbreak.'),
(76, '2023-03-14 16:15:54', 'Ilyass_Berada (uid: 65) possibly teleport hacked (distance: 417.0)'),
(77, '2023-03-14 16:22:28', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 3815.4)'),
(78, '2023-03-14 16:25:13', 'abdollah_algnawi (uid: 14) possibly teleport hacked (distance: 484.8)'),
(79, '2023-03-14 16:26:14', 'AJAXX_SIPO (uid: 50) possibly teleport hacked (distance: 3801.8)'),
(80, '2023-03-14 16:27:34', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 1117.7)'),
(81, '2023-03-14 16:30:24', 'Ilyass_Berada (uid: 65) possibly teleport hacked (distance: 3678.7)'),
(82, '2023-03-14 16:45:18', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(83, '2023-03-14 16:57:19', 'Anas_Sousi (uid: 0) possibly teleport hacked (distance: 1750.2)'),
(84, '2023-03-14 16:58:01', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 350.1 km/h'),
(85, '2023-03-14 16:58:02', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 365.1 km/h'),
(86, '2023-03-14 17:05:14', 'PROF_TIMSA7 (uid: 59) possibly teleport hacked (distance: 1953.6)'),
(87, '2023-03-14 17:11:07', 'Vini_Edrian (uid: 23) possibly teleport hacked (distance: 120.8)'),
(88, '2023-03-14 17:15:40', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 4697.3)'),
(89, '2023-03-14 17:19:22', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 1100.3)'),
(90, '2023-03-14 17:22:13', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 1074.9)'),
(91, '2023-03-14 17:24:56', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 1002.4)'),
(92, '2023-03-14 17:28:50', 'Anwar_Mohamed (uid: 60) possibly teleport hacked (distance: 141.0)'),
(93, '2023-03-14 17:32:50', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 918.2)'),
(94, '2023-03-14 17:34:39', 'PROF_TIMSA7 (uid: 59) possibly teleport hacked (distance: 3327.8)'),
(95, '2023-03-14 17:35:29', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 705.0)'),
(96, '2023-03-14 17:35:49', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 932.6)'),
(97, '2023-03-14 17:37:34', 'Rachid_ekambi (uid: 17) possibly teleport hacked (distance: 172.2)'),
(98, '2023-03-14 17:41:08', 'PROF_TIMSA7 (uid: 59) possibly teleport hacked (distance: 3309.7)'),
(99, '2023-03-14 18:00:43', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3598.5)'),
(100, '2023-03-14 18:05:37', 'LUCAS_GUANTANAMO (uid: 40) possibly teleport hacked (distance: 3544.6)'),
(101, '2023-03-14 18:16:12', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1390.7)'),
(102, '2023-03-14 18:20:00', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 216.9)'),
(103, '2023-03-14 18:29:03', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 116.3)'),
(104, '2023-03-14 18:35:35', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3435.8)'),
(105, '2023-03-14 18:40:02', 'ZIZWAR_7M7 (uid: 26) possibly teleport hacked (distance: 3187.3)'),
(106, '2023-03-14 18:40:09', 'X_Mafia (uid: 56) possibly teleport hacked (distance: 5557.0)'),
(107, '2023-03-14 18:40:38', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 1289.1)'),
(108, '2023-03-14 18:42:48', 'ZIZWAR_7M7 (uid: 26) possibly teleport hacked (distance: 118.8)'),
(109, '2023-03-14 18:45:09', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(110, '2023-03-14 18:45:11', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(111, '2023-03-14 18:45:12', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(112, '2023-03-14 18:45:14', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(113, '2023-03-14 18:45:16', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(114, '2023-03-14 18:45:19', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(115, '2023-03-14 18:45:46', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(116, '2023-03-14 19:01:16', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(117, '2023-03-14 19:03:21', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 829.2)'),
(118, '2023-03-14 19:08:37', 'Lmour_pholoko (uid: 76) possibly teleport hacked (distance: 2213.0)'),
(119, '2023-03-14 19:09:49', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2215.8)'),
(120, '2023-03-14 19:10:32', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2030.9)'),
(121, '2023-03-14 19:11:15', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 2259.0)'),
(122, '2023-03-14 19:15:00', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2193.3)'),
(123, '2023-03-14 19:15:44', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2139.5)'),
(124, '2023-03-14 19:16:46', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2168.4)'),
(125, '2023-03-14 19:17:34', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2141.6)'),
(126, '2023-03-14 19:20:05', 'ZIZWAR_7M7 (uid: 26) possibly used airbreak.'),
(127, '2023-03-14 19:20:32', 'Vini_Edrian (uid: 23) possibly used airbreak.'),
(128, '2023-03-14 19:28:40', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 3570.7)'),
(129, '2023-03-14 19:30:55', 'LUCAS_GUANTANAMO (uid: 40) possibly teleport hacked (distance: 5422.4)'),
(130, '2023-03-14 19:43:19', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1051.4)'),
(131, '2023-03-14 20:02:23', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 179.4)'),
(132, '2023-03-14 20:07:11', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 966.8)'),
(133, '2023-03-14 20:08:35', 'Mohamed_gostavo (uid: 0) possibly teleport hacked (distance: 4042.3)'),
(134, '2023-03-14 20:13:46', 'Mistro_Roberto (uid: 42) possibly used airbreak.'),
(135, '2023-03-14 20:13:46', 'Mistro_Roberto (uid: 42) possibly used airbreak.'),
(136, '2023-03-14 20:25:23', 'Ilyass_Berada (uid: 65) possibly teleport hacked (distance: 4493.7)'),
(137, '2023-03-14 20:25:47', 'Ilyass_Berada (uid: 65) possibly teleport hacked (distance: 4493.7)'),
(138, '2023-03-14 20:30:19', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 2931.5)'),
(139, '2023-03-14 20:52:57', 'Vini_Edrian (uid: 23) possibly teleport hacked (distance: 2359.9)'),
(140, '2023-03-14 21:05:19', 'Jlabanda_MDFK (uid: 93) possibly teleport hacked (distance: 110.6)'),
(141, '2023-03-14 21:30:04', 'Simo_gostavo (uid: 89) possibly teleport hacked (distance: 364.4)'),
(142, '2023-03-14 21:32:33', 'Simo_gostavo (uid: 89) possibly teleport hacked (distance: 398.0)'),
(143, '2023-03-14 21:33:05', 'Simo_gostavo (uid: 89) possibly teleport hacked (distance: 145.7)'),
(144, '2023-03-14 21:39:35', 'LHAJ_SFIRAA (uid: 97) possibly teleport hacked (distance: 424.6)'),
(145, '2023-03-14 21:40:04', 'LHAJ_SFIRAA (uid: 0) possibly teleport hacked (distance: 589.7)'),
(146, '2023-03-14 21:40:43', 'LHAJ_SFIRAA (uid: 97) possibly teleport hacked (distance: 401.9)'),
(147, '2023-03-14 21:45:59', 'Sami_Alpatchino (uid: 52) possibly used airbreak.'),
(148, '2023-03-14 21:47:07', 'DRISS_ESCOBAR (uid: 86) possibly used airbreak.'),
(149, '2023-03-14 21:57:53', 'Eazy_Gaviria (uid: 100) possibly teleport hacked (distance: 506.5)'),
(150, '2023-03-14 21:58:25', 'Rachid_ekambi (uid: 17) possibly teleport hacked (distance: 109.0)'),
(151, '2023-03-14 22:02:35', 'TONIKE_BIMO (uid: 99) possibly teleport hacked (distance: 2850.9)'),
(152, '2023-03-14 22:14:50', 'LAMAR_PABLOX (uid: 12) possibly teleport hacked (distance: 117.4)'),
(153, '2023-03-14 22:15:06', 'LAMAR_PABLOX (uid: 12) possibly teleport hacked (distance: 119.4)'),
(154, '2023-03-14 22:15:30', 'LAMAR_PABLOX (uid: 12) possibly teleport hacked (distance: 4682.5)'),
(155, '2023-03-14 22:18:20', 'Eazy_Gaviria (uid: 100) possibly teleport hacked (distance: 907.7)'),
(156, '2023-03-14 22:34:55', 'AYMEN_LME3DAWI (uid: 28) possibly used airbreak.'),
(157, '2023-03-14 22:49:07', 'Si_Drogba (uid: 102) possibly teleport hacked (distance: 974.2)'),
(158, '2023-03-14 22:49:17', 'Si_Drogba (uid: 102) possibly teleport hacked (distance: 521.4)'),
(159, '2023-03-14 23:05:58', 'Ismail_guzmane (uid: 105) possibly teleport hacked (distance: 1259.4)'),
(160, '2023-03-14 23:06:09', 'Vane_Slawi (uid: 104) possibly used airbreak.'),
(161, '2023-03-14 23:16:05', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 3774.0)'),
(162, '2023-03-14 23:49:03', 'Snop_Doge (uid: 112) possibly used airbreak.'),
(163, '2023-03-14 23:55:29', 'salto_bikit (uid: 88) possibly teleport hacked (distance: 3389.0)'),
(164, '2023-03-14 23:56:10', 'salto_bikit (uid: 0) possibly teleport hacked (distance: 4087.7)'),
(165, '2023-03-15 00:01:39', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 113.7)'),
(166, '2023-03-15 00:05:28', 'salto_bikit (uid: 88) possibly teleport hacked (distance: 185.2)'),
(167, '2023-03-15 00:21:23', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 368.4 km/h'),
(168, '2023-03-15 00:21:31', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 364.0 km/h'),
(169, '2023-03-15 00:21:32', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 367.2 km/h'),
(170, '2023-03-15 00:21:33', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 367.0 km/h'),
(171, '2023-03-15 00:21:36', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 367.0 km/h'),
(172, '2023-03-15 00:21:40', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 366.7 km/h'),
(173, '2023-03-15 00:21:43', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 366.4 km/h'),
(174, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 366.6 km/h'),
(175, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 384.5 km/h'),
(176, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 384.9 km/h'),
(177, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.2 km/h'),
(178, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.0 km/h'),
(179, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.1 km/h'),
(180, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.1 km/h'),
(181, '2023-03-15 00:21:45', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.2 km/h'),
(182, '2023-03-15 00:21:48', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.2 km/h'),
(183, '2023-03-15 00:21:48', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.2 km/h'),
(184, '2023-03-15 00:21:48', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.1 km/h'),
(185, '2023-03-15 00:21:51', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.1 km/h'),
(186, '2023-03-15 00:21:53', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.1 km/h'),
(187, '2023-03-15 00:21:53', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.1 km/h'),
(188, '2023-03-15 00:21:53', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 383.6 km/h'),
(189, '2023-03-15 00:22:31', 'JAIMSE_PALACIO (uid: 35) possibly used airbreak.'),
(190, '2023-03-15 00:24:07', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 350.5 km/h'),
(191, '2023-03-15 00:24:10', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 350.1 km/h'),
(192, '2023-03-15 00:24:10', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 368.6 km/h'),
(193, '2023-03-15 00:24:10', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 368.8 km/h'),
(194, '2023-03-15 00:24:10', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 368.7 km/h'),
(195, '2023-03-15 00:24:10', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 368.8 km/h'),
(196, '2023-03-15 00:24:11', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 368.7 km/h'),
(197, '2023-03-15 00:25:36', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 410.3 km/h'),
(198, '2023-03-15 00:25:37', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 461.6 km/h'),
(199, '2023-03-15 00:25:40', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 467.6 km/h'),
(200, '2023-03-15 00:25:41', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 515.5 km/h'),
(201, '2023-03-15 00:25:41', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 515.6 km/h'),
(202, '2023-03-15 00:25:41', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 455.4 km/h'),
(203, '2023-03-15 00:25:43', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 467.3 km/h'),
(204, '2023-03-15 00:25:43', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 468.1 km/h'),
(205, '2023-03-15 00:25:46', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 468.4 km/h'),
(206, '2023-03-15 00:25:46', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 468.3 km/h'),
(207, '2023-03-15 00:25:46', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 468.2 km/h'),
(208, '2023-03-15 00:25:47', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 385.6 km/h'),
(209, '2023-03-15 00:29:00', 'Vane_Slawi (uid: 104) possibly teleport hacked (distance: 145.2)'),
(210, '2023-03-15 00:29:28', 'Lmour_pholoko (uid: 0) possibly teleport hacked (distance: 4015.4)'),
(211, '2023-03-15 00:32:16', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 423.1 km/h'),
(212, '2023-03-15 00:32:16', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 462.0 km/h'),
(213, '2023-03-15 00:32:17', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 494.0 km/h'),
(214, '2023-03-15 00:32:19', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 510.1 km/h'),
(215, '2023-03-15 00:32:19', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 510.1 km/h'),
(216, '2023-03-15 00:32:20', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 554.2 km/h'),
(217, '2023-03-15 00:32:21', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 558.1 km/h'),
(218, '2023-03-15 00:32:22', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 556.9 km/h'),
(219, '2023-03-15 00:32:23', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 557.6 km/h'),
(220, '2023-03-15 00:32:24', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 484.8 km/h'),
(221, '2023-03-15 00:32:25', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 485.3 km/h'),
(222, '2023-03-15 00:32:27', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 402.7 km/h'),
(223, '2023-03-15 00:32:29', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 372.8 km/h'),
(224, '2023-03-15 00:37:05', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 450.4 km/h'),
(225, '2023-03-15 00:37:06', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 615.5 km/h'),
(226, '2023-03-15 00:37:07', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 781.7 km/h'),
(227, '2023-03-15 00:37:09', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 886.2 km/h'),
(228, '2023-03-15 00:37:10', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 883.4 km/h'),
(229, '2023-03-15 00:40:58', 'Kwika_Sriwila (uid: 117) possibly used airbreak.'),
(230, '2023-03-15 00:54:43', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 640.2)'),
(231, '2023-03-15 01:01:10', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 131.2)'),
(232, '2023-03-15 01:01:26', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 102.4)'),
(233, '2023-03-15 01:01:26', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 120.2)'),
(234, '2023-03-15 01:01:36', 'Anwar_Mohamed (uid: 60) possibly teleport hacked (distance: 817.3)'),
(235, '2023-03-15 01:10:08', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 121.3)'),
(236, '2023-03-15 01:46:01', 'AYMEN_LME3DAWI (uid: 28) possibly used airbreak.'),
(237, '2023-03-15 01:46:26', 'Ayoub_Jasm (uid: 91) possibly teleport hacked (distance: 363.2)'),
(238, '2023-03-15 02:03:34', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 114.0)'),
(239, '2023-03-15 02:11:00', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 384.1 km/h'),
(240, '2023-03-15 02:11:02', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 383.7 km/h'),
(241, '2023-03-15 02:11:02', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 446.0 km/h'),
(242, '2023-03-15 02:11:04', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 533.2 km/h'),
(243, '2023-03-15 02:11:04', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 630.6 km/h'),
(244, '2023-03-15 02:11:04', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 709.6 km/h'),
(245, '2023-03-15 02:11:04', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 788.0 km/h'),
(246, '2023-03-15 02:11:04', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 788.9 km/h'),
(247, '2023-03-15 02:11:04', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 792.0 km/h'),
(248, '2023-03-15 02:11:04', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 842.0 km/h'),
(249, '2023-03-15 02:11:05', 'Vini_Edrian (uid: 23) possibly speedhacked, speed: 617.4 km/h'),
(250, '2023-03-15 02:13:00', 'Anas_Tali (uid: 63) possibly teleport hacked (distance: 302.1)'),
(251, '2023-03-15 02:29:03', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 130.1)'),
(252, '2023-03-15 02:38:43', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 207.3)'),
(253, '2023-03-15 02:40:10', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 236.7)'),
(254, '2023-03-15 02:57:07', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1841.3)'),
(255, '2023-03-15 03:06:28', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 208.5)'),
(256, '2023-03-15 03:20:53', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1676.2)'),
(257, '2023-03-15 03:22:44', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1775.6)'),
(258, '2023-03-15 03:26:42', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 248.1)'),
(259, '2023-03-15 03:33:44', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 253.0)'),
(260, '2023-03-15 03:34:13', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 318.6)'),
(261, '2023-03-15 03:35:29', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 156.6)'),
(262, '2023-03-15 03:39:42', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 2660.3)'),
(263, '2023-03-15 03:39:46', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 105.5)'),
(264, '2023-03-15 03:40:19', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 105.1)'),
(265, '2023-03-15 03:43:12', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 129.4)'),
(266, '2023-03-15 03:43:16', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 179.9)'),
(267, '2023-03-15 03:43:22', 'dob_lghaba (uid: 45) possibly teleport hacked (distance: 2469.7)'),
(268, '2023-03-15 03:44:49', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3832.9)'),
(269, '2023-03-15 03:56:35', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(270, '2023-03-15 03:56:45', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 486.4)'),
(271, '2023-03-15 03:56:59', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 497.5)'),
(272, '2023-03-15 03:57:10', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 876.4)'),
(273, '2023-03-15 03:57:10', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 454.9)'),
(274, '2023-03-15 03:57:29', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 434.0)'),
(275, '2023-03-15 03:57:40', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 128.7)'),
(276, '2023-03-15 03:58:17', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 259.1)'),
(277, '2023-03-15 03:58:46', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 980.8)'),
(278, '2023-03-15 03:59:14', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 485.5)'),
(279, '2023-03-15 03:59:30', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 1161.8)'),
(280, '2023-03-15 04:00:18', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 1092.9)'),
(281, '2023-03-15 04:03:59', 'psiko_boukhris (uid: 54) possibly teleport hacked (distance: 1097.0)'),
(282, '2023-03-15 04:28:12', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 202.8)'),
(283, '2023-03-15 04:32:19', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 4629.1)'),
(284, '2023-03-15 04:33:27', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 4519.5)'),
(285, '2023-03-15 04:33:27', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 462.7)'),
(286, '2023-03-15 04:38:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 350.7 km/h'),
(287, '2023-03-15 04:38:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 374.6 km/h'),
(288, '2023-03-15 04:38:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 384.4 km/h'),
(289, '2023-03-15 04:38:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 384.4 km/h'),
(290, '2023-03-15 04:38:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 384.4 km/h'),
(291, '2023-03-15 04:38:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 384.4 km/h'),
(292, '2023-03-15 04:38:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 384.4 km/h'),
(293, '2023-03-15 04:38:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 384.4 km/h'),
(294, '2023-03-15 04:38:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 384.6 km/h'),
(295, '2023-03-15 04:38:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 386.6 km/h'),
(296, '2023-03-15 04:38:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 425.2 km/h'),
(297, '2023-03-15 04:38:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.8 km/h'),
(298, '2023-03-15 04:38:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.8 km/h'),
(299, '2023-03-15 04:38:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.8 km/h'),
(300, '2023-03-15 04:38:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.8 km/h'),
(301, '2023-03-15 04:38:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.8 km/h'),
(302, '2023-03-15 04:38:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.8 km/h'),
(303, '2023-03-15 04:38:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 425.1 km/h'),
(304, '2023-03-15 04:38:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.8 km/h'),
(305, '2023-03-15 04:38:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 422.1 km/h'),
(306, '2023-03-15 04:38:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.9 km/h'),
(307, '2023-03-15 04:38:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.9 km/h'),
(308, '2023-03-15 04:38:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.9 km/h'),
(309, '2023-03-15 04:38:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 422.0 km/h'),
(310, '2023-03-15 04:38:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 425.8 km/h'),
(311, '2023-03-15 04:38:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 422.0 km/h'),
(312, '2023-03-15 04:38:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 425.3 km/h'),
(313, '2023-03-15 04:38:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 422.0 km/h'),
(314, '2023-03-15 04:38:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 395.4 km/h'),
(315, '2023-03-15 04:38:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 392.7 km/h'),
(316, '2023-03-15 04:38:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 386.0 km/h'),
(317, '2023-03-15 04:38:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.5 km/h'),
(318, '2023-03-15 04:38:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.5 km/h'),
(319, '2023-03-15 04:38:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.5 km/h'),
(320, '2023-03-15 04:38:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.5 km/h'),
(321, '2023-03-15 04:38:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.8 km/h'),
(322, '2023-03-15 04:38:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.5 km/h'),
(323, '2023-03-15 04:38:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 405.7 km/h'),
(324, '2023-03-15 04:38:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 405.7 km/h'),
(325, '2023-03-15 04:38:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 405.1 km/h'),
(326, '2023-03-15 04:38:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 407.1 km/h'),
(327, '2023-03-15 04:38:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.5 km/h'),
(328, '2023-03-15 04:39:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.8 km/h'),
(329, '2023-03-15 04:39:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.8 km/h'),
(330, '2023-03-15 04:39:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.8 km/h'),
(331, '2023-03-15 04:39:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.8 km/h'),
(332, '2023-03-15 04:39:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.9 km/h'),
(333, '2023-03-15 04:39:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.9 km/h'),
(334, '2023-03-15 04:39:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 445.7 km/h'),
(335, '2023-03-15 04:39:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 488.3 km/h'),
(336, '2023-03-15 04:39:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 496.0 km/h'),
(337, '2023-03-15 04:39:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 496.4 km/h'),
(338, '2023-03-15 04:39:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 491.9 km/h'),
(339, '2023-03-15 04:39:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 491.9 km/h'),
(340, '2023-03-15 04:39:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 491.9 km/h'),
(341, '2023-03-15 04:39:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 491.9 km/h'),
(342, '2023-03-15 04:39:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 491.7 km/h'),
(343, '2023-03-15 04:39:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 496.3 km/h'),
(344, '2023-03-15 04:39:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 491.7 km/h'),
(345, '2023-03-15 04:39:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 496.2 km/h'),
(346, '2023-03-15 04:39:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 491.9 km/h'),
(347, '2023-03-15 04:39:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 493.2 km/h'),
(348, '2023-03-15 04:39:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 494.6 km/h'),
(349, '2023-03-15 04:39:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 496.3 km/h'),
(350, '2023-03-15 04:39:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 492.8 km/h'),
(351, '2023-03-15 04:39:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 492.2 km/h'),
(352, '2023-03-15 04:39:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 498.0 km/h'),
(353, '2023-03-15 04:39:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.6 km/h'),
(354, '2023-03-15 04:39:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.4 km/h'),
(355, '2023-03-15 04:39:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(356, '2023-03-15 04:39:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.4 km/h'),
(357, '2023-03-15 04:39:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(358, '2023-03-15 04:39:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.8 km/h'),
(359, '2023-03-15 04:39:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(360, '2023-03-15 04:39:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.8 km/h'),
(361, '2023-03-15 04:39:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(362, '2023-03-15 04:39:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 513.9 km/h'),
(363, '2023-03-15 04:39:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(364, '2023-03-15 04:39:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 512.3 km/h'),
(365, '2023-03-15 04:39:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(366, '2023-03-15 04:39:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(367, '2023-03-15 04:39:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.0 km/h'),
(368, '2023-03-15 04:39:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(369, '2023-03-15 04:39:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(370, '2023-03-15 04:39:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(371, '2023-03-15 04:39:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.0 km/h'),
(372, '2023-03-15 04:39:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.0 km/h'),
(373, '2023-03-15 04:39:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.1 km/h'),
(374, '2023-03-15 04:39:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.0 km/h'),
(375, '2023-03-15 04:39:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.0 km/h'),
(376, '2023-03-15 04:39:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.7 km/h'),
(377, '2023-03-15 04:39:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.0 km/h'),
(378, '2023-03-15 04:39:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(379, '2023-03-15 04:39:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(380, '2023-03-15 04:39:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(381, '2023-03-15 04:39:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(382, '2023-03-15 04:39:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(383, '2023-03-15 04:39:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 513.9 km/h'),
(384, '2023-03-15 04:39:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 513.5 km/h'),
(385, '2023-03-15 04:40:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.4 km/h'),
(386, '2023-03-15 04:40:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 506.6 km/h'),
(387, '2023-03-15 04:40:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 505.5 km/h'),
(388, '2023-03-15 04:40:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 511.8 km/h'),
(389, '2023-03-15 04:40:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.6 km/h'),
(390, '2023-03-15 04:40:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.6 km/h'),
(391, '2023-03-15 04:40:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 513.5 km/h'),
(392, '2023-03-15 04:40:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.6 km/h'),
(393, '2023-03-15 04:40:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.1 km/h'),
(394, '2023-03-15 04:40:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.1 km/h'),
(395, '2023-03-15 04:40:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.4 km/h'),
(396, '2023-03-15 04:40:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.4 km/h'),
(397, '2023-03-15 04:40:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.4 km/h'),
(398, '2023-03-15 04:40:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 508.8 km/h'),
(399, '2023-03-15 04:40:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.2 km/h'),
(400, '2023-03-15 04:40:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 508.6 km/h'),
(401, '2023-03-15 04:40:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.4 km/h'),
(402, '2023-03-15 04:40:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 508.1 km/h'),
(403, '2023-03-15 04:40:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(404, '2023-03-15 04:40:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.0 km/h'),
(405, '2023-03-15 04:40:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 511.6 km/h'),
(406, '2023-03-15 04:40:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 506.2 km/h'),
(407, '2023-03-15 04:40:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 507.6 km/h'),
(408, '2023-03-15 04:40:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 513.0 km/h'),
(409, '2023-03-15 04:40:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.7 km/h'),
(410, '2023-03-15 04:40:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.3 km/h'),
(411, '2023-03-15 04:40:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.3 km/h'),
(412, '2023-03-15 04:40:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.9 km/h'),
(413, '2023-03-15 04:40:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.3 km/h'),
(414, '2023-03-15 04:40:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.3 km/h'),
(415, '2023-03-15 04:40:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.7 km/h'),
(416, '2023-03-15 04:40:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.6 km/h'),
(417, '2023-03-15 04:40:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.6 km/h'),
(418, '2023-03-15 04:40:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 513.6 km/h'),
(419, '2023-03-15 04:40:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 514.2 km/h'),
(420, '2023-03-15 04:40:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 513.3 km/h'),
(421, '2023-03-15 04:40:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 508.3 km/h'),
(422, '2023-03-15 04:40:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.4 km/h'),
(423, '2023-03-15 04:40:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(424, '2023-03-15 04:40:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(425, '2023-03-15 04:40:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(426, '2023-03-15 04:40:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(427, '2023-03-15 04:40:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.2 km/h'),
(428, '2023-03-15 04:40:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(429, '2023-03-15 04:40:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(430, '2023-03-15 04:40:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(431, '2023-03-15 04:40:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 512.6 km/h'),
(432, '2023-03-15 04:40:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(433, '2023-03-15 04:40:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.9 km/h'),
(434, '2023-03-15 04:40:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(435, '2023-03-15 04:40:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.9 km/h'),
(436, '2023-03-15 04:40:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(437, '2023-03-15 04:40:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(438, '2023-03-15 04:40:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 511.7 km/h'),
(439, '2023-03-15 04:40:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(440, '2023-03-15 04:41:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(441, '2023-03-15 04:41:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.3 km/h'),
(442, '2023-03-15 04:41:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.1 km/h'),
(443, '2023-03-15 04:41:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.6 km/h'),
(444, '2023-03-15 04:41:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.0 km/h'),
(445, '2023-03-15 04:41:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 510.2 km/h'),
(446, '2023-03-15 04:41:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.7 km/h'),
(447, '2023-03-15 04:41:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 509.0 km/h'),
(448, '2023-03-15 04:41:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 507.9 km/h'),
(449, '2023-03-15 04:41:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 507.9 km/h'),
(450, '2023-03-15 04:41:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 507.3 km/h'),
(451, '2023-03-15 04:41:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 507.3 km/h'),
(452, '2023-03-15 04:41:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 533.3 km/h'),
(453, '2023-03-15 04:41:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 542.6 km/h'),
(454, '2023-03-15 04:41:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 543.5 km/h'),
(455, '2023-03-15 04:41:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.1 km/h'),
(456, '2023-03-15 04:41:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.8 km/h'),
(457, '2023-03-15 04:41:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.8 km/h'),
(458, '2023-03-15 04:41:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.8 km/h'),
(459, '2023-03-15 04:41:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.1 km/h'),
(460, '2023-03-15 04:41:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.1 km/h'),
(461, '2023-03-15 04:41:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.1 km/h'),
(462, '2023-03-15 04:41:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(463, '2023-03-15 04:41:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 547.7 km/h'),
(464, '2023-03-15 04:41:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(465, '2023-03-15 04:41:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(466, '2023-03-15 04:41:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(467, '2023-03-15 04:41:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(468, '2023-03-15 04:41:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(469, '2023-03-15 04:41:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 547.6 km/h'),
(470, '2023-03-15 04:41:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(471, '2023-03-15 04:41:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 544.0 km/h'),
(472, '2023-03-15 04:41:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 555.5 km/h'),
(473, '2023-03-15 04:41:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(474, '2023-03-15 04:41:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(475, '2023-03-15 04:41:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(476, '2023-03-15 04:41:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(477, '2023-03-15 04:41:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(478, '2023-03-15 04:41:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(479, '2023-03-15 04:41:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.6 km/h'),
(480, '2023-03-15 04:41:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 577.4 km/h'),
(481, '2023-03-15 04:41:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(482, '2023-03-15 04:41:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(483, '2023-03-15 04:41:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(484, '2023-03-15 04:41:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(485, '2023-03-15 04:41:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(486, '2023-03-15 04:41:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(487, '2023-03-15 04:41:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(488, '2023-03-15 04:41:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(489, '2023-03-15 04:41:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(490, '2023-03-15 04:41:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.2 km/h'),
(491, '2023-03-15 04:41:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(492, '2023-03-15 04:41:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(493, '2023-03-15 04:41:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.2 km/h'),
(494, '2023-03-15 04:41:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.3 km/h'),
(495, '2023-03-15 04:41:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(496, '2023-03-15 04:42:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.0 km/h'),
(497, '2023-03-15 04:42:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.0 km/h'),
(498, '2023-03-15 04:42:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.2 km/h'),
(499, '2023-03-15 04:42:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.8 km/h'),
(500, '2023-03-15 04:42:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.1 km/h'),
(501, '2023-03-15 04:42:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.7 km/h'),
(502, '2023-03-15 04:42:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.1 km/h'),
(503, '2023-03-15 04:42:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.8 km/h'),
(504, '2023-03-15 04:42:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.7 km/h'),
(505, '2023-03-15 04:42:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(506, '2023-03-15 04:42:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.7 km/h'),
(507, '2023-03-15 04:42:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 575.3 km/h'),
(508, '2023-03-15 04:42:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.7 km/h'),
(509, '2023-03-15 04:42:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.1 km/h'),
(510, '2023-03-15 04:42:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.2 km/h'),
(511, '2023-03-15 04:42:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 570.9 km/h'),
(512, '2023-03-15 04:42:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(513, '2023-03-15 04:42:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(514, '2023-03-15 04:42:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(515, '2023-03-15 04:42:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(516, '2023-03-15 04:42:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(517, '2023-03-15 04:42:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(518, '2023-03-15 04:42:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(519, '2023-03-15 04:42:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(520, '2023-03-15 04:42:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 571.0 km/h'),
(521, '2023-03-15 04:42:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.3 km/h'),
(522, '2023-03-15 04:42:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.2 km/h');
INSERT INTO `log_cheat` (`id`, `date`, `description`) VALUES
(523, '2023-03-15 04:42:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.6 km/h'),
(524, '2023-03-15 04:42:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(525, '2023-03-15 04:42:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(526, '2023-03-15 04:42:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.4 km/h'),
(527, '2023-03-15 04:42:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(528, '2023-03-15 04:42:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(529, '2023-03-15 04:42:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(530, '2023-03-15 04:42:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(531, '2023-03-15 04:42:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(532, '2023-03-15 04:42:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(533, '2023-03-15 04:42:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.8 km/h'),
(534, '2023-03-15 04:42:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(535, '2023-03-15 04:42:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.0 km/h'),
(536, '2023-03-15 04:42:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(537, '2023-03-15 04:42:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(538, '2023-03-15 04:42:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.8 km/h'),
(539, '2023-03-15 04:42:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 575.8 km/h'),
(540, '2023-03-15 04:42:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(541, '2023-03-15 04:42:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(542, '2023-03-15 04:42:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(543, '2023-03-15 04:42:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(544, '2023-03-15 04:42:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.8 km/h'),
(545, '2023-03-15 04:42:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.6 km/h'),
(546, '2023-03-15 04:42:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.6 km/h'),
(547, '2023-03-15 04:42:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(548, '2023-03-15 04:42:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.8 km/h'),
(549, '2023-03-15 04:42:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.2 km/h'),
(550, '2023-03-15 04:42:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(551, '2023-03-15 04:42:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(552, '2023-03-15 04:42:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(553, '2023-03-15 04:43:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(554, '2023-03-15 04:43:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(555, '2023-03-15 04:43:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(556, '2023-03-15 04:43:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(557, '2023-03-15 04:43:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(558, '2023-03-15 04:43:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.8 km/h'),
(559, '2023-03-15 04:43:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(560, '2023-03-15 04:43:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(561, '2023-03-15 04:43:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(562, '2023-03-15 04:43:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.0 km/h'),
(563, '2023-03-15 04:43:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(564, '2023-03-15 04:43:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(565, '2023-03-15 04:43:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(566, '2023-03-15 04:43:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(567, '2023-03-15 04:43:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.0 km/h'),
(568, '2023-03-15 04:43:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 577.8 km/h'),
(569, '2023-03-15 04:43:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 580.0 km/h'),
(570, '2023-03-15 04:43:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 576.6 km/h'),
(571, '2023-03-15 04:43:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.0 km/h'),
(572, '2023-03-15 04:43:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(573, '2023-03-15 04:43:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(574, '2023-03-15 04:43:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.6 km/h'),
(575, '2023-03-15 04:43:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(576, '2023-03-15 04:43:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 577.5 km/h'),
(577, '2023-03-15 04:43:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.8 km/h'),
(578, '2023-03-15 04:43:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(579, '2023-03-15 04:43:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(580, '2023-03-15 04:43:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(581, '2023-03-15 04:43:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(582, '2023-03-15 04:43:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(583, '2023-03-15 04:43:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(584, '2023-03-15 04:43:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(585, '2023-03-15 04:43:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(586, '2023-03-15 04:43:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(587, '2023-03-15 04:43:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(588, '2023-03-15 04:43:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(589, '2023-03-15 04:43:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(590, '2023-03-15 04:43:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(591, '2023-03-15 04:43:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(592, '2023-03-15 04:43:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(593, '2023-03-15 04:43:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(594, '2023-03-15 04:43:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(595, '2023-03-15 04:43:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(596, '2023-03-15 04:43:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(597, '2023-03-15 04:43:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(598, '2023-03-15 04:43:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 577.9 km/h'),
(599, '2023-03-15 04:43:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(600, '2023-03-15 04:43:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(601, '2023-03-15 04:43:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(602, '2023-03-15 04:43:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(603, '2023-03-15 04:43:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(604, '2023-03-15 04:43:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(605, '2023-03-15 04:43:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(606, '2023-03-15 04:43:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(607, '2023-03-15 04:43:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(608, '2023-03-15 04:43:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(609, '2023-03-15 04:44:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.9 km/h'),
(610, '2023-03-15 04:44:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(611, '2023-03-15 04:44:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.8 km/h'),
(612, '2023-03-15 04:44:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 579.2 km/h'),
(613, '2023-03-15 04:44:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.4 km/h'),
(614, '2023-03-15 04:44:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.4 km/h'),
(615, '2023-03-15 04:44:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 572.7 km/h'),
(616, '2023-03-15 04:44:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 578.9 km/h'),
(617, '2023-03-15 04:44:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.6 km/h'),
(618, '2023-03-15 04:44:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 573.0 km/h'),
(619, '2023-03-15 04:44:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 551.4 km/h'),
(620, '2023-03-15 04:44:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(621, '2023-03-15 04:44:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(622, '2023-03-15 04:44:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(623, '2023-03-15 04:44:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(624, '2023-03-15 04:44:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(625, '2023-03-15 04:44:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(626, '2023-03-15 04:44:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(627, '2023-03-15 04:44:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 521.4 km/h'),
(628, '2023-03-15 04:44:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.2 km/h'),
(629, '2023-03-15 04:44:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 515.8 km/h'),
(630, '2023-03-15 04:44:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 519.5 km/h'),
(631, '2023-03-15 04:44:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 516.0 km/h'),
(632, '2023-03-15 04:44:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 493.7 km/h'),
(633, '2023-03-15 04:44:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.6 km/h'),
(634, '2023-03-15 04:44:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.6 km/h'),
(635, '2023-03-15 04:44:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.6 km/h'),
(636, '2023-03-15 04:44:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.6 km/h'),
(637, '2023-03-15 04:44:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.6 km/h'),
(638, '2023-03-15 04:44:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.6 km/h'),
(639, '2023-03-15 04:44:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 392.2 km/h'),
(640, '2023-03-15 04:44:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 378.5 km/h'),
(641, '2023-03-15 04:44:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 393.3 km/h'),
(642, '2023-03-15 04:44:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.8 km/h'),
(643, '2023-03-15 04:44:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 391.2 km/h'),
(644, '2023-03-15 04:47:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 369.2 km/h'),
(645, '2023-03-15 04:47:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(646, '2023-03-15 04:47:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 406.9 km/h'),
(647, '2023-03-15 04:47:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(648, '2023-03-15 04:47:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.7 km/h'),
(649, '2023-03-15 04:47:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(650, '2023-03-15 04:47:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(651, '2023-03-15 04:47:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 407.2 km/h'),
(652, '2023-03-15 04:47:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(653, '2023-03-15 04:47:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(654, '2023-03-15 04:47:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(655, '2023-03-15 04:47:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(656, '2023-03-15 04:47:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(657, '2023-03-15 04:47:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 406.7 km/h'),
(658, '2023-03-15 04:47:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.9 km/h'),
(659, '2023-03-15 04:47:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.9 km/h'),
(660, '2023-03-15 04:47:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 403.3 km/h'),
(661, '2023-03-15 04:47:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.2 km/h'),
(662, '2023-03-15 04:47:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.2 km/h'),
(663, '2023-03-15 04:47:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(664, '2023-03-15 04:47:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.5 km/h'),
(665, '2023-03-15 04:47:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(666, '2023-03-15 04:47:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(667, '2023-03-15 04:47:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(668, '2023-03-15 04:47:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(669, '2023-03-15 04:47:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(670, '2023-03-15 04:47:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(671, '2023-03-15 04:47:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(672, '2023-03-15 04:47:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(673, '2023-03-15 04:47:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(674, '2023-03-15 04:47:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(675, '2023-03-15 04:47:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(676, '2023-03-15 04:47:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(677, '2023-03-15 04:47:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(678, '2023-03-15 04:47:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(679, '2023-03-15 04:47:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(680, '2023-03-15 04:47:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(681, '2023-03-15 04:47:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(682, '2023-03-15 04:47:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(683, '2023-03-15 04:47:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(684, '2023-03-15 04:47:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 404.3 km/h'),
(685, '2023-03-15 04:49:01', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 2462.8)'),
(686, '2023-03-15 04:50:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 383.7 km/h'),
(687, '2023-03-15 04:50:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 418.8 km/h'),
(688, '2023-03-15 04:50:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 453.7 km/h'),
(689, '2023-03-15 04:50:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 488.6 km/h'),
(690, '2023-03-15 04:50:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 524.6 km/h'),
(691, '2023-03-15 04:50:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 558.6 km/h'),
(692, '2023-03-15 04:50:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 597.6 km/h'),
(693, '2023-03-15 04:50:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 617.7 km/h'),
(694, '2023-03-15 04:50:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 637.4 km/h'),
(695, '2023-03-15 04:50:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 629.7 km/h'),
(696, '2023-03-15 04:50:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 629.7 km/h'),
(697, '2023-03-15 04:50:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 629.7 km/h'),
(698, '2023-03-15 04:50:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 629.7 km/h'),
(699, '2023-03-15 04:50:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 636.0 km/h'),
(700, '2023-03-15 04:51:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 629.8 km/h'),
(701, '2023-03-15 04:51:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 629.7 km/h'),
(702, '2023-03-15 04:51:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 629.7 km/h'),
(703, '2023-03-15 04:51:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 615.4 km/h'),
(704, '2023-03-15 04:51:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 624.0 km/h'),
(705, '2023-03-15 04:51:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 632.6 km/h'),
(706, '2023-03-15 04:51:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.8 km/h'),
(707, '2023-03-15 04:51:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.8 km/h'),
(708, '2023-03-15 04:51:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.8 km/h'),
(709, '2023-03-15 04:51:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(710, '2023-03-15 04:51:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(711, '2023-03-15 04:51:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 640.6 km/h'),
(712, '2023-03-15 04:51:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(713, '2023-03-15 04:51:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(714, '2023-03-15 04:51:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.1 km/h'),
(715, '2023-03-15 04:51:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.1 km/h'),
(716, '2023-03-15 04:51:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.1 km/h'),
(717, '2023-03-15 04:51:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.3 km/h'),
(718, '2023-03-15 04:51:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(719, '2023-03-15 04:51:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 638.4 km/h'),
(720, '2023-03-15 04:51:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(721, '2023-03-15 04:51:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 635.6 km/h'),
(722, '2023-03-15 04:51:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(723, '2023-03-15 04:51:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 633.2 km/h'),
(724, '2023-03-15 04:51:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 645.6 km/h'),
(725, '2023-03-15 04:51:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 674.7 km/h'),
(726, '2023-03-15 04:51:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 710.4 km/h'),
(727, '2023-03-15 04:51:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 750.1 km/h'),
(728, '2023-03-15 04:51:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 777.5 km/h'),
(729, '2023-03-15 04:51:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 823.8 km/h'),
(730, '2023-03-15 04:51:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.3 km/h'),
(731, '2023-03-15 04:51:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 850.4 km/h'),
(732, '2023-03-15 04:51:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.3 km/h'),
(733, '2023-03-15 04:51:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.3 km/h'),
(734, '2023-03-15 04:51:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.3 km/h'),
(735, '2023-03-15 04:51:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(736, '2023-03-15 04:51:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(737, '2023-03-15 04:51:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 848.1 km/h'),
(738, '2023-03-15 04:51:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(739, '2023-03-15 04:51:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 843.7 km/h'),
(740, '2023-03-15 04:51:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(741, '2023-03-15 04:51:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(742, '2023-03-15 04:51:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(743, '2023-03-15 04:51:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(744, '2023-03-15 04:51:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(745, '2023-03-15 04:51:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(746, '2023-03-15 04:51:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(747, '2023-03-15 04:51:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 850.5 km/h'),
(748, '2023-03-15 04:51:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(749, '2023-03-15 04:51:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(750, '2023-03-15 04:51:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(751, '2023-03-15 04:51:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(752, '2023-03-15 04:51:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 850.7 km/h'),
(753, '2023-03-15 04:51:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(754, '2023-03-15 04:51:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(755, '2023-03-15 04:51:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(756, '2023-03-15 04:52:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(757, '2023-03-15 04:52:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 837.2 km/h'),
(758, '2023-03-15 04:52:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 856.9 km/h'),
(759, '2023-03-15 04:52:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 882.0 km/h'),
(760, '2023-03-15 04:52:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 907.7 km/h'),
(761, '2023-03-15 04:52:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 941.2 km/h'),
(762, '2023-03-15 04:52:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 971.8 km/h'),
(763, '2023-03-15 04:52:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1005.0 km/h'),
(764, '2023-03-15 04:52:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1053.3 km/h'),
(765, '2023-03-15 04:52:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1060.2 km/h'),
(766, '2023-03-15 04:52:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1095.9 km/h'),
(767, '2023-03-15 04:52:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1128.8 km/h'),
(768, '2023-03-15 04:52:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1163.7 km/h'),
(769, '2023-03-15 04:52:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1204.8 km/h'),
(770, '2023-03-15 04:52:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1226.7 km/h'),
(771, '2023-03-15 04:52:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1256.5 km/h'),
(772, '2023-03-15 04:52:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1280.8 km/h'),
(773, '2023-03-15 04:52:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1307.7 km/h'),
(774, '2023-03-15 04:52:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1334.6 km/h'),
(775, '2023-03-15 04:52:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1361.4 km/h'),
(776, '2023-03-15 04:52:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1429.3 km/h'),
(777, '2023-03-15 04:52:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1420.1 km/h'),
(778, '2023-03-15 04:52:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1447.2 km/h'),
(779, '2023-03-15 04:52:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1478.5 km/h'),
(780, '2023-03-15 04:52:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1506.4 km/h'),
(781, '2023-03-15 04:52:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1528.6 km/h'),
(782, '2023-03-15 04:52:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1554.2 km/h'),
(783, '2023-03-15 04:52:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1574.0 km/h'),
(784, '2023-03-15 04:52:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1528.2 km/h'),
(785, '2023-03-15 04:52:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1528.4 km/h'),
(786, '2023-03-15 04:52:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1526.6 km/h'),
(787, '2023-03-15 04:52:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1545.0 km/h'),
(788, '2023-03-15 04:52:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1593.6 km/h'),
(789, '2023-03-15 04:52:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1605.6 km/h'),
(790, '2023-03-15 04:52:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1617.2 km/h'),
(791, '2023-03-15 04:52:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1632.8 km/h'),
(792, '2023-03-15 04:52:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1629.9 km/h'),
(793, '2023-03-15 04:52:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1631.1 km/h'),
(794, '2023-03-15 04:52:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1651.4 km/h'),
(795, '2023-03-15 04:52:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1672.1 km/h'),
(796, '2023-03-15 04:52:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1692.8 km/h'),
(797, '2023-03-15 04:52:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1692.8 km/h'),
(798, '2023-03-15 04:52:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1692.8 km/h'),
(799, '2023-03-15 04:52:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1692.7 km/h'),
(800, '2023-03-15 04:52:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1692.7 km/h'),
(801, '2023-03-15 04:52:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1745.1 km/h'),
(802, '2023-03-15 04:52:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1692.7 km/h'),
(803, '2023-03-15 04:52:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1724.0 km/h'),
(804, '2023-03-15 04:52:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1780.7 km/h'),
(805, '2023-03-15 04:52:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1780.6 km/h'),
(806, '2023-03-15 04:52:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1721.2 km/h'),
(807, '2023-03-15 04:52:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.2 km/h'),
(808, '2023-03-15 04:52:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1727.7 km/h'),
(809, '2023-03-15 04:52:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.2 km/h'),
(810, '2023-03-15 04:52:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.2 km/h'),
(811, '2023-03-15 04:53:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.2 km/h'),
(812, '2023-03-15 04:53:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.2 km/h'),
(813, '2023-03-15 04:53:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.3 km/h'),
(814, '2023-03-15 04:53:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1788.7 km/h'),
(815, '2023-03-15 04:53:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1785.5 km/h'),
(816, '2023-03-15 04:53:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.0 km/h'),
(817, '2023-03-15 04:53:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.6 km/h'),
(818, '2023-03-15 04:53:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.5 km/h'),
(819, '2023-03-15 04:53:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.4 km/h'),
(820, '2023-03-15 04:53:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.2 km/h'),
(821, '2023-03-15 04:53:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.2 km/h'),
(822, '2023-03-15 04:53:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.3 km/h'),
(823, '2023-03-15 04:53:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.3 km/h'),
(824, '2023-03-15 04:53:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1729.8 km/h'),
(825, '2023-03-15 04:53:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1784.5 km/h'),
(826, '2023-03-15 04:53:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1727.8 km/h'),
(827, '2023-03-15 04:53:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1787.1 km/h'),
(828, '2023-03-15 04:53:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1788.8 km/h'),
(829, '2023-03-15 04:53:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.6 km/h'),
(830, '2023-03-15 04:53:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.5 km/h'),
(831, '2023-03-15 04:53:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.2 km/h'),
(832, '2023-03-15 04:53:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.5 km/h'),
(833, '2023-03-15 04:53:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.2 km/h'),
(834, '2023-03-15 04:53:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1774.3 km/h'),
(835, '2023-03-15 04:53:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.5 km/h'),
(836, '2023-03-15 04:53:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.5 km/h'),
(837, '2023-03-15 04:53:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.7 km/h'),
(838, '2023-03-15 04:53:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.3 km/h'),
(839, '2023-03-15 04:53:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.6 km/h'),
(840, '2023-03-15 04:53:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1789.3 km/h'),
(841, '2023-03-15 04:53:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.6 km/h'),
(842, '2023-03-15 04:53:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1728.7 km/h'),
(843, '2023-03-15 04:53:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1746.7 km/h'),
(844, '2023-03-15 04:53:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1769.8 km/h'),
(845, '2023-03-15 04:53:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.9 km/h'),
(846, '2023-03-15 04:53:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1854.2 km/h'),
(847, '2023-03-15 04:53:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1794.0 km/h'),
(848, '2023-03-15 04:53:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1793.5 km/h'),
(849, '2023-03-15 04:53:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1793.5 km/h'),
(850, '2023-03-15 04:53:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1854.1 km/h'),
(851, '2023-03-15 04:53:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1871.9 km/h'),
(852, '2023-03-15 04:53:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.2 km/h'),
(853, '2023-03-15 04:53:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.2 km/h'),
(854, '2023-03-15 04:53:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.7 km/h'),
(855, '2023-03-15 04:53:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1810.4 km/h'),
(856, '2023-03-15 04:53:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.7 km/h'),
(857, '2023-03-15 04:53:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.7 km/h'),
(858, '2023-03-15 04:53:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.7 km/h'),
(859, '2023-03-15 04:53:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1827.4 km/h'),
(860, '2023-03-15 04:53:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1792.7 km/h'),
(861, '2023-03-15 04:53:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1805.5 km/h'),
(862, '2023-03-15 04:53:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1891.6 km/h'),
(863, '2023-03-15 04:53:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1843.7 km/h'),
(864, '2023-03-15 04:53:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1864.0 km/h'),
(865, '2023-03-15 04:53:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1957.5 km/h'),
(866, '2023-03-15 04:53:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1946.6 km/h'),
(867, '2023-03-15 04:54:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2005.9 km/h'),
(868, '2023-03-15 04:54:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2022.5 km/h'),
(869, '2023-03-15 04:54:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2015.1 km/h'),
(870, '2023-03-15 04:54:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2033.2 km/h'),
(871, '2023-03-15 04:54:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2060.2 km/h'),
(872, '2023-03-15 04:54:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2088.7 km/h'),
(873, '2023-03-15 04:54:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2121.3 km/h'),
(874, '2023-03-15 04:54:07', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 102.2)'),
(875, '2023-03-15 04:54:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2067.4 km/h'),
(876, '2023-03-15 04:54:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2104.6 km/h'),
(877, '2023-03-15 04:54:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2227.2 km/h'),
(878, '2023-03-15 04:54:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2226.9 km/h'),
(879, '2023-03-15 04:54:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2224.6 km/h'),
(880, '2023-03-15 04:54:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2227.6 km/h'),
(881, '2023-03-15 04:54:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2319.8 km/h'),
(882, '2023-03-15 04:54:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2401.6 km/h'),
(883, '2023-03-15 04:54:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2399.2 km/h'),
(884, '2023-03-15 04:54:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2435.9 km/h'),
(885, '2023-03-15 04:54:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2438.1 km/h'),
(886, '2023-03-15 04:54:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2439.1 km/h'),
(887, '2023-03-15 04:54:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2325.5 km/h'),
(888, '2023-03-15 04:54:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2438.1 km/h'),
(889, '2023-03-15 04:54:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2427.0 km/h'),
(890, '2023-03-15 04:54:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2323.4 km/h'),
(891, '2023-03-15 04:54:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2420.6 km/h'),
(892, '2023-03-15 04:54:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2322.4 km/h'),
(893, '2023-03-15 04:54:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(894, '2023-03-15 04:54:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(895, '2023-03-15 04:54:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(896, '2023-03-15 04:54:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2343.9 km/h'),
(897, '2023-03-15 04:54:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(898, '2023-03-15 04:54:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(899, '2023-03-15 04:54:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(900, '2023-03-15 04:54:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.2 km/h'),
(901, '2023-03-15 04:54:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.2 km/h'),
(902, '2023-03-15 04:54:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(903, '2023-03-15 04:54:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.6 km/h'),
(904, '2023-03-15 04:54:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2420.0 km/h'),
(905, '2023-03-15 04:54:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.5 km/h'),
(906, '2023-03-15 04:54:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.5 km/h'),
(907, '2023-03-15 04:54:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2436.7 km/h'),
(908, '2023-03-15 04:54:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.6 km/h'),
(909, '2023-03-15 04:54:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2413.7 km/h'),
(910, '2023-03-15 04:54:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.5 km/h'),
(911, '2023-03-15 04:54:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2441.1 km/h'),
(912, '2023-03-15 04:54:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2334.0 km/h'),
(913, '2023-03-15 04:54:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2371.3 km/h'),
(914, '2023-03-15 04:54:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.8 km/h'),
(915, '2023-03-15 04:54:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.8 km/h'),
(916, '2023-03-15 04:54:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.8 km/h'),
(917, '2023-03-15 04:54:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.3 km/h'),
(918, '2023-03-15 04:54:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.8 km/h'),
(919, '2023-03-15 04:54:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.8 km/h'),
(920, '2023-03-15 04:54:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.8 km/h'),
(921, '2023-03-15 04:54:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2434.3 km/h'),
(922, '2023-03-15 04:54:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.8 km/h'),
(923, '2023-03-15 04:54:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2439.5 km/h'),
(924, '2023-03-15 04:55:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2441.8 km/h'),
(925, '2023-03-15 04:55:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2403.0 km/h'),
(926, '2023-03-15 04:55:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.6 km/h'),
(927, '2023-03-15 04:55:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2441.8 km/h'),
(928, '2023-03-15 04:55:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.7 km/h'),
(929, '2023-03-15 04:55:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.0 km/h'),
(930, '2023-03-15 04:55:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2468.9 km/h'),
(931, '2023-03-15 04:55:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2328.1 km/h'),
(932, '2023-03-15 04:55:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.6 km/h'),
(933, '2023-03-15 04:55:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.1 km/h'),
(934, '2023-03-15 04:55:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.1 km/h'),
(935, '2023-03-15 04:55:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2373.8 km/h'),
(936, '2023-03-15 04:55:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.1 km/h'),
(937, '2023-03-15 04:55:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.1 km/h'),
(938, '2023-03-15 04:55:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.1 km/h'),
(939, '2023-03-15 04:55:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2409.3 km/h'),
(940, '2023-03-15 04:55:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.1 km/h'),
(941, '2023-03-15 04:55:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.2 km/h'),
(942, '2023-03-15 04:55:19', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.7 km/h'),
(943, '2023-03-15 04:55:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2297.4 km/h'),
(944, '2023-03-15 04:55:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2325.7 km/h'),
(945, '2023-03-15 04:55:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.9 km/h'),
(946, '2023-03-15 04:55:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2441.4 km/h'),
(947, '2023-03-15 04:55:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1939.3 km/h'),
(948, '2023-03-15 04:55:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2074.8 km/h'),
(949, '2023-03-15 04:55:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2064.1 km/h'),
(950, '2023-03-15 04:55:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2371.8 km/h'),
(951, '2023-03-15 04:55:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2324.7 km/h'),
(952, '2023-03-15 04:55:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2423.6 km/h'),
(953, '2023-03-15 04:55:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2438.4 km/h'),
(954, '2023-03-15 04:55:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2359.7 km/h'),
(955, '2023-03-15 04:55:33', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2440.6 km/h'),
(956, '2023-03-15 04:55:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2328.3 km/h'),
(957, '2023-03-15 04:55:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2330.1 km/h'),
(958, '2023-03-15 04:55:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2328.9 km/h'),
(959, '2023-03-15 04:55:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2327.3 km/h'),
(960, '2023-03-15 04:55:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.8 km/h'),
(961, '2023-03-15 04:55:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2325.6 km/h'),
(962, '2023-03-15 04:55:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.1 km/h'),
(963, '2023-03-15 04:55:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2427.3 km/h'),
(964, '2023-03-15 04:55:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2326.1 km/h'),
(965, '2023-03-15 04:55:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2284.0 km/h'),
(966, '2023-03-15 04:55:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2285.2 km/h'),
(967, '2023-03-15 04:55:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2263.5 km/h'),
(968, '2023-03-15 04:55:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2186.6 km/h'),
(969, '2023-03-15 04:55:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2137.5 km/h'),
(970, '2023-03-15 04:55:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2094.3 km/h'),
(971, '2023-03-15 04:55:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2125.1 km/h'),
(972, '2023-03-15 04:55:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2125.4 km/h'),
(973, '2023-03-15 04:55:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2042.1 km/h'),
(974, '2023-03-15 04:55:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2041.1 km/h'),
(975, '2023-03-15 04:55:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2039.6 km/h'),
(976, '2023-03-15 04:55:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 2008.4 km/h'),
(977, '2023-03-15 04:55:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1939.5 km/h'),
(978, '2023-03-15 04:55:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1848.8 km/h'),
(979, '2023-03-15 04:55:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1868.6 km/h'),
(980, '2023-03-15 04:56:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1872.9 km/h'),
(981, '2023-03-15 04:56:01', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1846.3 km/h'),
(982, '2023-03-15 04:56:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1748.8 km/h'),
(983, '2023-03-15 04:56:04', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1620.4 km/h'),
(984, '2023-03-15 04:56:05', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1530.1 km/h'),
(985, '2023-03-15 04:56:06', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1503.2 km/h'),
(986, '2023-03-15 04:56:07', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1464.4 km/h'),
(987, '2023-03-15 04:56:08', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1502.4 km/h'),
(988, '2023-03-15 04:56:08', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 496.6)'),
(989, '2023-03-15 04:56:09', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1479.1 km/h'),
(990, '2023-03-15 04:56:10', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1476.4 km/h'),
(991, '2023-03-15 04:56:11', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1388.3 km/h'),
(992, '2023-03-15 04:56:12', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1212.7 km/h'),
(993, '2023-03-15 04:56:13', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 1086.5 km/h'),
(994, '2023-03-15 04:56:14', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 961.7 km/h'),
(995, '2023-03-15 04:56:15', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 861.0 km/h'),
(996, '2023-03-15 04:56:16', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 800.3 km/h'),
(997, '2023-03-15 04:56:17', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 720.3 km/h'),
(998, '2023-03-15 04:56:18', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(999, '2023-03-15 04:56:20', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1000, '2023-03-15 04:56:21', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1001, '2023-03-15 04:56:22', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1002, '2023-03-15 04:56:23', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1003, '2023-03-15 04:56:24', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1004, '2023-03-15 04:56:25', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.6 km/h'),
(1005, '2023-03-15 04:56:26', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.6 km/h'),
(1006, '2023-03-15 04:56:27', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1007, '2023-03-15 04:56:28', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1008, '2023-03-15 04:56:29', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1009, '2023-03-15 04:56:30', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1010, '2023-03-15 04:56:31', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1011, '2023-03-15 04:56:32', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1012, '2023-03-15 04:56:34', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 707.9 km/h'),
(1013, '2023-03-15 04:56:35', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.5 km/h'),
(1014, '2023-03-15 04:56:36', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.6 km/h'),
(1015, '2023-03-15 04:56:37', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.6 km/h'),
(1016, '2023-03-15 04:56:38', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 707.8 km/h'),
(1017, '2023-03-15 04:56:39', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 698.6 km/h'),
(1018, '2023-03-15 04:56:40', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 707.9 km/h'),
(1019, '2023-03-15 04:56:41', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 708.0 km/h'),
(1020, '2023-03-15 04:56:42', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 656.7 km/h'),
(1021, '2023-03-15 04:56:43', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 516.9 km/h'),
(1022, '2023-03-15 04:56:44', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 428.2 km/h'),
(1023, '2023-03-15 04:56:45', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 366.3 km/h'),
(1024, '2023-03-15 05:02:59', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 4360.5)'),
(1025, '2023-03-15 05:11:03', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 199.1)'),
(1026, '2023-03-15 05:12:28', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 197.4)'),
(1027, '2023-03-15 05:13:17', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 2024.7)'),
(1028, '2023-03-15 05:13:35', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 144.0)'),
(1029, '2023-03-15 05:14:46', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 366.0 km/h'),
(1030, '2023-03-15 05:14:47', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 395.3 km/h'),
(1031, '2023-03-15 05:14:48', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 421.6 km/h'),
(1032, '2023-03-15 05:14:49', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 450.7 km/h'),
(1033, '2023-03-15 05:14:50', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 451.4 km/h');
INSERT INTO `log_cheat` (`id`, `date`, `description`) VALUES
(1034, '2023-03-15 05:14:51', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 450.7 km/h'),
(1035, '2023-03-15 05:14:52', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 450.7 km/h'),
(1036, '2023-03-15 05:14:53', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 450.7 km/h'),
(1037, '2023-03-15 05:14:54', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 444.1 km/h'),
(1038, '2023-03-15 05:14:55', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 372.7 km/h'),
(1039, '2023-03-15 05:14:56', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 370.4 km/h'),
(1040, '2023-03-15 05:14:57', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 372.9 km/h'),
(1041, '2023-03-15 05:14:58', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 372.5 km/h'),
(1042, '2023-03-15 05:14:59', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 373.5 km/h'),
(1043, '2023-03-15 05:15:00', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 371.2 km/h'),
(1044, '2023-03-15 05:15:02', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 371.2 km/h'),
(1045, '2023-03-15 05:15:03', 'STEVAW_MARTINEZ (uid: 48) possibly speedhacked, speed: 371.2 km/h'),
(1046, '2023-03-15 05:24:35', 'Selfx_Tchapo (uid: 49) possibly used airbreak.'),
(1047, '2023-03-15 05:34:00', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3448.5)'),
(1048, '2023-03-15 05:37:10', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3521.8)'),
(1049, '2023-03-15 05:37:26', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 160.2)'),
(1050, '2023-03-15 05:38:08', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 332.0)'),
(1051, '2023-03-15 05:39:58', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1583.2)'),
(1052, '2023-03-15 05:45:42', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 750.5)'),
(1053, '2023-03-15 05:46:20', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 146.1)'),
(1054, '2023-03-15 05:47:59', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 188.6)'),
(1055, '2023-03-15 05:59:48', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3419.4)'),
(1056, '2023-03-15 06:44:33', 'LHAJ_SFIRAA (uid: 0) possibly teleport hacked (distance: 4703.6)'),
(1057, '2023-03-15 06:56:27', 'Mohamed_gostavo (uid: 87) possibly teleport hacked (distance: 145.7)'),
(1058, '2023-03-15 09:59:49', 'Ayoub_Jasm (uid: 91) possibly used airbreak.'),
(1059, '2023-03-15 10:13:50', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 239.2)'),
(1060, '2023-03-15 10:19:16', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 4490.8)'),
(1061, '2023-03-15 10:36:50', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1062, '2023-03-15 10:43:28', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1063, '2023-03-15 10:43:31', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1064, '2023-03-15 10:43:32', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1065, '2023-03-15 10:43:35', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1066, '2023-03-15 10:43:36', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1067, '2023-03-15 10:43:43', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1068, '2023-03-15 10:45:38', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1069, '2023-03-15 10:50:23', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 3880.8)'),
(1070, '2023-03-15 10:50:23', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 121.9)'),
(1071, '2023-03-15 10:51:17', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 2904.2)'),
(1072, '2023-03-15 10:51:17', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 100.2)'),
(1073, '2023-03-15 10:51:54', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 2487.8)'),
(1074, '2023-03-15 10:51:54', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 101.9)'),
(1075, '2023-03-15 10:51:54', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 115.9)'),
(1076, '2023-03-15 11:08:56', 'Felix_Jigo (uid: 98) possibly used airbreak.'),
(1077, '2023-03-15 11:28:49', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 1992.0)'),
(1078, '2023-03-15 11:28:49', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 111.2)'),
(1079, '2023-03-15 11:42:18', 'Lmour_pholoko (uid: 76) possibly teleport hacked (distance: 2215.4)'),
(1080, '2023-03-15 11:48:12', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1081, '2023-03-15 11:52:23', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1082, '2023-03-15 11:52:27', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1083, '2023-03-15 11:52:31', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1084, '2023-03-15 11:52:43', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1085, '2023-03-15 11:53:03', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1086, '2023-03-15 11:56:57', 'Ayoub_Jasm (uid: 91) possibly teleport hacked (distance: 437.1)'),
(1087, '2023-03-15 11:57:09', 'Ayoub_Jasm (uid: 91) possibly teleport hacked (distance: 114.5)'),
(1088, '2023-03-15 11:58:41', 'LUCAS_GUANTANAMO (uid: 40) possibly teleport hacked (distance: 2915.2)'),
(1089, '2023-03-15 11:59:19', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1090, '2023-03-15 12:05:52', 'LilD_Kingos (uid: 0) possibly teleport hacked (distance: 285.8)'),
(1091, '2023-03-15 12:23:23', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 729.3)'),
(1092, '2023-03-15 12:30:37', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1093, '2023-03-15 12:51:42', 'Vane_Slawi (uid: 104) possibly teleport hacked (distance: 229.9)'),
(1094, '2023-03-15 13:04:13', 'Chliha_Olmhjob (uid: 110) possibly used airbreak.'),
(1095, '2023-03-15 13:12:10', 'Pitcho_Dasilva (uid: 132) possibly teleport hacked (distance: 3774.2)'),
(1096, '2023-03-15 13:12:17', 'Pitcho_Dasilva (uid: 132) possibly teleport hacked (distance: 3774.2)'),
(1097, '2023-03-15 13:12:33', 'LUCAS_GUANTANAMO (uid: 40) possibly teleport hacked (distance: 3663.7)'),
(1098, '2023-03-15 13:14:55', 'LUCAS_GUANTANAMO (uid: 40) possibly teleport hacked (distance: 5058.8)'),
(1099, '2023-03-15 13:15:25', 'LHAJ_SFIRAA (uid: 0) possibly teleport hacked (distance: 625.5)'),
(1100, '2023-03-15 13:54:13', 'Tyson_Choppa (uid: 0) possibly teleport hacked (distance: 583.1)'),
(1101, '2023-03-15 15:36:34', 'Comi_Escobar (uid: 123) possibly teleport hacked (distance: 1048.8)'),
(1102, '2023-03-15 15:38:27', 'Comi_Escobar (uid: 123) possibly teleport hacked (distance: 476.1)'),
(1103, '2023-03-15 15:46:36', 'Comi_Escobar (uid: 123) possibly teleport hacked (distance: 123.4)'),
(1104, '2023-03-15 15:52:50', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1105, '2023-03-15 16:01:19', 'Comi_Escobar (uid: 123) possibly teleport hacked (distance: 310.1)'),
(1106, '2023-03-15 16:12:10', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 184.5)'),
(1107, '2023-03-15 16:13:27', 'Comi_Escobar (uid: 123) possibly teleport hacked (distance: 472.5)'),
(1108, '2023-03-15 17:21:32', 'Alex_Bonelli (uid: 111) possibly used airbreak.'),
(1109, '2023-03-15 17:40:23', 'dizzy_dros (uid: 0) possibly teleport hacked (distance: 599.0)'),
(1110, '2023-03-15 17:43:43', 'X__2 (uid: 142) possibly used airbreak.'),
(1111, '2023-03-15 17:44:17', 'X__2 (uid: 142) possibly used airbreak.'),
(1112, '2023-03-15 17:44:54', 'X__2 (uid: 142) possibly used airbreak.'),
(1113, '2023-03-15 17:45:29', 'X__2 (uid: 142) possibly used airbreak.'),
(1114, '2023-03-15 17:45:51', 'X__2 (uid: 142) possibly used airbreak.'),
(1115, '2023-03-15 17:46:09', 'X__2 (uid: 142) possibly used airbreak.'),
(1116, '2023-03-15 17:46:22', 'X__2 (uid: 142) possibly used airbreak.'),
(1117, '2023-03-15 17:59:23', 'salto_bikit (uid: 88) possibly teleport hacked (distance: 2225.4)'),
(1118, '2023-03-15 18:17:29', 'Lmour_pholoko (uid: 76) possibly teleport hacked (distance: 102.2)'),
(1119, '2023-03-15 18:27:47', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 275.0)'),
(1120, '2023-03-15 18:28:21', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 561.2)'),
(1121, '2023-03-15 18:28:50', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 4318.7)'),
(1122, '2023-03-15 18:28:54', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 133.3)'),
(1123, '2023-03-15 18:30:52', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 4459.0)'),
(1124, '2023-03-15 18:31:21', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 2442.4)'),
(1125, '2023-03-15 18:33:46', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 1898.6)'),
(1126, '2023-03-15 18:33:47', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 132.9)'),
(1127, '2023-03-15 18:57:28', 'Chliha_Olmhjob (uid: 110) possibly used airbreak.'),
(1128, '2023-03-15 19:03:45', 'SALIM_LUCAS (uid: 113) possibly teleport hacked (distance: 114.6)'),
(1129, '2023-03-15 19:08:15', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 291.1)'),
(1130, '2023-03-15 19:12:51', 'PROF_TIMSA7 (uid: 59) possibly teleport hacked (distance: 3125.4)'),
(1131, '2023-03-15 19:19:40', 'zamora_chadi (uid: 141) possibly teleport hacked (distance: 125.0)'),
(1132, '2023-03-15 19:19:40', 'SALIM_LUCAS (uid: 113) possibly teleport hacked (distance: 3690.4)'),
(1133, '2023-03-15 19:22:15', 'Chliha_Olmhjob (uid: 110) possibly used airbreak.'),
(1134, '2023-03-15 19:22:46', 'salto_bikit (uid: 88) possibly teleport hacked (distance: 4467.9)'),
(1135, '2023-03-15 19:27:55', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 1720.6)'),
(1136, '2023-03-15 21:47:10', 'Yassir_sancho (uid: 135) possibly teleport hacked (distance: 1639.4)'),
(1137, '2023-03-15 21:49:28', 'Yassir_sancho (uid: 135) possibly teleport hacked (distance: 1750.3)'),
(1138, '2023-03-15 21:54:20', 'Chliha_Olmhjob (uid: 110) possibly used airbreak.'),
(1139, '2023-03-15 21:58:01', 'Yassir_sancho (uid: 135) possibly teleport hacked (distance: 1141.6)'),
(1140, '2023-03-15 22:00:14', 'Yassir_sancho (uid: 135) possibly teleport hacked (distance: 2480.9)'),
(1141, '2023-03-15 22:04:16', 'Bilomi_albert (uid: 0) possibly teleport hacked (distance: 1143.7)'),
(1142, '2023-03-15 22:07:12', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1143, '2023-03-15 22:07:59', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1144, '2023-03-15 22:07:59', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1145, '2023-03-15 22:08:20', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1146, '2023-03-15 22:08:23', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1147, '2023-03-15 22:08:25', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1148, '2023-03-15 22:08:26', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1149, '2023-03-15 22:09:14', 'Bilomi_albert (uid: 152) possibly teleport hacked (distance: 2459.5)'),
(1150, '2023-03-15 22:21:07', 'DRISS_ESCOBAR (uid: 86) possibly used airbreak.'),
(1151, '2023-03-15 22:21:52', 'ROCH_PRAN (uid: 109) possibly teleport hacked (distance: 549.2)'),
(1152, '2023-03-15 22:23:23', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 157.7)'),
(1153, '2023-03-15 22:51:15', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 4844.6)'),
(1154, '2023-03-15 22:52:33', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 4340.7)'),
(1155, '2023-03-15 22:53:06', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1156, '2023-03-15 22:54:31', 'Jlabanda_MDFK (uid: 93) possibly teleport hacked (distance: 2104.2)'),
(1157, '2023-03-15 22:55:02', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 2688.5)'),
(1158, '2023-03-15 22:57:19', 'SHARLOC_SMOKERS (uid: 154) possibly teleport hacked (distance: 401.7)'),
(1159, '2023-03-15 22:58:39', 'Hamdi_johnson (uid: 156) possibly teleport hacked (distance: 108.8)'),
(1160, '2023-03-15 23:01:06', 'SHARLOC_SMOKERS (uid: 154) possibly teleport hacked (distance: 2460.4)'),
(1161, '2023-03-15 23:04:39', 'POP_SMOKE (uid: 157) possibly teleport hacked (distance: 2829.0)'),
(1162, '2023-03-15 23:04:48', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1163, '2023-03-15 23:06:10', 'hmed_twil (uid: 131) possibly hacked armor. (old: 90.00, new: 100.00)'),
(1164, '2023-03-15 23:12:48', 'SHARLOC_SMOKERS (uid: 154) possibly used airbreak.'),
(1165, '2023-03-15 23:53:50', 'hmed_twil (uid: 131) possibly hacked armor. (old: 89.00, new: 100.00)'),
(1166, '2023-03-15 23:57:23', 'hmed_twil (uid: 131) possibly hacked armor. (old: 23.00, new: 100.00)'),
(1167, '2023-03-15 23:58:54', 'hmed_twil (uid: 131) possibly hacked armor. (old: 36.00, new: 100.00)'),
(1168, '2023-03-16 00:01:28', 'SALIM_LUCAS (uid: 113) possibly used airbreak.'),
(1169, '2023-03-16 00:01:50', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1170, '2023-03-16 00:06:57', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1171, '2023-03-16 00:08:35', 'Chliha_Olmhjob (uid: 110) possibly used airbreak.'),
(1172, '2023-03-16 00:10:26', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 91.00, new: 100.00)'),
(1173, '2023-03-16 00:11:06', 'SHARLOC_SMOKERS (uid: 154) possibly used airbreak.'),
(1174, '2023-03-16 00:11:58', 'ROCH_PRAN (uid: 109) possibly teleport hacked (distance: 149.3)'),
(1175, '2023-03-16 00:14:54', 'SALIM_LUCAS (uid: 113) possibly used airbreak.'),
(1176, '2023-03-16 00:52:14', 'JAIMSE_PALACIO (uid: 35) possibly teleport hacked (distance: 4262.0)'),
(1177, '2023-03-16 01:19:33', 'Darwin_Watirson (uid: 106) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1178, '2023-03-16 02:16:05', 'dob_lghaba (uid: 0) possibly teleport hacked (distance: 5485.1)'),
(1179, '2023-03-16 02:23:49', 'Anas_Tali (uid: 63) possibly teleport hacked (distance: 100.4)'),
(1180, '2023-03-16 02:24:55', 'Ayoub_Jasm (uid: 91) possibly teleport hacked (distance: 104.5)'),
(1181, '2023-03-16 04:08:15', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1191.7)'),
(1182, '2023-03-16 07:31:33', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 1756.1)'),
(1183, '2023-03-16 07:32:21', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 4424.1)'),
(1184, '2023-03-16 07:33:22', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 2482.6)'),
(1185, '2023-03-16 07:33:47', 'Anas_Tali (uid: 63) possibly teleport hacked (distance: 174.7)'),
(1186, '2023-03-16 07:39:27', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3941.8)'),
(1187, '2023-03-16 07:44:07', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 3156.9)'),
(1188, '2023-03-16 07:45:04', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 231.2)'),
(1189, '2023-03-16 07:47:18', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 865.3)'),
(1190, '2023-03-16 11:48:10', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1191, '2023-03-16 11:48:11', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1192, '2023-03-16 11:52:19', 'WALID_PABLO (uid: 165) possibly teleport hacked (distance: 967.5)'),
(1193, '2023-03-16 11:57:19', 'matouss_clean (uid: 121) possibly teleport hacked (distance: 4265.8)'),
(1194, '2023-03-16 12:05:35', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1195, '2023-03-16 12:08:12', 'LA7AJ_BLACK (uid: 0) possibly teleport hacked (distance: 2829.4)'),
(1196, '2023-03-16 12:11:36', 'Lmour_pholoko (uid: 76) possibly used airbreak.'),
(1197, '2023-03-16 12:12:29', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1198, '2023-03-16 12:26:06', 'Yasser_Zineddine (uid: 153) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1199, '2023-03-16 12:29:35', 'Darwin_Watirson (uid: 106) possibly teleport hacked (distance: 533.6)'),
(1200, '2023-03-16 12:31:48', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1201, '2023-03-16 12:31:50', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1202, '2023-03-16 12:31:52', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1203, '2023-03-16 12:31:56', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1204, '2023-03-16 12:32:19', 'Yasser_Zineddine (uid: 153) possibly teleport hacked (distance: 126.3)'),
(1205, '2023-03-16 12:32:21', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1206, '2023-03-16 12:32:23', 'Yasser_Zineddine (uid: 153) possibly used airbreak.'),
(1207, '2023-03-16 12:34:54', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 1076.4)'),
(1208, '2023-03-16 12:46:58', 'Kwika_Sriwila (uid: 117) possibly teleport hacked (distance: 3037.9)'),
(1209, '2023-03-16 12:48:05', 'Mistro_Roberto (uid: 42) possibly teleport hacked (distance: 3974.1)'),
(1210, '2023-03-16 12:50:01', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 3013.8)'),
(1211, '2023-03-16 12:55:27', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 1174.3)'),
(1212, '2023-03-16 12:56:29', 'LMCH_NATAZI (uid: 83) possibly teleport hacked (distance: 2977.3)'),
(1213, '2023-03-16 12:58:34', 'Darwin_Watirson (uid: 0) possibly teleport hacked (distance: 3513.0)'),
(1214, '2023-03-16 13:02:10', 'AYMEN_LME3DAWI (uid: 28) possibly used airbreak.'),
(1215, '2023-03-16 13:02:19', 'Darwin_Watirson (uid: 0) possibly teleport hacked (distance: 569.8)'),
(1216, '2023-03-16 13:02:20', 'LilD_Kingos (uid: 0) possibly teleport hacked (distance: 2279.2)'),
(1217, '2023-03-16 13:09:24', 'Lmour_pholoko (uid: 76) possibly teleport hacked (distance: 3958.8)'),
(1218, '2023-03-16 13:12:27', 'Kwika_Sriwila (uid: 117) possibly teleport hacked (distance: 2216.8)'),
(1219, '2023-03-16 13:15:47', 'LMCH_NATAZI (uid: 83) possibly teleport hacked (distance: 775.9)'),
(1220, '2023-03-16 13:15:48', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 3548.2)'),
(1221, '2023-03-16 13:29:22', 'Yasser_Zineddine (uid: 153) possibly teleport hacked (distance: 2146.9)'),
(1222, '2023-03-16 13:35:46', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 2219.3)'),
(1223, '2023-03-16 13:37:34', 'matouss_clean (uid: 121) possibly teleport hacked (distance: 263.1)'),
(1224, '2023-03-16 13:41:08', 'LAMAR_PABLOX (uid: 12) possibly teleport hacked (distance: 3203.4)'),
(1225, '2023-03-16 13:44:43', 'matouss_clean (uid: 121) possibly teleport hacked (distance: 245.2)'),
(1226, '2023-03-16 13:47:00', 'matouss_clean (uid: 121) possibly teleport hacked (distance: 158.9)'),
(1227, '2023-03-16 13:47:02', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1228, '2023-03-16 13:55:43', 'LMCH_NATAZI (uid: 83) possibly teleport hacked (distance: 522.9)'),
(1229, '2023-03-16 14:21:14', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 114.3)'),
(1230, '2023-03-16 14:32:11', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 1587.5)'),
(1231, '2023-03-16 14:32:15', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 133.1)'),
(1232, '2023-03-16 14:34:32', 'Limbo_sinyore (uid: 8) possibly teleport hacked (distance: 134.5)'),
(1233, '2023-03-16 14:37:07', 'zamora_chadi (uid: 141) possibly used airbreak.'),
(1234, '2023-03-16 14:37:12', 'POP_SMOKE (uid: 157) possibly used airbreak.'),
(1235, '2023-03-16 14:40:37', 'POP_SMOKE (uid: 157) possibly teleport hacked (distance: 1500.9)'),
(1236, '2023-03-16 14:45:16', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 2000.0)'),
(1237, '2023-03-16 14:45:44', 'TOM_SMOKER (uid: 176) possibly used airbreak.'),
(1238, '2023-03-16 14:48:22', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 2908.4)'),
(1239, '2023-03-16 14:50:23', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 4170.5)'),
(1240, '2023-03-16 14:52:20', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 607.9)'),
(1241, '2023-03-16 14:52:25', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 1368.4)'),
(1242, '2023-03-16 14:54:53', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 3060.9)'),
(1243, '2023-03-16 14:57:47', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 1251.1)'),
(1244, '2023-03-16 15:02:34', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1245, '2023-03-16 15:02:58', 'zamora_chadi (uid: 141) possibly used airbreak.'),
(1246, '2023-03-16 15:05:41', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 1934.9)'),
(1247, '2023-03-16 15:06:08', 'SHARLOC_SMOKERS (uid: 154) possibly used airbreak.'),
(1248, '2023-03-16 15:06:47', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 1899.9)'),
(1249, '2023-03-16 15:10:22', 'Darwin_Watirson (uid: 106) possibly teleport hacked (distance: 342.7)'),
(1250, '2023-03-16 15:12:08', 'POP_SMOKE (uid: 157) possibly teleport hacked (distance: 3151.7)'),
(1251, '2023-03-16 15:12:12', 'zamora_chadi (uid: 141) possibly used airbreak.'),
(1252, '2023-03-16 15:29:39', 'HOUSSAM_KABBACHE (uid: 169) possibly teleport hacked (distance: 1359.4)'),
(1253, '2023-03-16 15:34:17', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 720.7)'),
(1254, '2023-03-16 15:36:48', 'AYMEN_LME3DAWI (uid: 28) possibly teleport hacked (distance: 445.7)'),
(1255, '2023-03-16 15:40:06', 'Chliha_Olmhjob (uid: 110) possibly speedhacked, speed: 359.2 km/h'),
(1256, '2023-03-16 15:40:28', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 241.2)'),
(1257, '2023-03-16 15:41:19', 'Kwika_Sriwila (uid: 117) possibly used airbreak.'),
(1258, '2023-03-16 16:03:44', 'Chliha_Olmhjob (uid: 110) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1259, '2023-03-16 16:07:09', 'salto_bikit (uid: 88) possibly teleport hacked (distance: 3043.1)'),
(1260, '2023-03-16 16:07:29', 'Vigas_Omerta (uid: 187) possibly teleport hacked (distance: 3778.1)'),
(1261, '2023-03-16 16:09:16', 'Vigas_Omerta (uid: 187) possibly teleport hacked (distance: 3810.3)'),
(1262, '2023-03-16 16:13:01', 'Vigas_Omerta (uid: 187) possibly teleport hacked (distance: 422.2)'),
(1263, '2023-03-16 16:31:13', 'dbana_garcia (uid: 0) possibly teleport hacked (distance: 2478.8)'),
(1264, '2023-03-16 16:32:06', 'RELAX_PERSON (uid: 189) possibly used airbreak.'),
(1265, '2023-03-16 16:35:59', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 4893.9)'),
(1266, '2023-03-16 16:36:03', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 150.9)'),
(1267, '2023-03-16 16:43:22', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 2374.8)'),
(1268, '2023-03-16 16:44:35', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 2692.4)'),
(1269, '2023-03-16 16:50:47', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 623.7)'),
(1270, '2023-03-16 16:51:19', 'Selfx_Tchapo (uid: 49) possibly teleport hacked (distance: 1788.7)'),
(1271, '2023-03-16 16:57:16', 'MIKHAEL_RODRIGUEZ (uid: 188) possibly used airbreak.'),
(1272, '2023-03-16 17:07:53', 'JERRY_SMOKER (uid: 173) possibly teleport hacked (distance: 138.4)'),
(1273, '2023-03-16 17:19:40', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 60.00, new: 100.00)'),
(1274, '2023-03-16 17:22:00', 'zamora_chadi (uid: 141) possibly teleport hacked (distance: 507.4)'),
(1275, '2023-03-16 17:22:00', 'Kwika_Sriwila (uid: 117) possibly teleport hacked (distance: 536.7)'),
(1276, '2023-03-16 17:32:42', 'SIMO_TACHTOCH (uid: 194) possibly teleport hacked (distance: 879.3)'),
(1277, '2023-03-16 17:34:46', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 126.5)'),
(1278, '2023-03-16 17:39:55', 'SHARLOC_SMOKERS (uid: 154) possibly teleport hacked (distance: 282.1)'),
(1279, '2023-03-16 17:42:03', 'Ismail_Sanch (uid: 175) possibly teleport hacked (distance: 103.5)'),
(1280, '2023-03-16 17:42:07', 'Ismail_Sanch (uid: 175) possibly teleport hacked (distance: 103.5)'),
(1281, '2023-03-16 17:47:40', 'Kwika_Sriwila (uid: 117) possibly teleport hacked (distance: 182.6)'),
(1282, '2023-03-16 17:49:26', 'Chliha_Olmhjob (uid: 110) possibly speedhacked, speed: 371.9 km/h'),
(1283, '2023-03-16 18:07:34', 'Matrax_Smoker (uid: 184) possibly teleport hacked (distance: 3735.7)'),
(1284, '2023-03-16 18:14:20', 'Kwika_Sriwila (uid: 117) possibly teleport hacked (distance: 126.1)'),
(1285, '2023-03-16 18:14:49', 'Carlos_Messi (uid: 90) possibly used airbreak.'),
(1286, '2023-03-16 18:20:46', 'abdollah_algnawi (uid: 14) possibly teleport hacked (distance: 2959.1)'),
(1287, '2023-03-16 18:24:51', 'LAMAR_PABLOX (uid: 12) possibly used airbreak.'),
(1288, '2023-03-16 18:30:39', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 84.00, new: 100.00)'),
(1289, '2023-03-16 18:32:58', 'SHARLOC_SMOKERS (uid: 154) possibly used airbreak.'),
(1290, '2023-03-16 18:53:09', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 554.9)'),
(1291, '2023-03-16 18:59:07', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 83.00, new: 100.00)'),
(1292, '2023-03-16 19:01:03', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 87.00, new: 100.00)'),
(1293, '2023-03-16 19:02:21', 'Jlabanda_MDFK (uid: 93) possibly used airbreak.'),
(1294, '2023-03-16 19:14:20', 'Ayoub_Jasm (uid: 91) possibly teleport hacked (distance: 152.8)'),
(1295, '2023-03-16 19:15:55', 'LAMAR_PABLOX (uid: 12) possibly teleport hacked (distance: 354.6)'),
(1296, '2023-03-16 19:33:25', 'hmed_twil (uid: 131) possibly hacked armor. (old: 93.00, new: 100.00)'),
(1297, '2023-03-16 19:37:09', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1298, '2023-03-16 19:43:36', 'Lmour_pholoko (uid: 76) possibly teleport hacked (distance: 637.6)'),
(1299, '2023-03-16 19:46:44', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1300, '2023-03-16 19:48:17', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 154.5)'),
(1301, '2023-03-16 19:58:37', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 1349.4)'),
(1302, '2023-03-16 19:58:37', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 112.0)'),
(1303, '2023-03-16 19:58:37', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 113.5)'),
(1304, '2023-03-16 19:58:37', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 103.7)'),
(1305, '2023-03-16 19:58:37', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 114.0)'),
(1306, '2023-03-16 20:05:37', 'WALID_PABLO (uid: 0) possibly teleport hacked (distance: 761.7)'),
(1307, '2023-03-16 20:09:23', 'LAMAR_PABLOX (uid: 12) possibly used airbreak.'),
(1308, '2023-03-16 20:09:27', 'LAMAR_PABLOX (uid: 12) possibly used airbreak.'),
(1309, '2023-03-16 20:20:12', 'Lucas_Garcia (uid: 168) possibly teleport hacked (distance: 4496.7)'),
(1310, '2023-03-16 20:20:17', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1311, '2023-03-16 20:26:01', 'SHARLOC_SMOKERS (uid: 154) possibly used airbreak.'),
(1312, '2023-03-16 20:29:14', 'SHARLOC_SMOKERS (uid: 154) possibly used airbreak.'),
(1313, '2023-03-16 20:30:11', 'Lucas_Garcia (uid: 168) possibly teleport hacked (distance: 3784.2)'),
(1314, '2023-03-16 20:38:35', 'Lucas_Garcia (uid: 168) possibly teleport hacked (distance: 229.0)'),
(1315, '2023-03-16 20:40:40', 'POP_SMOKE (uid: 157) possibly hacked armor. (old: 97.00, new: 100.00)'),
(1316, '2023-03-16 20:44:28', 'SHARLOC_SMOKERS (uid: 154) possibly used airbreak.'),
(1317, '2023-03-16 20:56:22', 'UTCHIHA_PABLO (uid: 15) possibly teleport hacked (distance: 3188.8)'),
(1318, '2023-03-16 21:08:48', 'LHAJ_SFIRAA (uid: 97) possibly used airbreak.'),
(1319, '2023-03-16 21:11:20', 'MOUAD_PABLO (uid: 21) possibly used airbreak.'),
(1320, '2023-03-16 21:25:21', 'Lmour_pholoko (uid: 76) possibly teleport hacked (distance: 1028.9)'),
(1321, '2023-03-16 21:26:49', 'Anwar_Mohamed (uid: 60) possibly teleport hacked (distance: 442.9)'),
(1322, '2023-03-16 22:00:12', 'PABLO_PICASO (uid: 183) possibly used airbreak.'),
(1323, '2023-03-16 22:01:21', 'PABLO_PICASO (uid: 183) possibly hacked armor. (old: 40.00, new: 50.00)'),
(1324, '2023-03-17 13:00:32', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1325, '2023-03-17 13:00:53', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1326, '2023-03-17 13:02:48', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1327, '2023-03-17 13:02:48', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1328, '2023-03-17 13:02:48', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1329, '2023-03-17 13:03:02', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1330, '2023-03-17 13:03:04', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1331, '2023-03-17 13:11:28', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 3533.8)'),
(1332, '2023-03-17 13:11:36', 'Shan_Pholoko (uid: 200) possibly used airbreak.'),
(1333, '2023-03-17 13:13:39', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 591.4)'),
(1334, '2023-03-17 13:17:54', 'LMCH_NATAZI (uid: 83) possibly teleport hacked (distance: 2771.6)'),
(1335, '2023-03-17 13:19:28', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 1368.4)'),
(1336, '2023-03-17 13:24:03', 'ADMIN_BO3O (uid: 0) possibly teleport hacked (distance: 3258.1)'),
(1337, '2023-03-17 13:31:22', 'Lmour_pholoko (uid: 0) possibly teleport hacked (distance: 692.0)'),
(1338, '2023-03-17 13:32:00', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 4499.3)'),
(1339, '2023-03-17 13:35:01', 'matouss_clean (uid: 121) possibly used airbreak.'),
(1340, '2023-03-17 13:36:21', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 4934.4)'),
(1341, '2023-03-17 13:39:12', 'Lmour_pholoko (uid: 0) possibly teleport hacked (distance: 950.6)'),
(1342, '2023-03-17 13:43:17', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 4679.4)'),
(1343, '2023-03-17 13:45:58', 'Lmour_pholoko (uid: 0) possibly teleport hacked (distance: 4917.4)'),
(1344, '2023-03-17 13:48:02', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 1426.5)'),
(1345, '2023-03-17 14:06:16', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 581.8)'),
(1346, '2023-03-17 14:15:19', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 1187.0)'),
(1347, '2023-03-17 14:19:32', 'Carlos_Messi (uid: 0) possibly teleport hacked (distance: 1889.3)'),
(1348, '2023-03-17 14:34:17', 'Chliha_Olmhjob (uid: 110) possibly teleport hacked (distance: 146.2)'),
(1349, '2023-03-17 14:36:31', 'salto_bikit (uid: 88) possibly teleport hacked (distance: 838.1)'),
(1350, '2023-03-17 14:46:00', 'Mistro_Roberto (uid: 42) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1351, '2023-03-17 14:46:20', 'Mistro_Roberto (uid: 42) possibly hacked armor. (old: 67.00, new: 100.00)'),
(1352, '2023-03-17 14:53:33', 'Mistro_Roberto (uid: 42) possibly hacked armor. (old: 20.00, new: 100.00)'),
(1353, '2023-03-17 14:56:42', 'Mistro_Roberto (uid: 42) possibly hacked armor. (old: 95.00, new: 100.00)'),
(1354, '2023-03-17 14:56:56', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 637.9)'),
(1355, '2023-03-17 14:58:26', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 577.8)'),
(1356, '2023-03-17 15:45:54', 'hmed_twil (uid: 131) possibly speedhacked, speed: 356.1 km/h'),
(1357, '2023-03-17 15:47:29', 'hmed_twil (uid: 131) possibly speedhacked, speed: 356.0 km/h'),
(1358, '2023-03-17 15:47:30', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.6 km/h'),
(1359, '2023-03-17 15:47:31', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.9 km/h'),
(1360, '2023-03-17 15:47:33', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.9 km/h'),
(1361, '2023-03-17 15:47:34', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.5 km/h'),
(1362, '2023-03-17 15:47:35', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.7 km/h'),
(1363, '2023-03-17 15:48:16', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 3252.7)'),
(1364, '2023-03-17 15:48:38', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 3939.9)'),
(1365, '2023-03-17 15:49:02', 'hmed_twil (uid: 131) possibly speedhacked, speed: 351.3 km/h'),
(1366, '2023-03-17 15:49:03', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.6 km/h'),
(1367, '2023-03-17 15:49:04', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.6 km/h'),
(1368, '2023-03-17 15:49:05', 'hmed_twil (uid: 131) possibly speedhacked, speed: 355.9 km/h'),
(1369, '2023-03-17 15:56:46', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 4595.7)'),
(1370, '2023-03-17 15:58:34', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 3624.3)'),
(1371, '2023-03-17 15:58:37', 'Trafik_Guzman (uid: 203) possibly teleport hacked (distance: 521.6)'),
(1372, '2023-03-17 15:59:39', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 4010.0)'),
(1373, '2023-03-17 15:59:58', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 2830.6)'),
(1374, '2023-03-17 16:00:27', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1375, '2023-03-17 16:02:38', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 3613.4)'),
(1376, '2023-03-17 16:03:07', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1377, '2023-03-17 18:05:46', 'Anwar_Mohamed (uid: 0) possibly teleport hacked (distance: 405.5)'),
(1378, '2023-03-17 18:35:24', 'yasser_elallawi (uid: 122) possibly teleport hacked (distance: 119.4)'),
(1379, '2023-03-17 19:03:32', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 578.8)'),
(1380, '2023-03-17 20:25:49', 'Andrew_Tate (uid: 162) possibly teleport hacked (distance: 521.6)'),
(1381, '2023-03-17 20:26:02', 'Andrew_Tate (uid: 162) possibly teleport hacked (distance: 209.1)'),
(1382, '2023-03-17 20:27:33', 'Andrew_Tate (uid: 162) possibly teleport hacked (distance: 3774.4)'),
(1383, '2023-03-17 20:39:45', 'LAMAR_PABLOX (uid: 12) possibly teleport hacked (distance: 105.7)'),
(1384, '2023-03-17 20:44:05', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 3627.6)'),
(1385, '2023-03-17 20:45:09', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 1162.4)'),
(1386, '2023-03-17 20:45:12', 'hmed_twil (uid: 131) possibly teleport hacked (distance: 1232.9)'),
(1387, '2023-03-17 21:09:15', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1388, '2023-03-17 21:11:29', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1389, '2023-03-17 21:14:51', 'hmed_twil (uid: 131) possibly hacked armor. (old: 60.00, new: 100.00)'),
(1390, '2023-03-17 21:20:25', 'hmed_twil (uid: 131) possibly speedhacked, speed: 353.2 km/h'),
(1391, '2023-03-17 21:20:40', 'hmed_twil (uid: 131) possibly speedhacked, speed: 370.4 km/h'),
(1392, '2023-03-17 21:20:41', 'hmed_twil (uid: 131) possibly speedhacked, speed: 439.8 km/h'),
(1393, '2023-03-17 21:20:57', 'hmed_twil (uid: 131) possibly speedhacked, speed: 392.9 km/h'),
(1394, '2023-03-17 21:32:11', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1395, '2023-03-17 21:39:01', 'SALIM_LUCAS (uid: 113) possibly teleport hacked (distance: 129.9)'),
(1396, '2023-03-17 21:41:27', 'hmed_twil (uid: 131) possibly speedhacked, speed: 396.1 km/h'),
(1397, '2023-03-17 21:42:30', 'hmed_twil (uid: 131) possibly speedhacked, speed: 369.7 km/h'),
(1398, '2023-03-17 21:42:31', 'hmed_twil (uid: 131) possibly speedhacked, speed: 425.8 km/h'),
(1399, '2023-03-17 21:42:32', 'hmed_twil (uid: 131) possibly speedhacked, speed: 434.1 km/h'),
(1400, '2023-03-17 21:42:33', 'hmed_twil (uid: 131) possibly speedhacked, speed: 371.1 km/h'),
(1401, '2023-03-17 22:04:10', 'STEVAW_MARTINEZ (uid: 48) possibly teleport hacked (distance: 327.5)'),
(1402, '2023-03-17 22:12:26', 'hmed_twil (uid: 131) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1403, '2023-03-17 22:25:14', 'hmed_twil (uid: 131) possibly hacked armor. (old: 56.00, new: 100.00)'),
(1404, '2023-03-18 14:08:31', 'CORLO_NEGRO (uid: 7) possibly teleport hacked (distance: 180.8)'),
(1405, '2023-03-18 14:34:21', 'CORLO_NEGRO (uid: 0) possibly teleport hacked (distance: 3533.8)'),
(1406, '2023-03-18 14:47:01', 'CORLO_NEGRO (uid: 7) possibly teleport hacked (distance: 132.3)'),
(1407, '2023-03-18 15:05:50', 'CORLO_NEGRO (uid: 7) possibly teleport hacked (distance: 1348.9)'),
(1408, '2023-03-18 15:54:01', 'JAIMSE_PALACIO (uid: 35) possibly used airbreak.'),
(1409, '2023-03-18 15:59:13', 'Dyablo_Dr3awi (uid: 70) possibly teleport hacked (distance: 180.7)'),
(1410, '2023-03-18 15:59:18', 'Dyablo_Dr3awi (uid: 70) possibly teleport hacked (distance: 182.2)'),
(1411, '2023-03-19 20:13:21', 'Chliha_Olmhjob (uid: 10) possibly teleport hacked (distance: 136.5)'),
(1412, '2023-03-19 20:30:52', 'yasser_elallawi (uid: 5) possibly teleport hacked (distance: 116.2)'),
(1413, '2023-03-19 21:13:50', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 4638.1)'),
(1414, '2023-03-19 22:49:47', 'Raynez_Partida (uid: 25) possibly used airbreak.'),
(1415, '2023-03-19 23:16:07', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 1355.4)'),
(1416, '2023-03-19 23:35:17', 'Dyablo_Dr3awi (uid: 28) possibly teleport hacked (distance: 521.4)'),
(1417, '2023-03-19 23:35:18', 'Dyablo_Dr3awi (uid: 28) possibly teleport hacked (distance: 792.4)'),
(1418, '2023-03-20 00:18:11', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 234.1)'),
(1419, '2023-03-20 00:59:17', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 2191.4)'),
(1420, '2023-03-20 01:26:51', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 1276.6)'),
(1421, '2023-03-20 01:27:49', 'James_Edrian (uid: 16) possibly hacked armor. (old: 4.00, new: 253.00)'),
(1422, '2023-03-20 04:01:30', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 1560.5)'),
(1423, '2023-03-20 04:19:42', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 1813.6)'),
(1424, '2023-03-20 04:34:07', 'STEVAW_MARTINEZ (uid: 9) possibly speedhacked, speed: 369.7 km/h'),
(1425, '2023-03-20 04:34:08', 'STEVAW_MARTINEZ (uid: 9) possibly speedhacked, speed: 378.7 km/h'),
(1426, '2023-03-20 04:34:09', 'STEVAW_MARTINEZ (uid: 9) possibly speedhacked, speed: 356.6 km/h'),
(1427, '2023-03-20 04:34:10', 'STEVAW_MARTINEZ (uid: 9) possibly speedhacked, speed: 355.5 km/h'),
(1428, '2023-03-20 04:34:11', 'STEVAW_MARTINEZ (uid: 9) possibly speedhacked, speed: 357.4 km/h'),
(1429, '2023-03-20 04:34:12', 'STEVAW_MARTINEZ (uid: 9) possibly speedhacked, speed: 357.5 km/h'),
(1430, '2023-03-20 05:34:21', 'CORLO_NEGRO (uid: 30) possibly teleport hacked (distance: 165.0)'),
(1431, '2023-03-20 10:58:20', 'Pablo_Walid (uid: 4) possibly used airbreak.'),
(1432, '2023-03-20 11:31:24', 'LHAJ_SFIRAA (uid: 31) possibly teleport hacked (distance: 4493.7)'),
(1433, '2023-03-20 11:49:04', 'Pablo_Walid (uid: 4) possibly teleport hacked (distance: 362.3)'),
(1434, '2023-03-20 11:51:46', 'Pablo_Walid (uid: 4) possibly teleport hacked (distance: 174.0)'),
(1435, '2023-03-20 12:00:38', 'Pablo_Walid (uid: 4) possibly teleport hacked (distance: 276.9)'),
(1436, '2023-03-20 12:24:06', 'Pablo_Walid (uid: 4) possibly teleport hacked (distance: 107.2)'),
(1437, '2023-03-20 13:22:38', 'COROMBO_PABLO (uid: 33) possibly teleport hacked (distance: 3203.3)'),
(1438, '2023-03-20 13:46:16', 'Anwar_Mohamed (uid: 34) possibly teleport hacked (distance: 521.6)'),
(1439, '2023-03-20 13:46:29', 'Anwar_Mohamed (uid: 34) possibly teleport hacked (distance: 209.1)'),
(1440, '2023-03-20 14:06:31', 'AJAXX_SIPO (uid: 35) possibly teleport hacked (distance: 3599.4)'),
(1441, '2023-03-20 14:08:57', 'AJAXX_SIPO (uid: 35) possibly teleport hacked (distance: 1721.0)'),
(1442, '2023-03-20 14:09:46', 'AJAXX_SIPO (uid: 35) possibly teleport hacked (distance: 1550.7)'),
(1443, '2023-03-20 15:13:15', 'PABLO_PICASO (uid: 6) possibly teleport hacked (distance: 286.2)'),
(1444, '2023-03-20 15:13:18', 'PABLO_PICASO (uid: 6) possibly teleport hacked (distance: 199.9)'),
(1445, '2023-03-20 15:13:18', 'PABLO_PICASO (uid: 6) possibly teleport hacked (distance: 113.6)'),
(1446, '2023-03-20 15:13:18', 'PABLO_PICASO (uid: 6) possibly teleport hacked (distance: 103.7)'),
(1447, '2023-03-20 15:13:18', 'PABLO_PICASO (uid: 6) possibly teleport hacked (distance: 113.6)'),
(1448, '2023-03-20 15:13:18', 'PABLO_PICASO (uid: 6) possibly teleport hacked (distance: 103.7)'),
(1449, '2023-03-20 15:17:01', 'PABLO_PICASO (uid: 6) possibly teleport hacked (distance: 1019.2)'),
(1450, '2023-03-20 17:14:01', 'CORLO_NEGRO (uid: 0) possibly teleport hacked (distance: 1370.8)'),
(1451, '2023-03-20 18:46:40', 'psiko_boukhris (uid: 0) possibly teleport hacked (distance: 1152.8)'),
(1452, '2023-03-20 20:19:24', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 1783.0)'),
(1453, '2023-03-20 22:43:25', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 709.7)'),
(1454, '2023-03-20 23:06:55', 'karim_pablo (uid: 0) possibly teleport hacked (distance: 725.4)'),
(1455, '2023-03-21 00:43:19', 'psiko_boukhris (uid: 0) possibly teleport hacked (distance: 3537.2)'),
(1456, '2023-03-21 13:15:00', 'abdollah_algnawi (uid: 0) possibly teleport hacked (distance: 746.4)'),
(1457, '2023-03-21 13:19:07', 'SALIM_LUCAS (uid: 43) possibly teleport hacked (distance: 3603.7)'),
(1458, '2023-03-21 13:27:07', 'SALIM_LUCAS (uid: 43) possibly teleport hacked (distance: 205.3)'),
(1459, '2023-03-21 19:01:31', 'Hamdi_johnson (uid: 45) possibly teleport hacked (distance: 103.8)'),
(1460, '2023-03-22 01:30:05', 'STEVAW_MARTINEZ (uid: 9) possibly hacked armor. (old: 25.00, new: 100.00)'),
(1461, '2023-03-22 04:57:28', 'Snop_Amar (uid: 47) possibly teleport hacked (distance: 254.0)'),
(1462, '2023-03-22 05:00:19', 'Snop_Amar (uid: 47) possibly teleport hacked (distance: 836.2)'),
(1463, '2023-03-22 12:34:13', 'STEVAW_MARTINEZ (uid: 9) possibly hacked armor. (old: 0.00, new: 100.00)'),
(1464, '2023-03-22 12:36:16', 'STEVAW_MARTINEZ (uid: 9) possibly teleport hacked (distance: 577.9)'),
(1465, '2023-03-22 19:46:58', 'LAMAR_PABLOX (uid: 19) possibly teleport hacked (distance: 538.9)'),
(1466, '2023-03-22 21:19:24', 'AYMEN_LME3DAWI (uid: 14) possibly used airbreak.'),
(1467, '2023-03-23 23:23:31', 'yasser_elallawi (uid: 5) possibly teleport hacked (distance: 289.0)'),
(1468, '2023-03-24 19:28:26', 'AMRO_MINE (uid: 57) possibly used airbreak.'),
(1469, '2023-03-24 19:28:41', 'AMRO_MINE (uid: 0) possibly teleport hacked (distance: 731.4)'),
(1470, '2023-03-24 19:34:28', 'AMRO_MINE (uid: 0) possibly teleport hacked (distance: 3860.9)'),
(1471, '2023-03-24 19:36:01', 'AMRO_MINE (uid: 0) possibly teleport hacked (distance: 3798.3)'),
(1472, '2023-03-25 01:17:38', 'AMRO_MINE (uid: 0) possibly teleport hacked (distance: 825.9)'),
(1473, '2023-03-25 14:18:30', 'Cryston_Robert (uid: 0) possibly teleport hacked (distance: 267.6)'),
(1474, '2023-03-25 14:37:04', 'AMRO_MINE (uid: 0) possibly teleport hacked (distance: 1115.3)'),
(1475, '2023-03-25 14:48:54', 'Selfx_Tchapo (uid: 70) possibly teleport hacked (distance: 1869.5)'),
(1476, '2023-03-25 14:50:39', 'Selfx_Tchapo (uid: 70) possibly teleport hacked (distance: 3533.4)'),
(1477, '2023-03-25 14:50:57', 'Selfx_Tchapo (uid: 70) possibly teleport hacked (distance: 2464.9)'),
(1478, '2023-03-25 14:51:17', 'Selfx_Tchapo (uid: 70) possibly teleport hacked (distance: 4095.9)'),
(1479, '2023-03-25 16:52:01', 'hmed_twil (uid: 72) possibly teleport hacked (distance: 4595.6)'),
(1480, '2023-03-26 13:52:46', 'mohamad_goto (uid: 0) possibly teleport hacked (distance: 1450.3)'),
(1481, '2023-03-26 13:53:28', 'mohamad_goto (uid: 82) possibly teleport hacked (distance: 127.6)'),
(1482, '2023-03-26 13:56:09', 'mohamad_goto (uid: 0) possibly teleport hacked (distance: 1452.1)'),
(1483, '2023-03-26 19:53:43', 'mohamad_goto (uid: 0) possibly teleport hacked (distance: 563.1)'),
(1484, '2023-03-26 22:17:31', 'Kvara_escobar (uid: 86) possibly used airbreak.'),
(1485, '2023-03-26 22:37:27', 'Ayoub_bakh (uid: 84) possibly teleport hacked (distance: 1056.1)'),
(1486, '2023-03-26 22:42:56', 'Ayoub_bakh (uid: 84) possibly teleport hacked (distance: 4495.4)'),
(1487, '2023-03-26 23:05:50', 'Cedos_Sparow (uid: 64) possibly teleport hacked (distance: 2948.4)'),
(1488, '2023-03-27 01:58:21', 'BADR_PEDRI (uid: 88) possibly teleport hacked (distance: 448.1)'),
(1489, '2023-03-27 01:58:27', 'BADR_PEDRI (uid: 88) possibly teleport hacked (distance: 199.9)'),
(1490, '2023-03-27 01:58:27', 'BADR_PEDRI (uid: 88) possibly teleport hacked (distance: 113.7)'),
(1491, '2023-03-27 01:58:27', 'BADR_PEDRI (uid: 88) possibly teleport hacked (distance: 103.8)'),
(1492, '2023-03-27 01:58:27', 'BADR_PEDRI (uid: 88) possibly teleport hacked (distance: 113.7)'),
(1493, '2023-03-27 01:58:27', 'BADR_PEDRI (uid: 88) possibly teleport hacked (distance: 103.8)'),
(1494, '2023-03-27 01:59:30', 'BADR_PEDRI (uid: 88) possibly teleport hacked (distance: 385.6)'),
(1495, '2023-03-27 11:44:05', 'Cheblyyy_Baggio (uid: 73) possibly speedhacked, speed: 1992.4 km/h');

-- --------------------------------------------------------

--
-- Structure de la table `log_contracts`
--

CREATE TABLE `log_contracts` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_faction`
--

CREATE TABLE `log_faction` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_faction`
--

INSERT INTO `log_faction` (`id`, `date`, `description`) VALUES
(1613, '2023-01-31 22:00:51', 'Karam_Billionaire (uid: 1243) kicked Karam_Billionaire (uid: 1243) from Police Los Santos (id: 0) as rank Unspecified (5).'),
(1614, '2023-02-01 16:58:18', 'Alphonso_Viper (uid: 1241) has quit Police Los Santos (id: 0) has rank Unspecified (1).'),
(1615, '2023-02-10 18:02:07', 'Karam_Billionaire (uid: 1243) kicked Karam_Billionaire (uid: 1243) from Burger Shot Los Santos (id: 4) as rank Unspecified (5).'),
(1616, '2023-02-16 23:43:25', 'Karam_Billionaire (uid: 1243) kicked Karam_Billionaire (uid: 1243) from Police Los Santos (id: 0) as rank Unspecified (5).'),
(1617, '2023-02-19 21:31:37', 'Karam_Billionaire (uid: 1281) has quit Police Los Santos (id: 0) has rank Unspecified (5).'),
(1618, '2023-02-20 15:01:37', 'Michael_Zodiac (uid: 1265) has quit Police Los Santos (id: 0) has rank Chef Police (5).'),
(1619, '2023-02-21 01:46:10', 'HAMOCHI_SIROM (uid: 1271) has invited LKHRAZ_ML (uid: 1297) to Police Los Santos (id: 0).'),
(1620, '2023-03-14 16:59:01', 'Tyson_Choppa (uid: 37) has invited PROF_TIMSA7 (uid: 59) to Police Los Santos (id: 0).'),
(1621, '2023-03-14 17:04:24', 'Tyson_Choppa (uid: 37) has invited Anwar_Mohamed (uid: 60) to Police Los Santos (id: 0).'),
(1622, '2023-03-14 17:06:01', 'Tyson_Choppa (uid: 37) has invited Rachid_ekambi (uid: 17) to Police Los Santos (id: 0).'),
(1623, '2023-03-14 17:06:16', 'Tyson_Choppa (uid: 37) has set Rachid_ekambi\'s (uid: 17) rank in Police Los Santos (id: 0) to Co Chef Police (4).'),
(1624, '2023-03-14 17:07:15', 'Tyson_Choppa (uid: 37) has set Anwar_Mohamed\'s (uid: 60) rank in Police Los Santos (id: 0) to Special Police (3).'),
(1625, '2023-03-14 17:30:41', 'Tyson_Choppa (uid: 37) has set Anwar_Mohamed\'s (uid: 60) rank in Police Los Santos (id: 0) to Chef Police (5).'),
(1626, '2023-03-14 17:30:57', 'Felix_Jigo (uid: 3) has set Felix_Jigo\'s (uid: 3) rank in Mechanic Los Santos (id: 3) to Chef Mechanic (5).'),
(1627, '2023-03-14 17:47:26', 'Tyson_Choppa (uid: 37) has given Anas_Tali (uid: 63) a ticket for $1000.'),
(1628, '2023-03-14 17:58:22', 'Tyson_Choppa (uid: 37) has invited ZIZWAR_7M7 (uid: 26) to Police Los Santos (id: 0).'),
(1629, '2023-03-14 17:59:34', 'Tyson_Choppa (uid: 37) has invited Tropa_Williams (uid: 80) to Police Los Santos (id: 0).'),
(1630, '2023-03-14 18:09:05', 'Felix_Jigo (uid: 3) has invited Nfha_Doo (uid: 30) to Mechanic Los Santos (id: 3).'),
(1631, '2023-03-14 18:19:10', 'Tyson_Choppa (uid: 37) has set Anwar_Mohamed\'s (uid: 60) rank in Police Los Santos (id: 0) to Special Police (3).'),
(1632, '2023-03-14 18:41:56', 'Rachid_ekambi (uid: 17) has invited LMCH_NATAZI (uid: 83) to Police Los Santos (id: 0).'),
(1633, '2023-03-14 23:35:07', 'Rachid_ekambi (uid: 17) has invited Chliha_Olmhjob (uid: 110) to Police Los Santos (id: 0).'),
(1634, '2023-03-15 13:27:44', 'abdollah_algnawi (uid: 14) has given Vini_Edrian (uid: 23) a ticket for $1500.'),
(1635, '2023-03-15 13:54:53', 'Tyson_Choppa (uid: 37) has invited hmed_twil (uid: 131) to Police Los Santos (id: 0).'),
(1636, '2023-03-15 13:55:31', 'Tyson_Choppa (uid: 37) has set hmed_twil\'s (uid: 131) rank in Police Los Santos (id: 0) to Head Police (1).'),
(1637, '2023-03-15 13:56:05', 'Tyson_Choppa (uid: 37) has set hmed_twil\'s (uid: 131) rank in Police Los Santos (id: 0) to Trial Memeber Police (0).'),
(1638, '2023-03-15 14:46:19', 'Rachid_ekambi (uid: 17) has invited Yassir_sancho (uid: 135) to Police Los Santos (id: 0).'),
(1639, '2023-03-15 14:47:25', 'Chliha_Olmhjob (uid: 110) has given Ismail_guzmane (uid: 105) a ticket for $1000.'),
(1640, '2023-03-15 15:57:51', 'Tyson_Choppa (uid: 37) has invited anuar_oustora (uid: 133) to Police Los Santos (id: 0).'),
(1641, '2023-03-15 16:18:08', 'Rachid_ekambi (uid: 17) has invited dizzy_dros (uid: 139) to Police Los Santos (id: 0).'),
(1642, '2023-03-15 16:19:37', 'Rachid_ekambi (uid: 17) has invited STEVAW_MARTINEZ (uid: 48) to Police Los Santos (id: 0).'),
(1643, '2023-03-15 16:25:04', 'Rachid_ekambi (uid: 17) has quit Medical Los Santos (id: 1) has rank Chef Medic (5).'),
(1644, '2023-03-15 16:25:19', 'Rachid_ekambi (uid: 17) has quit News Los Santos (id: 2) has rank Unspecified (5).'),
(1645, '2023-03-15 16:25:25', 'Rachid_ekambi (uid: 17) has quit Mechanic Los Santos (id: 3) has rank Chef Mechanic (5).'),
(1646, '2023-03-15 16:25:27', 'Rachid_ekambi (uid: 17) has quit Burger Shot Los Santos (id: 4) has rank Unspecified (5).'),
(1647, '2023-03-15 16:25:29', 'Rachid_ekambi (uid: 17) has quit Burger Shot Los Santos (id: 4) has rank Unspecified (5).'),
(1648, '2023-03-15 16:25:33', 'Rachid_ekambi (uid: 17) has quit Federal Fbi Los Santos (id: 5) has rank Unspecified (5).'),
(1649, '2023-03-15 17:19:47', 'ALVARO_MORATA (uid: 75) has invited James_Edrian (uid: 36) to Medical Los Santos (id: 1).'),
(1650, '2023-03-15 17:21:52', 'ALVARO_MORATA (uid: 75) has set James_Edrian\'s (uid: 36) rank in Medical Los Santos (id: 1) to Chef Medic (5).'),
(1651, '2023-03-15 17:31:58', 'STEVAW_MARTINEZ (uid: 48) has quit Police Los Santos (id: 0) has rank Trial Memeber Police (0).'),
(1652, '2023-03-15 18:36:25', 'Rachid_ekambi (uid: 17) has invited NMS_FLIX (uid: 143) to Police Los Santos (id: 0).'),
(1653, '2023-03-15 21:33:58', 'James_Edrian (uid: 36) has invited Vini_Edrian (uid: 23) to Medical Los Santos (id: 1).'),
(1654, '2023-03-15 21:34:13', 'James_Edrian (uid: 36) has set Vini_Edrian\'s (uid: 23) rank in Medical Los Santos (id: 1) to Chef Medic (5).'),
(1655, '2023-03-15 22:19:38', 'Felix_Jigo (uid: 98) has invited dbana_garcia (uid: 140) to Mechanic Los Santos (id: 3).'),
(1656, '2023-03-15 22:35:49', 'Tyson_Choppa (uid: 37) has invited Jack_Hunter (uid: 120) to Police Los Santos (id: 0).'),
(1657, '2023-03-15 22:42:53', 'Vini_Edrian (uid: 23) has set ALVARO_MORATA\'s (uid: 75) rank in Medical Los Santos (id: 1) to Special Medic (3).'),
(1658, '2023-03-15 22:45:30', 'Tyson_Choppa (uid: 37) has invited RAMZI__HAMO (uid: 150) to Police Los Santos (id: 0).'),
(1659, '2023-03-15 22:46:33', 'Oualid_Jackson (uid: 85) offline kicked pedro_Admin (uid: 2) from News Los Santos (id: 2) as rank Unspecified (5).'),
(1660, '2023-03-15 23:15:50', 'James_Edrian (uid: 36) has invited Kaspre_Edrian (uid: 29) to Medical Los Santos (id: 1).'),
(1661, '2023-03-15 23:16:05', 'James_Edrian (uid: 36) has set Kaspre_Edrian\'s (uid: 29) rank in Medical Los Santos (id: 1) to Co Chef Medic (4).'),
(1662, '2023-03-16 12:32:47', 'Oualid_Jackson (uid: 85) has invited HOUSSAM_KABBACHE (uid: 169) to News Los Santos (id: 2).'),
(1663, '2023-03-16 13:29:21', 'GOD_TIPO (uid: 125) has quit Mechanic Los Santos (id: 3) has rank Chef Mechanic (5).'),
(1664, '2023-03-16 13:38:36', 'Felix_Jigo (uid: 98) has set CORLO_NEGRO\'s (uid: 7) rank in Mechanic Los Santos (id: 3) to Co Chef Mechanic (4).'),
(1665, '2023-03-16 13:46:12', 'LMCH_NATAZI (uid: 83) has given Savage_Alexander (uid: 171) a ticket for $2500.'),
(1666, '2023-03-16 13:50:16', 'Unknown_ (uid: 94) has quit News Los Santos (id: 2) has rank Unspecified (5).'),
(1667, '2023-03-16 14:30:57', 'Rachid_ekambi (uid: 17) has quit News Los Santos (id: 2) has rank Unspecified (5).'),
(1668, '2023-03-16 14:32:38', 'Rachid_ekambi (uid: 17) has invited Lucas_Morinio (uid: 147) to Police Los Santos (id: 0).'),
(1669, '2023-03-16 15:43:51', 'abdollah_algnawi (uid: 14) has quit Police Los Santos (id: 0) has rank Trial Memeber Police (0).'),
(1670, '2023-03-16 15:44:04', 'Rachid_ekambi (uid: 17) has invited abdollah_algnawi (uid: 14) to Police Los Santos (id: 0).'),
(1671, '2023-03-16 16:16:28', 'Felix_Jigo (uid: 98) has invited JAIMSE_PALACIO (uid: 35) to Mechanic Los Santos (id: 3).'),
(1672, '2023-03-16 16:39:33', 'Yassir_sancho (uid: 135) has given dbana_garcia (uid: 140) a ticket for $2500.'),
(1673, '2023-03-16 17:07:07', 'Yassir_sancho (uid: 135) has given Matrax_Smoker (uid: 184) a ticket for $2500.'),
(1674, '2023-03-16 17:08:46', 'Rachid_ekambi (uid: 17) has quit News Los Santos (id: 2) has rank CHEF (5).'),
(1675, '2023-03-16 17:09:59', 'Rachid_ekambi (uid: 17) has set Rachid_ekambi\'s (uid: 17) rank in Police Los Santos (id: 0) to CO CHEF OF POLICE (4).'),
(1676, '2023-03-16 17:42:41', 'Yassir_sancho (uid: 135) has given Matrax_Smoker (uid: 184) a ticket for $1000.'),
(1677, '2023-03-16 18:58:48', 'James_Edrian (uid: 36) has invited Alex_Cobra (uid: 1) to Medical Los Santos (id: 1).'),
(1678, '2023-03-16 18:58:57', 'James_Edrian (uid: 36) has set Alex_Cobra\'s (uid: 1) rank in Medical Los Santos (id: 1) to Chef Medic (5).'),
(1679, '2023-03-16 19:10:02', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to Unspecified (9).'),
(1680, '2023-03-16 19:10:19', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to Unspecified (10).'),
(1681, '2023-03-16 19:17:32', 'Oualid_Jackson (uid: 85) offline kicked HOUSSAM_KABBACHE (uid: 169) from News Los Santos (id: 2) as rank Unspecified (0).'),
(1682, '2023-03-16 19:19:15', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to DOCTEUR (5).'),
(1683, '2023-03-16 19:19:18', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to AID DOCTEUR (4).'),
(1684, '2023-03-16 19:19:21', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to DOCTEUR (5).'),
(1685, '2023-03-16 19:19:23', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to BNAJ (3).'),
(1686, '2023-03-16 19:20:03', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to FRMLI (2).'),
(1687, '2023-03-16 19:20:12', 'GOD_TIPO (uid: 125) has set GOD_TIPO\'s (uid: 125) rank in Medical Los Santos (id: 1) to FRMLIA (1).'),
(1688, '2023-03-16 20:15:36', 'Rachid_ekambi (uid: 17) has charged James_Edrian (uid: 36) with hareb mn comico okan 3ndo t7e9i9'),
(1689, '2023-03-17 13:34:22', 'GOD_TIPO (uid: 125) has quit Medical Los Santos (id: 1) has rank chef medic (5).'),
(1690, '2023-03-17 15:00:48', 'Rachid_ekambi (uid: 17) has invited NEJI_FLIX (uid: 192) to Police Los Santos (id: 0).'),
(1691, '2023-03-17 16:31:24', 'X_Mafia (uid: 163) has quit Police Los Santos (id: 0) has rank Unspecified (1).'),
(1692, '2023-03-17 16:32:49', 'X_Mafia (uid: 163) has quit Police Los Santos (id: 0) has rank Unspecified (0).'),
(1693, '2023-03-18 15:46:22', 'Tyson_Choppa (uid: 37) has invited Dyablo_Dr3awi (uid: 70) to Police Los Santos (id: 0).'),
(1694, '2023-03-18 16:07:45', 'GOD TIPO (uid: 125) has deleted faction  (id: 7).'),
(1695, '2023-03-18 16:26:34', 'Tyson_Choppa (uid: 37) has set abdollah_algnawi\'s (uid: 14) rank in Police Los Santos (id: 0) to OFFICER 1 (1).'),
(1696, '2023-03-18 16:26:40', 'Tyson_Choppa (uid: 37) has set abdollah_algnawi\'s (uid: 14) rank in Police Los Santos (id: 0) to OFFICER 2 (2).'),
(1697, '2023-03-18 16:27:36', 'Tyson_Choppa (uid: 37) has quit Police Los Santos (id: 0) has rank CHEIF (17).'),
(1698, '2023-03-18 16:28:17', 'ALVARO_MORATA (uid: 75) has quit Medical Los Santos (id: 1) has rank special medic (3).'),
(1699, '2023-03-18 16:28:50', 'Tyson_Choppa (uid: 37) has set ALVARO_MORATA\'s (uid: 75) rank in Police Los Santos (id: 0) to OFFICER 1 (1).'),
(1700, '2023-03-18 16:59:34', 'Dyablo_Dr3awi (uid: 70) has taken Dyablo_Dr3awi\'s (uid: 70) weapons.'),
(1701, '2023-03-18 16:59:50', 'Dyablo_Dr3awi (uid: 70) has taken X_Mafia\'s (uid: 163) weapons.'),
(1702, '2023-03-18 16:59:54', 'Dyablo_Dr3awi (uid: 70) has taken X_Mafia\'s (uid: 163) weapons.'),
(1703, '2023-03-18 17:03:41', 'Tyson_Choppa (uid: 37) has set Anwar_Mohamed\'s (uid: 60) rank in Police Los Santos (id: 0) to COMMANDER (11).'),
(1704, '2023-03-19 20:10:04', 'NMS_FLIX (uid: 13) has invited abdollah_algnawi (uid: 12) to Police Los Santos (id: 0).'),
(1705, '2023-03-19 20:28:40', 'abdollah_algnawi (uid: 12) has charged GOD_TIPO (uid: 11) with dasr'),
(1706, '2023-03-19 20:32:05', 'GOD_TIPO (uid: 11) has invited Tyson_Choppa (uid: 18) to Police Los Santos (id: 0).'),
(1707, '2023-03-19 20:32:23', 'GOD_TIPO (uid: 11) has set Tyson_Choppa\'s (uid: 18) rank in Police Los Santos (id: 0) to ASSISTANT CHIEF (16).'),
(1708, '2023-03-19 20:32:26', 'GOD_TIPO (uid: 11) has set Tyson_Choppa\'s (uid: 18) rank in Police Los Santos (id: 0) to CHIEF (17).'),
(1709, '2023-03-19 20:32:58', 'Tyson_Choppa (uid: 18) has set abdollah_algnawi\'s (uid: 12) rank in Police Los Santos (id: 0) to OFFICER 2 (2).'),
(1710, '2023-03-19 22:15:11', 'GOD_TIPO (uid: 11) has quit Medical Los Santos (id: 1) has rank chef medic (5).'),
(1711, '2023-03-19 22:16:00', 'NMS_FLIX (uid: 13) kicked NMS_FLIX (uid: 13) from Police Los Santos (id: 0) as rank CHIEF (17).'),
(1712, '2023-03-20 01:41:32', 'Vini_Edrian (uid: 7) kicked Marroki_Crazy (uid: 26) from Medical Los Santos (id: 1) as rank chef medic (5).'),
(1713, '2023-03-20 14:40:41', 'Vini_Edrian (uid: 7) has invited Aymen_Stunt (uid: 21) to Medical Los Santos (id: 1).'),
(1714, '2023-03-20 21:24:45', 'abdollah_algnawi (uid: 12) has taken Dyablo_Dr3awi\'s (uid: 28) weapons.'),
(1715, '2023-03-20 21:24:47', 'abdollah_algnawi (uid: 12) has taken Dyablo_Dr3awi\'s (uid: 28) weapons.'),
(1716, '2023-03-20 21:24:49', 'abdollah_algnawi (uid: 12) has taken Dyablo_Dr3awi\'s (uid: 28) weapons.'),
(1717, '2023-03-20 22:12:58', 'GOD_TIPO (uid: 11) has quit Mechanic Los Santos (id: 3) has rank Unspecified (5).'),
(1718, '2023-03-21 19:02:40', 'Vini_Edrian (uid: 7) has quit MKHZN (id: 6) has rank Unspecified (12).'),
(1719, '2023-03-21 19:05:02', 'Dyablo_Dr3awi (uid: 28) has quit Burger Shot Los Santos (id: 4) has rank BIG CHEF (5).'),
(1720, '2023-03-25 17:40:18', 'GOD_TIPO (uid: 11) has invited benzz_lcasawi (uid: 71) to Police Los Santos (id: 0).'),
(1721, '2023-03-26 03:33:39', 'psiko_boukhris (uid: 1) has quit MKHZN (id: 6) has rank Unspecified (12).');

-- --------------------------------------------------------

--
-- Structure de la table `log_gang`
--

CREATE TABLE `log_gang` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_gang`
--

INSERT INTO `log_gang` (`id`, `date`, `description`) VALUES
(1, '2023-02-01 16:55:12', 'Alphonso_Viper (uid: 1241) has quit Varios Astecas Los Santos (id: 0) has rank Unspecified (6).'),
(2, '2023-02-01 16:58:11', 'Alphonso_Viper (uid: 1241) has quit Varios Astecas Los Santos (id: 0) has rank Unspecified (6).'),
(3, '2023-02-06 05:33:11', 'Karam_Billionaire (uid: 1243) kicked Karam_Billionaire (uid: 1243) from Vagos Los Santos (id: 1) as rank Unspecified (6).'),
(4, '2023-02-16 15:50:44', 'Karam_Billionaire (uid: 1243) has quit Grove Stret Families (id: 0) has rank Unspecified (1).'),
(5, '2023-02-20 07:14:57', 'Michael_Zodiac (uid: 1265) has quit Grove Stret Families (id: 0) has rank Unspecified (6).'),
(6, '2023-02-20 15:00:36', 'Michael_Zodiac (uid: 1265) has quit Front Yard Ballas (id: 2) has rank Unspecified (6).'),
(7, '2023-03-14 15:34:02', 'BADR_PABLO (uid: 10) has invited UTCHIHA_PABLO (uid: 15) to Grove Stret Families (id: 0).'),
(8, '2023-03-14 15:34:05', 'BADR_PABLO (uid: 10) has invited Pedro_Tilox (uid: 39) to Grove Stret Families (id: 0).'),
(9, '2023-03-14 15:36:30', 'BADR_PABLO (uid: 10) has invited L3ALAWI_PEDRI (uid: 19) to Grove Stret Families (id: 0).'),
(10, '2023-03-14 15:36:34', 'Mistro_Roberto (uid: 42) has invited Limbo_sinyore (uid: 8) to Front Yard Ballas (id: 2).'),
(11, '2023-03-14 15:36:56', 'Mistro_Roberto (uid: 42) has set Limbo_sinyore\'s (uid: 8) rank in Front Yard Ballas (id: 2) to Unspecified (6).'),
(12, '2023-03-14 15:42:39', 'dob_lghaba (uid: 45) has invited JAIMSE_PALACIO (uid: 35) to Los Santos Vagos (id: 1).'),
(13, '2023-03-14 15:43:04', 'dob_lghaba (uid: 45) has invited Abdelillah_rinio (uid: 44) to Los Santos Vagos (id: 1).'),
(14, '2023-03-14 15:43:22', 'dob_lghaba (uid: 45) has invited TWIST_PATRON (uid: 11) to Los Santos Vagos (id: 1).'),
(15, '2023-03-14 15:44:02', 'BADR_PABLO (uid: 10) has invited BOB_PABLO (uid: 18) to Grove Stret Families (id: 0).'),
(16, '2023-03-14 15:53:48', 'dob_lghaba (uid: 45) has invited NMS_PATRON (uid: 41) to Los Santos Vagos (id: 1).'),
(17, '2023-03-14 15:56:06', 'Limbo_sinyore (uid: 8) has invited AJAXX_SIPO (uid: 50) to Front Yard Ballas (id: 2).'),
(18, '2023-03-14 15:56:26', 'dob_lghaba (uid: 45) has invited YASSINE_GUZMAN (uid: 53) to Los Santos Vagos (id: 1).'),
(19, '2023-03-14 16:04:27', 'Vini_Edrian (uid: 23) has invited Kaspre_Edrian (uid: 29) to Los Santos Marabunta (id: 3).'),
(20, '2023-03-14 16:11:22', 'Vini_Edrian (uid: 23) has invited James_Edrian (uid: 36) to Los Santos Marabunta (id: 3).'),
(21, '2023-03-14 16:12:09', 'Vini_Edrian (uid: 23) has set James_Edrian\'s (uid: 36) rank in Los Santos Marabunta (id: 3) to Unspecified (6).'),
(22, '2023-03-14 16:12:26', 'Vini_Edrian (uid: 23) has quit Los Santos Marabunta (id: 3) has rank Unspecified (6).'),
(23, '2023-03-14 16:14:53', 'James_Edrian (uid: 36) has invited Vini_Edrian (uid: 23) to Los Santos Marabunta (id: 3).'),
(24, '2023-03-14 16:15:10', 'James_Edrian (uid: 36) has set Vini_Edrian\'s (uid: 23) rank in Los Santos Marabunta (id: 3) to Unspecified (6).'),
(25, '2023-03-14 16:24:28', 'ANAS_RAID (uid: 13) has quit Front Yard Ballas (id: 2) has rank Unspecified (6).'),
(26, '2023-03-14 16:24:49', 'dob_lghaba (uid: 45) has set NMS_PATRON\'s (uid: 41) rank in Los Santos Vagos (id: 1) to under boss (5).'),
(27, '2023-03-14 16:24:59', 'dob_lghaba (uid: 45) has invited ANAS_RAID (uid: 13) to Los Santos Vagos (id: 1).'),
(28, '2023-03-14 16:25:12', 'dob_lghaba (uid: 45) has set ANAS_RAID\'s (uid: 13) rank in Los Santos Vagos (id: 1) to under boss (5).'),
(29, '2023-03-14 16:28:25', 'ANAS_RAID (uid: 13) has invited Anas_Tali (uid: 63) to Los Santos Vagos (id: 1).'),
(30, '2023-03-14 16:28:35', 'NMS_PATRON (uid: 41) has invited Selfx_Tchapo (uid: 49) to Los Santos Vagos (id: 1).'),
(31, '2023-03-14 16:28:37', 'ANAS_RAID (uid: 13) has set Anas_Tali\'s (uid: 63) rank in Los Santos Vagos (id: 1) to Unspecified (2).'),
(32, '2023-03-14 16:33:04', 'dob_lghaba (uid: 45) has set NMS_PATRON\'s (uid: 41) rank in Los Santos Vagos (id: 1) to boss (6).'),
(33, '2023-03-14 16:33:09', 'NMS_PATRON (uid: 41) kicked dob_lghaba (uid: 45) from Los Santos Vagos (id: 1) as rank boss (6).'),
(34, '2023-03-14 16:33:19', 'NMS_PATRON (uid: 41) has invited dob_lghaba (uid: 45) to Los Santos Vagos (id: 1).'),
(35, '2023-03-14 16:33:30', 'NMS_PATRON (uid: 41) has set dob_lghaba\'s (uid: 45) rank in Los Santos Vagos (id: 1) to boss (6).'),
(36, '2023-03-14 16:33:33', 'dob_lghaba (uid: 45) has set NMS_PATRON\'s (uid: 41) rank in Los Santos Vagos (id: 1) to under boss (5).'),
(37, '2023-03-14 16:36:29', 'POCO_LOCO (uid: 34) has invited psiko_boukhris (uid: 54) to MAFIA (id: 7).'),
(38, '2023-03-14 16:46:15', 'dob_lghaba (uid: 45) has invited STEVAW_MARTINEZ (uid: 48) to Los Santos Vagos (id: 1).'),
(39, '2023-03-14 16:46:30', 'dob_lghaba (uid: 45) has set STEVAW_MARTINEZ\'s (uid: 48) rank in Los Santos Vagos (id: 1) to dbdob sghir  (3).'),
(40, '2023-03-14 17:00:20', 'NMS_PATRON (uid: 41) has invited Ziko_Lanios (uid: 71) to Los Santos Vagos (id: 1).'),
(41, '2023-03-14 17:05:52', 'NMS_PATRON (uid: 41) has invited JOHN_WICK (uid: 72) to Los Santos Vagos (id: 1).'),
(42, '2023-03-14 17:09:23', 'NMS_PATRON (uid: 41) has invited AYMEN_LME3DAWI (uid: 28) to Los Santos Vagos (id: 1).'),
(43, '2023-03-14 17:19:11', 'Vini_Edrian (uid: 23) has invited bababoy_Edrian (uid: 74) to Los Santos Marabunta (id: 3).'),
(44, '2023-03-14 17:44:33', 'POCO_LOCO (uid: 34) has invited Keyhell_GUANTANAMO (uid: 79) to MAFIA (id: 7).'),
(45, '2023-03-14 18:10:30', 'POCO_LOCO (uid: 34) has invited JUNIOR_VINICUIS (uid: 82) to MAFIA (id: 7).'),
(46, '2023-03-14 18:10:57', 'POCO_LOCO (uid: 34) has invited X_Mafia (uid: 56) to MAFIA (id: 7).'),
(47, '2023-03-14 18:11:01', 'POCO_LOCO (uid: 34) has set X_Mafia\'s (uid: 56) rank in MAFIA (id: 7) to Unspecified (5).'),
(48, '2023-03-14 18:24:42', 'Mistro_Roberto (uid: 42) has invited Lmour_pholoko (uid: 76) to Front Yard Ballas (id: 2).'),
(49, '2023-03-14 19:02:00', 'Mistro_Roberto (uid: 42) has set Lmour_pholoko\'s (uid: 76) rank in Front Yard Ballas (id: 2) to MISTRO (6).'),
(50, '2023-03-14 19:02:14', 'Mistro_Roberto (uid: 42) has set Limbo_sinyore\'s (uid: 8) rank in Front Yard Ballas (id: 2) to MISTRO (6).'),
(51, '2023-03-14 19:19:40', 'NMS_PATRON (uid: 41) has set JAIMSE_PALACIO\'s (uid: 35) rank in Los Santos Vagos (id: 1) to dbdob kbir (4).'),
(52, '2023-03-14 19:47:02', 'X_Mafia (uid: 56) has set LUCAS_GUANTANAMO\'s (uid: 40) rank in MAFIA (id: 7) to Unspecified (2).'),
(53, '2023-03-14 19:50:14', 'X_Mafia (uid: 56) has set LUCAS_GUANTANAMO\'s (uid: 40) rank in MAFIA (id: 7) to new man (0).'),
(54, '2023-03-14 20:12:56', 'Mistro_Roberto (uid: 42) has invited salto_bikit (uid: 88) to Front Yard Ballas (id: 2).'),
(55, '2023-03-14 20:55:54', 'Vini_Edrian (uid: 23) has invited Baby_Gang (uid: 92) to Los Santos Marabunta (id: 3).'),
(56, '2023-03-14 21:10:49', 'Limbo_sinyore (uid: 8) has invited Ayoub_Jasm (uid: 91) to Front Yard Ballas (id: 2).'),
(57, '2023-03-14 21:12:12', 'Limbo_sinyore (uid: 8) has invited Jlabanda_MDFK (uid: 93) to Front Yard Ballas (id: 2).'),
(58, '2023-03-14 21:14:06', 'Limbo_sinyore (uid: 8) has invited Carlos_Messi (uid: 90) to Front Yard Ballas (id: 2).'),
(59, '2023-03-14 21:54:02', 'Limbo_sinyore (uid: 8) has invited Eazy_Gaviria (uid: 100) to Front Yard Ballas (id: 2).'),
(60, '2023-03-14 22:24:26', 'Lmour_pholoko (uid: 76) kicked Limbo_sinyore (uid: 8) from Front Yard Ballas (id: 2) as rank MISTRO (6).'),
(61, '2023-03-14 22:24:49', 'Lmour_pholoko (uid: 76) has invited Limbo_sinyore (uid: 8) to Front Yard Ballas (id: 2).'),
(62, '2023-03-14 22:25:08', 'Lmour_pholoko (uid: 76) has set Limbo_sinyore\'s (uid: 8) rank in Front Yard Ballas (id: 2) to MISTRO (6).'),
(63, '2023-03-14 22:55:12', 'NMS_PATRON (uid: 41) has invited ALBIRT_DAVINCHI (uid: 47) to Los Santos Vagos (id: 1).'),
(64, '2023-03-14 23:09:10', 'Lmour_pholoko (uid: 76) kicked salto_bikit (uid: 88) from Front Yard Ballas (id: 2) as rank jdid (0).'),
(65, '2023-03-14 23:10:34', 'Lmour_pholoko (uid: 76) has invited salto_bikit (uid: 88) to Front Yard Ballas (id: 2).'),
(66, '2023-03-14 23:10:57', 'Lmour_pholoko (uid: 76) has invited Darwin_Watirson (uid: 106) to Front Yard Ballas (id: 2).'),
(67, '2023-03-14 23:11:02', 'Lmour_pholoko (uid: 76) has invited Zerx_Davirda (uid: 107) to Front Yard Ballas (id: 2).'),
(68, '2023-03-14 23:51:20', 'Limbo_sinyore (uid: 8) has invited SALIM_LUCAS (uid: 113) to Front Yard Ballas (id: 2).'),
(69, '2023-03-15 00:00:40', 'Alex_Bonelli (uid: 111) has invited Robert_Carlos (uid: 114) to Blancos (id: 8).'),
(70, '2023-03-15 00:01:44', 'Alex_Bonelli (uid: 111) has invited Snop_Doge (uid: 112) to Blancos (id: 8).'),
(71, '2023-03-15 00:02:13', 'Alex_Bonelli (uid: 111) has set Snop_Doge\'s (uid: 112) rank in Blancos (id: 8) to Unspecified (6).'),
(72, '2023-03-15 00:15:58', 'Limbo_sinyore (uid: 8) has invited Kwika_Sriwila (uid: 117) to Front Yard Ballas (id: 2).'),
(73, '2023-03-15 00:16:05', 'Limbo_sinyore (uid: 8) has invited WASSIM_LUCAS (uid: 116) to Front Yard Ballas (id: 2).'),
(74, '2023-03-15 00:16:48', 'Alex_Bonelli (uid: 111) has invited Si_Drogba (uid: 102) to Blancos (id: 8).'),
(75, '2023-03-15 00:25:57', 'Snop_Doge (uid: 112) has invited Vane_Slawi (uid: 104) to Blancos (id: 8).'),
(76, '2023-03-15 02:30:11', 'dob_lghaba (uid: 45) has set STEVAW_MARTINEZ\'s (uid: 48) rank in Los Santos Vagos (id: 1) to b9i jdid (1).'),
(77, '2023-03-15 02:30:32', 'dob_lghaba (uid: 45) has set STEVAW_MARTINEZ\'s (uid: 48) rank in Los Santos Vagos (id: 1) to dbdob sghir  (3).'),
(78, '2023-03-15 02:30:40', 'dob_lghaba (uid: 45) has set Anas_Tali\'s (uid: 63) rank in Los Santos Vagos (id: 1) to b9i jdid (1).'),
(79, '2023-03-15 10:48:56', 'Lmour_pholoko (uid: 76) has invited matouss_clean (uid: 121) to Front Yard Ballas (id: 2).'),
(80, '2023-03-15 10:49:50', 'Mistro_Roberto (uid: 42) has set WASSIM_LUCAS\'s (uid: 116) rank in Front Yard Ballas (id: 2) to LID LIMNA (5).'),
(81, '2023-03-15 11:33:01', 'Mistro_Roberto (uid: 42) deposits 250 materials in the gang stash.'),
(82, '2023-03-15 11:33:03', 'Lmour_pholoko (uid: 76) deposits 750 materials in the gang stash.'),
(83, '2023-03-15 11:33:21', 'Mistro_Roberto (uid: 42) deposited $17000 in the gang stash.'),
(84, '2023-03-15 11:33:35', 'Lmour_pholoko (uid: 76) deposited $10000 in the gang stash.'),
(85, '2023-03-15 11:54:25', 'Vini_Edrian (uid: 23) has set Kaspre_Edrian\'s (uid: 29) rank in Los Santos Marabunta (id: 3) to Under boss (5).'),
(86, '2023-03-15 12:47:54', 'Snop_Doge (uid: 112) has invited Ferda_Fratilo (uid: 126) to Blancos (id: 8).'),
(87, '2023-03-15 12:47:58', 'Snop_Doge (uid: 112) has invited Wadii_Robio (uid: 127) to Blancos (id: 8).'),
(88, '2023-03-15 12:48:38', 'Snop_Doge (uid: 112) has invited ferdaws_binili (uid: 128) to Blancos (id: 8).'),
(89, '2023-03-15 12:48:50', 'Snop_Doge (uid: 112) has set Wadii_Robio\'s (uid: 127) rank in Blancos (id: 8) to CO OG (5).'),
(90, '2023-03-15 12:50:46', 'Lmour_pholoko (uid: 76) deposited $20000 in the gang stash.'),
(91, '2023-03-15 13:10:08', 'Snop_Doge (uid: 112) has invited Si_Brazili (uid: 103) to Blancos (id: 8).'),
(92, '2023-03-15 15:00:09', 'Snop_Doge (uid: 112) has invited Comi_Escobar (uid: 123) to Blancos (id: 8).'),
(93, '2023-03-15 16:03:23', 'Snop_Doge (uid: 112) has invited Pitcho_Dasilva (uid: 132) to Blancos (id: 8).'),
(94, '2023-03-15 16:19:30', 'STEVAW_MARTINEZ (uid: 48) has quit Los Santos Vagos (id: 1) has rank dbdob sghir  (3).'),
(95, '2023-03-15 16:27:38', 'James_Edrian (uid: 36) has quit Los Santos Marabunta (id: 3) has rank Boss (6).'),
(96, '2023-03-15 17:32:49', 'Lmour_pholoko (uid: 76) has invited zamora_chadi (uid: 141) to Front Yard Ballas (id: 2).'),
(97, '2023-03-15 17:39:15', 'Lmour_pholoko (uid: 76) has set Eazy_Gaviria\'s (uid: 100) rank in Front Yard Ballas (id: 2) to LID LIMNA (5).'),
(98, '2023-03-15 17:39:19', 'Lmour_pholoko (uid: 76) has set Eazy_Gaviria\'s (uid: 100) rank in Front Yard Ballas (id: 2) to mrsm (1).'),
(99, '2023-03-15 18:05:15', 'Lmour_pholoko (uid: 76) kicked Carlos_Messi (uid: 90) from Front Yard Ballas (id: 2) as rank jdid (0).'),
(100, '2023-03-15 18:06:23', 'Lmour_pholoko (uid: 76) has invited Carlos_Messi (uid: 90) to Front Yard Ballas (id: 2).'),
(101, '2023-03-15 21:23:31', 'Vini_Edrian (uid: 23) has quit Los Santos Marabunta (id: 3) has rank Boss (6).'),
(102, '2023-03-15 22:16:44', 'Lmour_pholoko (uid: 76) has set Eazy_Gaviria\'s (uid: 100) rank in Front Yard Ballas (id: 2) to LID LIMNA (5).'),
(103, '2023-03-15 22:16:55', 'Lmour_pholoko (uid: 76) has set Eazy_Gaviria\'s (uid: 100) rank in Front Yard Ballas (id: 2) to mrsm (1).'),
(104, '2023-03-15 22:17:40', 'Jlabanda_MDFK (uid: 93) deposited $10000 in the gang stash.'),
(105, '2023-03-15 22:21:48', 'Chinwi_eltchapo (uid: 96) has invited DRISS_ESCOBAR (uid: 86) to Los Santos Bikers (id: 4).'),
(106, '2023-03-15 22:21:53', 'Chinwi_eltchapo (uid: 96) has set DRISS_ESCOBAR\'s (uid: 86) rank in Los Santos Bikers (id: 4) to Unspecified (5).'),
(107, '2023-03-15 23:15:49', 'Kaspre_Edrian (uid: 29) has quit Los Santos Marabunta (id: 3) has rank Under boss (5).'),
(108, '2023-03-15 23:28:44', 'dob_lghaba (uid: 45) has invited STEVAW_MARTINEZ (uid: 48) to Los Santos Vagos (id: 1).'),
(109, '2023-03-16 00:15:50', 'dob_lghaba (uid: 45) has set STEVAW_MARTINEZ\'s (uid: 48) rank in Los Santos Vagos (id: 1) to dbdob kbir (4).'),
(110, '2023-03-16 00:20:49', 'Darwin_Watirson (uid: 106) deposited $10000 in the gang stash.'),
(111, '2023-03-16 02:37:41', 'ANAS_RAID (uid: 13) has set Anas_Tali\'s (uid: 63) rank in Los Santos Vagos (id: 1) to wld drb  (2).'),
(112, '2023-03-16 02:40:22', 'ANAS_RAID (uid: 13) has set AYMEN_LME3DAWI\'s (uid: 28) rank in Los Santos Vagos (id: 1) to dbdob sghir  (3).'),
(113, '2023-03-16 02:40:36', 'ANAS_RAID (uid: 13) has set Anas_Tali\'s (uid: 63) rank in Los Santos Vagos (id: 1) to dbdob sghir  (3).'),
(114, '2023-03-16 02:42:05', 'ANAS_RAID (uid: 13) has set AYMEN_LME3DAWI\'s (uid: 28) rank in Los Santos Vagos (id: 1) to under boss (5).'),
(115, '2023-03-16 12:05:25', 'Mistro_Roberto (uid: 42) has invited White_Flash (uid: 166) to Front Yard Ballas (id: 2).'),
(116, '2023-03-16 12:40:36', 'Darwin_Watirson (uid: 106) deposited $10000 in the gang stash.'),
(117, '2023-03-16 13:08:21', 'POP_SMOKE (uid: 157) has invited Ayman_Pedro (uid: 167) to Los Santos Marabunta (id: 3).'),
(118, '2023-03-16 14:39:24', 'Mistro_Roberto (uid: 42) deposited $10000 in the gang stash.'),
(119, '2023-03-16 14:45:58', 'POP_SMOKE (uid: 157) has invited Bilomi_albert (uid: 152) to Los Santos Marabunta (id: 3).'),
(120, '2023-03-16 14:46:35', 'X_Mafia (uid: 163) has quit Los Santos Bloods (id: 5) has rank Unspecified (5).'),
(121, '2023-03-16 14:50:17', 'SHARLOC_SMOKERS (uid: 154) has invited TOM_SMOKER (uid: 176) to Los Santos Bloods (id: 5).'),
(122, '2023-03-16 14:50:26', 'SHARLOC_SMOKERS (uid: 154) has invited HADES_SMOKERS (uid: 178) to Los Santos Bloods (id: 5).'),
(123, '2023-03-16 14:56:36', 'SHARLOC_SMOKERS (uid: 154) has invited JERRY_SMOKER (uid: 173) to Los Santos Bloods (id: 5).'),
(124, '2023-03-16 15:01:26', 'SHARLOC_SMOKERS (uid: 154) has invited Pagero_Wang (uid: 179) to Los Santos Bloods (id: 5).'),
(125, '2023-03-16 15:02:09', 'SHARLOC_SMOKERS (uid: 154) has set JERRY_SMOKER\'s (uid: 173) rank in Los Santos Bloods (id: 5) to Unspecified (2).'),
(126, '2023-03-16 15:02:16', 'POP_SMOKE (uid: 157) has invited Ahmed_Sfriwi (uid: 148) to Los Santos Marabunta (id: 3).'),
(127, '2023-03-16 15:02:29', 'SHARLOC_SMOKERS (uid: 154) has set Pagero_Wang\'s (uid: 179) rank in Los Santos Bloods (id: 5) to Unspecified (2).'),
(128, '2023-03-16 15:23:23', 'James_Edrian (uid: 36) has quit Los Santos Bloods (id: 5) has rank Unspecified (6).'),
(129, '2023-03-16 15:29:01', 'Limbo_sinyore (uid: 8) has invited Lucas_Garcia (uid: 168) to Front Yard Ballas (id: 2).'),
(130, '2023-03-16 15:29:41', 'Limbo_sinyore (uid: 8) kicked Lucas_Garcia (uid: 168) from Front Yard Ballas (id: 2) as rank jdid (0).'),
(131, '2023-03-16 15:32:15', 'Limbo_sinyore (uid: 8) has invited Lucas_Garcia (uid: 168) to Front Yard Ballas (id: 2).'),
(132, '2023-03-16 15:50:20', 'SHARLOC_SMOKERS (uid: 154) has invited Matrax_Smoker (uid: 184) to Los Santos Bloods (id: 5).'),
(133, '2023-03-16 15:53:48', 'X_Mafia (uid: 163) has quit Los Santos Bloods (id: 5) has rank [CO-OG] (5).'),
(134, '2023-03-16 15:54:16', 'Mistro_Roberto (uid: 42) has set Eazy_Gaviria\'s (uid: 100) rank in Front Yard Ballas (id: 2) to LID LIMNA (5).'),
(135, '2023-03-16 15:54:23', 'WALID_PABLO (uid: 165) has invited PABLO_PICASO (uid: 183) to Grove Stret Families (id: 0).'),
(136, '2023-03-16 15:55:34', 'WALID_PABLO (uid: 165) has invited BADR_PEDRI (uid: 182) to Grove Stret Families (id: 0).'),
(137, '2023-03-16 15:56:01', 'WALID_PABLO (uid: 165) has set PABLO_PICASO\'s (uid: 183) rank in Grove Stret Families (id: 0) to CO OG (5).'),
(138, '2023-03-16 15:56:10', 'WALID_PABLO (uid: 165) has set BADR_PEDRI\'s (uid: 182) rank in Grove Stret Families (id: 0) to LM9AWD (4).'),
(139, '2023-03-16 15:56:26', 'WALID_PABLO (uid: 165) has set BADR_PEDRI\'s (uid: 182) rank in Grove Stret Families (id: 0) to CO OG (5).'),
(140, '2023-03-16 15:57:22', 'WALID_PABLO (uid: 165) has invited Filix_Guzman (uid: 164) to Grove Stret Families (id: 0).'),
(141, '2023-03-16 15:59:44', 'Limbo_sinyore (uid: 8) has invited Hitman_ZERO (uid: 186) to Front Yard Ballas (id: 2).'),
(142, '2023-03-16 16:06:08', 'X_Mafia (uid: 163) has quit Los Santos Bloods (id: 5) has rank [CO-OG] (5).'),
(143, '2023-03-16 16:12:17', 'Mistro_Roberto (uid: 42) sold their gang owned Sabre (id: 1384) to the dealership for $0'),
(144, '2023-03-16 16:16:17', 'JAIMSE_PALACIO (uid: 35) has quit Los Santos Vagos (id: 1) has rank dbdob kbir (4).'),
(145, '2023-03-16 16:18:50', 'BADR_PEDRI (uid: 182) has invited MIKHAEL_RODRIGUEZ (uid: 188) to Grove Stret Families (id: 0).'),
(146, '2023-03-16 16:21:14', 'BADR_PEDRI (uid: 182) has invited RELAX_PERSON (uid: 189) to Grove Stret Families (id: 0).'),
(147, '2023-03-16 16:27:34', 'BADR_PEDRI (uid: 182) has invited HICHAM_PEDRI (uid: 159) to Grove Stret Families (id: 0).'),
(148, '2023-03-16 16:31:10', 'AYMEN_LME3DAWI (uid: 28) has invited JAIMSE_PALACIO (uid: 35) to Los Santos Vagos (id: 1).'),
(149, '2023-03-16 16:31:49', 'AYMEN_LME3DAWI (uid: 28) has set JAIMSE_PALACIO\'s (uid: 35) rank in Los Santos Vagos (id: 1) to dbdob kbir (4).'),
(150, '2023-03-16 16:41:58', 'AYMEN_LME3DAWI (uid: 28) has set Selfx_Tchapo\'s (uid: 49) rank in Los Santos Vagos (id: 1) to dbdob sghir  (3).'),
(151, '2023-03-16 17:06:07', 'Ayman_Pedro (uid: 167) deposits 1 grams of cocaine in the gang stash.'),
(152, '2023-03-16 17:24:06', 'POP_SMOKE (uid: 157) has invited Ismail_Sanch (uid: 175) to Los Santos Marabunta (id: 3).'),
(153, '2023-03-16 17:48:07', 'BADR_PEDRI (uid: 182) has set LAMAR_PABLOX\'s (uid: 12) rank in Grove Stret Families (id: 0) to CO OG (5).'),
(154, '2023-03-16 18:01:07', 'Limbo_sinyore (uid: 8) has set Carlos_Messi\'s (uid: 90) rank in Front Yard Ballas (id: 2) to LID LISRA (4).'),
(155, '2023-03-16 19:08:30', 'POP_SMOKE (uid: 157) has invited Savage_Alexander (uid: 171) to Los Santos Marabunta (id: 3).'),
(156, '2023-03-16 19:28:14', 'POP_SMOKE (uid: 157) has invited Abdou_meknassi (uid: 174) to Los Santos Marabunta (id: 3).'),
(157, '2023-03-16 19:28:49', 'POP_SMOKE (uid: 157) has set Abdou_meknassi\'s (uid: 174) rank in Los Santos Marabunta (id: 3) to Under boss (5).'),
(158, '2023-03-16 19:51:37', 'WALID_PABLO (uid: 165) has invited MOUAD_PABLO (uid: 21) to Grove Stret Families (id: 0).'),
(159, '2023-03-16 19:52:24', 'WALID_PABLO (uid: 165) has set MOUAD_PABLO\'s (uid: 21) rank in Grove Stret Families (id: 0) to WLD DRIBA (1).'),
(160, '2023-03-16 19:58:13', 'PAOLO_SMOKERS (uid: 177) has set HADES_SMOKERS\'s (uid: 178) rank in Los Santos Bloods (id: 5) to Unspecified (4).'),
(161, '2023-03-16 20:25:27', 'SHARLOC_SMOKERS (uid: 154) deposits 700 materials in the gang stash.'),
(162, '2023-03-16 20:25:37', 'SHARLOC_SMOKERS (uid: 154) deposits 50 materials in the gang stash.'),
(163, '2023-03-16 20:46:40', 'WALID_PABLO (uid: 165) has set PABLO_PICASO\'s (uid: 183) rank in Grove Stret Families (id: 0) to Unspecified (6).'),
(164, '2023-03-16 20:53:59', 'PABLO_PICASO (uid: 183) has set WALID_PABLO\'s (uid: 165) rank in Grove Stret Families (id: 0) to Unspecified (5).'),
(165, '2023-03-16 21:20:44', 'Lmour_pholoko (uid: 76) has invited Shan_Pholoko (uid: 200) to Front Yard Ballas (id: 2).'),
(166, '2023-03-16 21:23:46', 'Lmour_pholoko (uid: 76) kicked Shan_Pholoko (uid: 200) from Front Yard Ballas (id: 2) as rank Unspecified (0).'),
(167, '2023-03-16 21:23:53', 'Lmour_pholoko (uid: 76) has invited Shan_Pholoko (uid: 200) to Front Yard Ballas (id: 2).'),
(168, '2023-03-16 21:24:23', 'Lmour_pholoko (uid: 76) kicked Shan_Pholoko (uid: 200) from Front Yard Ballas (id: 2) as rank Unspecified (0).'),
(169, '2023-03-16 21:24:26', 'Lmour_pholoko (uid: 76) has invited Shan_Pholoko (uid: 200) to Front Yard Ballas (id: 2).'),
(170, '2023-03-17 13:28:49', 'AYMEN_LME3DAWI (uid: 28) has invited GREN_BTRIK (uid: 181) to Los Santos Vagos (id: 1).'),
(171, '2023-03-17 15:44:46', 'X_Mafia (uid: 163)  offlinekicked Chinwi_eltchapo (uid: 96) from Los Santos Bikers (id: 4) as rank Unspecified (6).'),
(172, '2023-03-17 15:45:02', 'X_Mafia (uid: 163)  offlinekicked DRISS_ESCOBAR (uid: 86) from Los Santos Bikers (id: 4) as rank Unspecified (5).'),
(173, '2023-03-17 16:07:24', 'X_Mafia (uid: 163) has set psiko_boukhris\'s (uid: 54) rank in MAFIA (id: 7) to Unspecified (5).'),
(174, '2023-03-17 16:22:50', 'X_Mafia (uid: 163) has quit MAFIA (id: 7) has rank Unspecified (6).'),
(175, '2023-03-17 19:53:09', 'LAMAR_PABLOX (uid: 12) has invited Pablo_Walid (uid: 207) to Grove Stret Families (id: 0).'),
(176, '2023-03-18 14:19:41', 'LAMAR_PABLOX (uid: 12) has set Pablo_Walid\'s (uid: 207) rank in Grove Stret Families (id: 0) to Unspecified (3).'),
(177, '2023-03-18 15:30:31', 'AYMEN_LME3DAWI (uid: 28) has invited MADARA_33 (uid: 196) to Los Santos Vagos (id: 1).'),
(178, '2023-03-19 22:44:37', 'Vini_Edrian (uid: 7) has quit Blancos (id: 8) has rank OG BLANCOS (6).'),
(179, '2023-03-19 22:46:16', 'GOD_TIPO (uid: 11) has invited Raynez_Partida (uid: 25) to Blancos (id: 8).'),
(180, '2023-03-20 00:48:18', 'yasser_elallawi (uid: 5) has invited Dyablo_Dr3awi (uid: 28) to Blancos (id: 8).'),
(181, '2023-03-20 00:48:51', 'yasser_elallawi (uid: 5) has set Dyablo_Dr3awi\'s (uid: 28) rank in Blancos (id: 8) to OG BLANCOS (6).'),
(182, '2023-03-20 00:52:39', 'Dyablo_Dr3awi (uid: 28) has quit Blancos (id: 8) has rank OG BLANCOS (6).'),
(183, '2023-03-20 00:58:18', 'yasser_elallawi (uid: 5) has invited Dyablo_Dr3awi (uid: 28) to Blancos (id: 8).'),
(184, '2023-03-20 00:58:36', 'yasser_elallawi (uid: 5) kicked Dyablo_Dr3awi (uid: 28) from Blancos (id: 8) as rank Unspecified (0).'),
(185, '2023-03-20 13:05:15', 'X_Mafia (uid: 8) has quit X  (id: 6) has rank Unspecified (6).'),
(186, '2023-03-20 13:06:24', 'X_Mafia (uid: 8) has quit Grove Stret Families (id: 0) has rank Unspecified (6).'),
(187, '2023-03-20 13:18:46', 'COROMBO_PABLO (uid: 33) has invited UTCHIHA_PABLO (uid: 3) to Grove Stret Families (id: 0).'),
(188, '2023-03-20 14:45:13', 'GOD_TIPO (uid: 11) has quit Los Santos Vagos (id: 1) has rank Unspecified (6).'),
(189, '2023-03-20 21:11:00', 'COROMBO_PABLO (uid: 33) has quit Grove Stret Families (id: 0) has rank Unspecified (6).'),
(190, '2023-03-20 21:39:49', 'psiko_boukhris (uid: 1) has invited Dyablo_Dr3awi (uid: 28) to MAFIA (id: 7).'),
(191, '2023-03-20 21:42:40', 'psiko_boukhris (uid: 1) has invited Pablo_Walid (uid: 4) to MAFIA (id: 7).'),
(192, '2023-03-20 22:30:59', 'psiko_boukhris (uid: 1) has invited COROMBO_PABLO (uid: 33) to MAFIA (id: 7).'),
(193, '2023-03-21 20:40:38', 'GOD TIPO (uid: 11) has removed gang  (id: 8).'),
(194, '2023-03-22 13:20:29', 'X_Mafia (uid: 8)  offlinekicked Dyablo_Dr3awi (uid: 28) from MAFIA (id: 7) as rank Unspecified (0).'),
(195, '2023-03-22 13:20:40', 'X_Mafia (uid: 8)  offlinekicked COROMBO_PABLO (uid: 33) from MAFIA (id: 7) as rank Unspecified (0).'),
(196, '2023-03-22 13:22:27', 'psiko_boukhris (uid: 1) has quit MAFIA (id: 7) has rank Unspecified (5).'),
(197, '2023-03-22 13:32:03', 'X_Mafia (uid: 8) has invited yasser_elallawi (uid: 5) to BLANCOS (id: 8).'),
(198, '2023-03-22 13:32:10', 'X_Mafia (uid: 8) has set yasser_elallawi\'s (uid: 5) rank in BLANCOS (id: 8) to Unspecified (6).'),
(199, '2023-03-22 13:53:16', 'yasser_elallawi (uid: 5) has set yasser_elallawi\'s (uid: 5) rank in BLANCOS (id: 8) to Unspecified (6).'),
(200, '2023-03-22 14:20:01', 'GOD_TIPO (uid: 11) has quit Grove Stret Families (id: 0) has rank Unspecified (6).'),
(201, '2023-03-22 20:46:49', 'X_Mafia (uid: 8) has invited COROMBO_PABLO (uid: 33) to Grove Stret Families (id: 0).'),
(202, '2023-03-23 00:34:24', 'yasser_elallawi (uid: 5) has invited Onahi_Tiger (uid: 51) to BLANCOS (id: 8).'),
(203, '2023-03-23 00:43:46', 'yasser_elallawi (uid: 5) has set Onahi_Tiger\'s (uid: 51) rank in BLANCOS (id: 8) to CO BOSS (5).'),
(204, '2023-03-24 21:39:45', 'AMRO_MINE (uid: 57) has invited PABLO_PICASO (uid: 6) to Los Santos Marabunta (id: 3).'),
(205, '2023-03-24 21:40:41', 'AMRO_MINE (uid: 57) has set PABLO_PICASO\'s (uid: 6) rank in Los Santos Marabunta (id: 3) to Unspecified (5).'),
(206, '2023-03-24 21:41:10', 'PABLO_PICASO (uid: 6) has invited PITER_PARKER (uid: 60) to Los Santos Marabunta (id: 3).'),
(207, '2023-03-24 21:42:33', 'PABLO_PICASO (uid: 6) has set PITER_PARKER\'s (uid: 60) rank in Los Santos Marabunta (id: 3) to Unspecified (5).'),
(208, '2023-03-25 00:58:14', 'AMRO_MINE (uid: 57) has invited Aymane_tobo (uid: 61) to Los Santos Marabunta (id: 3).'),
(209, '2023-03-25 01:18:44', 'AMRO_MINE (uid: 57) has set Aymane_tobo\'s (uid: 61) rank in Los Santos Marabunta (id: 3) to Unspecified (5).'),
(210, '2023-03-26 01:38:22', 'X_Mafia (uid: 8) has quit Los Santos Bloods (id: 5) has rank OG BLOODS (6).'),
(211, '2023-03-26 01:42:39', 'X_Mafia (uid: 8) has quit Los Santos Bloods (id: 5) has rank OG BLOODS (6).'),
(212, '2023-03-26 03:06:17', 'psiko_boukhris (uid: 1) has quit BLANCOS (id: 8) has rank BOSS (6).'),
(213, '2023-03-26 03:09:45', 'psiko_boukhris (uid: 1) has quit BLANCOS (id: 8) has rank BOSS (6).'),
(214, '2023-03-26 03:10:35', 'X_Mafia (uid: 77)  offlinekicked Pablo_Walid (uid: 4) from MAFIA (id: 7) as rank Unspecified (0).'),
(215, '2023-03-26 03:10:46', 'X_Mafia (uid: 77)  offlinekicked COROMBO_PABLO (uid: 33) from MAFIA (id: 7) as rank Unspecified (0).'),
(216, '2023-03-26 03:12:15', 'psiko_boukhris (uid: 1) has quit Grove Stret Families (id: 0) has rank Unspecified (6).'),
(217, '2023-03-26 12:58:02', 'AMRO_JOBINO (uid: 76) has invited Ahmed_lhaj (uid: 81) to Los Santos crips (id: 3).'),
(218, '2023-03-27 17:01:57', 'AMRO_JOBINO (uid: 76) has invited Mike_tyson (uid: 90) to Los Santos crips (id: 3).'),
(219, '2023-03-27 17:03:17', 'psiko_boukhris (uid: 1) has invited Pablo_Walid (uid: 4) to BLANCOS (id: 8).'),
(220, '2023-03-27 17:03:38', 'psiko_boukhris (uid: 1) has set Pablo_Walid\'s (uid: 4) rank in BLANCOS (id: 8) to CO BOSS (5).'),
(221, '2023-03-27 17:14:42', 'AMRO_JOBINO (uid: 76) has set Mike_tyson\'s (uid: 90) rank in Los Santos crips (id: 3) to Unspecified (5).');

-- --------------------------------------------------------

--
-- Structure de la table `log_give`
--

CREATE TABLE `log_give` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_give`
--

INSERT INTO `log_give` (`id`, `date`, `description`) VALUES
(1, '2023-03-14 16:37:33', 'Anas_Tali (uid: 63) (IP: 196.85.148.130) gives $10000 to dob_lghaba (uid: 45) (IP: 41.141.6.30)'),
(2, '2023-03-14 16:37:34', 'NMS_PATRON (uid: 41) (IP: 196.206.98.56) gives $15000 to dob_lghaba (uid: 45) (IP: 41.141.6.30)'),
(3, '2023-03-14 16:39:57', 'Selfx_Tchapo (uid: 49) (IP: 196.118.123.37) gives $3600 to dob_lghaba (uid: 45) (IP: 41.141.6.30)'),
(4, '2023-03-14 16:52:14', 'STEVAW_MARTINEZ (uid: 48) (IP: 196.89.208.37) gives $10000 to dob_lghaba (uid: 45) (IP: 41.141.6.30)'),
(5, '2023-03-14 17:28:52', 'Selfx_Tchapo (uid: 49) (IP: 196.118.123.37) gives $50000 to NMS_PATRON (uid: 41) (IP: 196.206.98.56)'),
(6, '2023-03-14 17:30:44', 'Anas_Tali (uid: 63) (IP: 196.85.148.130) gives $1 to psiko_boukhris (uid: 54) (IP: 41.143.5.252)'),
(7, '2023-03-14 18:14:48', 'Felix_Jigo (uid: 3) (IP: 196.217.36.149) gives $3000 to Nfha_Doo (uid: 30) (IP: 41.141.234.76)'),
(8, '2023-03-14 18:33:41', 'Anas_Tali (uid: 63) (IP: 154.148.35.5) gives $10000 to dob_lghaba (uid: 45) (IP: 160.178.171.225)'),
(9, '2023-03-14 18:59:25', 'NMS_PATRON (uid: 41) (IP: 196.206.98.56) gives $50000 to dob_lghaba (uid: 45) (IP: 160.178.171.225)'),
(10, '2023-03-14 19:00:41', 'LMCH_NATAZI (uid: 83) (IP: 41.92.25.91) gives $1000 to Limbo_sinyore (uid: 8) (IP: 196.117.3.94)'),
(11, '2023-03-14 19:00:52', 'LMCH_NATAZI (uid: 83) (IP: 41.92.25.91) gives $1000 to Limbo_sinyore (uid: 8) (IP: 196.117.3.94)'),
(12, '2023-03-14 19:02:31', 'dob_lghaba (uid: 45) (IP: 160.178.171.225) gives $100000 to JUNIOR_VINICUIS (uid: 82) (IP: 102.51.19.78)'),
(13, '2023-03-14 20:15:40', 'Oualid_Jackson (uid: 85) (IP: 196.89.208.2) gives $500 to ZIZWAR_7M7 (uid: 26) (IP: 41.143.102.88)'),
(14, '2023-03-14 20:44:04', 'AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190) gives $750 to PROF_TIMSA7 (uid: 59) (IP: 196.67.97.160)'),
(15, '2023-03-14 21:45:00', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(16, '2023-03-14 21:45:02', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(17, '2023-03-14 21:45:06', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(18, '2023-03-14 21:45:08', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(19, '2023-03-14 21:45:12', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(20, '2023-03-14 21:45:16', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(21, '2023-03-14 21:45:20', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(22, '2023-03-14 21:45:24', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(23, '2023-03-14 21:45:28', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(24, '2023-03-14 21:45:31', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(25, '2023-03-14 21:45:35', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(26, '2023-03-14 21:45:37', 'DRISS_ESCOBAR (uid: 86) (IP: 105.155.108.62) gives $14000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(27, '2023-03-14 21:45:38', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(28, '2023-03-14 21:45:46', 'DRAGA_SANDRO (uid: 95) (IP: 105.67.0.254) gives $1000 to Chinwi_eltchapo (uid: 96) (IP: 41.92.88.188)'),
(29, '2023-03-14 23:16:04', 'Limbo_sinyore (uid: 8) (IP: 196.117.3.94) gives $2000 to Ayoub_Jasm (uid: 91) (IP: 197.253.227.183)'),
(30, '2023-03-15 00:35:02', 'Chliha_Olmhjob (uid: 110) (IP: 105.154.32.63) gives $10000 to Selfx_Tchapo (uid: 49) (IP: 196.118.123.37)'),
(31, '2023-03-15 00:36:43', 'Chliha_Olmhjob (uid: 110) (IP: 105.154.32.63) gives $4000 to Selfx_Tchapo (uid: 49) (IP: 196.118.123.37)'),
(32, '2023-03-15 00:41:10', 'Selfx_Tchapo (uid: 49) (IP: 196.118.123.37) gives $12000 to Anas_Tali (uid: 63) (IP: 196.85.148.130)'),
(33, '2023-03-15 01:50:43', 'Selfx_Tchapo (uid: 49) gives 20 materials to dob_lghaba (uid: 45)'),
(34, '2023-03-15 01:50:47', 'Selfx_Tchapo (uid: 49) gives 80 materials to dob_lghaba (uid: 45)'),
(35, '2023-03-15 02:28:52', 'psiko_boukhris (uid: 54) (IP: 105.155.232.50) gives $13000 to Anas_Tali (uid: 63) (IP: 196.85.148.130)'),
(36, '2023-03-15 02:58:04', 'STEVAW_MARTINEZ (uid: 48) (IP: 41.249.175.12) gives $2000 to dob_lghaba (uid: 45) (IP: 160.178.171.225)'),
(37, '2023-03-15 03:06:10', 'Anas_Tali (uid: 63) (IP: 196.85.148.130) gives $5000 to psiko_boukhris (uid: 54) (IP: 105.155.232.50)'),
(38, '2023-03-15 03:06:26', 'Anas_Tali (uid: 63) (IP: 196.85.148.130) gives $2000 to psiko_boukhris (uid: 54) (IP: 105.155.232.50)'),
(39, '2023-03-15 03:07:31', 'psiko_boukhris (uid: 54) (IP: 105.155.232.50) gives $7000 to Anas_Tali (uid: 63) (IP: 196.85.148.130)'),
(40, '2023-03-15 10:56:16', 'Lmour_pholoko (uid: 76) gives 1500 materials to Mistro_Roberto (uid: 42)'),
(41, '2023-03-15 11:21:38', 'Jack_Hunter (uid: 120) (IP: 196.65.151.219) gives $10000 to DRISS_ESCOBAR (uid: 86) (IP: 105.155.108.62)'),
(42, '2023-03-15 11:25:24', 'Chliha_Olmhjob (uid: 110) (IP: 105.154.32.63) gives $460 to DRISS_ESCOBAR (uid: 86) (IP: 105.155.108.62)'),
(43, '2023-03-15 11:43:48', 'abdollah_algnawi (uid: 14) (IP: 41.92.97.135) gives $1000 to Chliha_Olmhjob (uid: 110) (IP: 105.154.32.63)'),
(44, '2023-03-15 12:56:30', 'Selfx_Tchapo (uid: 49) (IP: 196.118.123.37) gives $60000 to Snop_Doge (uid: 112) (IP: 41.92.87.51)'),
(45, '2023-03-15 13:23:14', 'X_Mafia (uid: 56) (IP: 105.66.4.148) gives $5000 to Darwin_Watirson (uid: 106) (IP: 197.144.61.243)'),
(46, '2023-03-15 15:09:21', 'Chliha_Olmhjob (uid: 110) (IP: 105.154.32.63) gives $1 to Reda_Tazi (uid: 5) (IP: 41.141.54.111)'),
(47, '2023-03-15 15:10:10', 'Chliha_Olmhjob (uid: 110) (IP: 105.154.32.63) gives $1 to Reda_Tazi (uid: 5) (IP: 41.141.54.111)'),
(48, '2023-03-15 19:17:33', 'STEVAW_MARTINEZ (uid: 48) (IP: 41.249.175.12) gives $200 to NMS_FLIX (uid: 143) (IP: 196.206.165.225)'),
(49, '2023-03-15 19:39:08', 'AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190) gives $1000 to Oualid_Jackson (uid: 85) (IP: 196.118.137.194)'),
(50, '2023-03-15 22:01:01', 'AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190) gives $2000 to Vini_Edrian (uid: 23) (IP: 196.75.90.99)'),
(51, '2023-03-15 22:35:20', 'Unknown_ (uid: 94) (IP: 196.217.76.10) gives $5000 to AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190)'),
(52, '2023-03-15 22:35:49', 'Unknown_ (uid: 94) (IP: 196.217.76.10) gives $4000 to AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190)'),
(53, '2023-03-15 22:53:17', 'Tyson_Choppa (uid: 37) (IP: 196.65.151.219) gives $3000 to Jack_Hunter (uid: 120) (IP: 196.65.151.219)'),
(54, '2023-03-15 23:20:51', 'Selfx_Tchapo (uid: 49) gives their Baseball Bat to dob_lghaba (uid: 45)'),
(55, '2023-03-15 23:22:29', 'Jack_Hunter (uid: 120) (IP: 196.65.151.219) gives $10000 to Tyson_Choppa (uid: 37) (IP: 196.65.151.219)'),
(56, '2023-03-15 23:25:27', 'Selfx_Tchapo (uid: 49) (IP: 196.115.46.208) gives $50000 to dob_lghaba (uid: 45) (IP: 196.89.38.66)'),
(57, '2023-03-15 23:25:37', 'Anas_Tali (uid: 63) (IP: 105.158.150.77) gives $50000 to dob_lghaba (uid: 45) (IP: 196.89.38.66)'),
(58, '2023-03-15 23:26:09', 'AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190) gives $50000 to dob_lghaba (uid: 45) (IP: 196.89.38.66)'),
(59, '2023-03-15 23:28:24', 'STEVAW_MARTINEZ (uid: 48) (IP: 196.74.232.227) gives $50000 to dob_lghaba (uid: 45) (IP: 196.89.38.66)'),
(60, '2023-03-16 00:26:39', 'Andrew_Tate (uid: 62) (IP: 105.66.132.238) gives $50000 to Ayoub_Jasm (uid: 91) (IP: 197.253.203.242)'),
(61, '2023-03-16 02:15:06', 'Rachid_ekambi (uid: 17) (IP: 41.249.127.53) gives $50000 to Ayoub_Jasm (uid: 91) (IP: 197.253.246.2)'),
(62, '2023-03-16 03:12:18', 'ADMIN_BO3O (uid: 62) gives their AK47 to dizzy_dros (uid: 139)'),
(63, '2023-03-16 12:33:54', 'Lmour_pholoko (uid: 76) has sold their Katana to Limbo_sinyore (uid: 8) for $1000.'),
(64, '2023-03-16 13:09:51', 'Yassir_sancho (uid: 135) (IP: 105.66.133.149) gives $1000 to DRISS_ESCOBAR (uid: 86) (IP: 196.74.130.156)'),
(65, '2023-03-16 13:18:57', 'Jlabanda_MDFK (uid: 93) (IP: 196.117.3.94) gives $90000 to Limbo_sinyore (uid: 8) (IP: 196.117.3.94)'),
(66, '2023-03-16 13:23:53', 'Mistro_Roberto (uid: 42) (IP: 196.121.49.149) gives $10000 to Limbo_sinyore (uid: 8) (IP: 196.117.3.94)'),
(67, '2023-03-16 13:36:35', 'Mistro_Roberto (uid: 42) (IP: 196.121.49.149) gives $2000 to Limbo_sinyore (uid: 8) (IP: 196.117.3.94)'),
(68, '2023-03-16 13:50:23', 'Mistro_Roberto (uid: 42) (IP: 196.121.49.149) gives $20000 to CORLO_NEGRO (uid: 7) (IP: 37.161.246.221)'),
(69, '2023-03-16 13:58:35', 'Darwin_Watirson (uid: 106) gives their Katana to Mistro_Roberto (uid: 42)'),
(70, '2023-03-16 14:39:04', 'zamora_chadi (uid: 141) (IP: 105.158.27.173) gives $10000 to Mistro_Roberto (uid: 42) (IP: 196.121.49.149)'),
(71, '2023-03-16 14:40:36', 'Chliha_Olmhjob (uid: 110) (IP: 105.159.229.16) gives $10000 to Bilomi_albert (uid: 152) (IP: 105.71.147.104)'),
(72, '2023-03-16 14:42:03', 'zamora_chadi (uid: 141) gives their Katana to Limbo_sinyore (uid: 8)'),
(73, '2023-03-16 14:47:07', 'psiko_boukhris (uid: 54) (IP: 196.206.183.112) gives $50000 to dob_lghaba (uid: 45) (IP: 196.64.35.78)'),
(74, '2023-03-16 15:01:02', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(75, '2023-03-16 15:01:06', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(76, '2023-03-16 15:01:10', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(77, '2023-03-16 15:01:31', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(78, '2023-03-16 15:01:36', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(79, '2023-03-16 15:01:45', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(80, '2023-03-16 15:01:49', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(81, '2023-03-16 15:01:51', 'Felix_Jigo (uid: 98) (IP: 41.142.143.171) gives $100000 to James_Edrian (uid: 36) (IP: 197.253.192.232)'),
(82, '2023-03-16 15:03:14', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $10000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(83, '2023-03-16 15:03:20', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $90000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(84, '2023-03-16 15:03:23', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $100000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(85, '2023-03-16 15:03:26', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $100000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(86, '2023-03-16 15:03:29', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $100000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(87, '2023-03-16 15:03:33', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $100000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(88, '2023-03-16 15:03:36', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $100000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(89, '2023-03-16 15:03:40', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $100000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(90, '2023-03-16 15:03:46', 'James_Edrian (uid: 36) (IP: 197.253.192.232) gives $40000 to Felix_Jigo (uid: 98) (IP: 41.142.143.171)'),
(91, '2023-03-16 15:17:26', 'JAIMSE_PALACIO (uid: 35) gives 2 grams of cocaine to AYMEN_LME3DAWI (uid: 28)'),
(92, '2023-03-16 15:44:24', 'Mistro_Roberto (uid: 42) (IP: 196.121.49.149) gives $1000 to Jlabanda_MDFK (uid: 93) (IP: 196.117.3.94)'),
(93, '2023-03-16 15:49:03', 'HOUSSAM_KABBACHE (uid: 169) (IP: 41.143.55.8) gives $467 to Chliha_Olmhjob (uid: 110) (IP: 41.251.139.52)'),
(94, '2023-03-16 16:21:32', 'James_Edrian (uid: 36) gives 1 painkillers to Eazy_Gaviria (uid: 100)'),
(95, '2023-03-16 16:21:56', 'Felix_Jigo (uid: 98) (IP: 105.155.196.36) gives $30000 to JAIMSE_PALACIO (uid: 35) (IP: 196.91.185.21)'),
(96, '2023-03-16 16:32:34', 'James_Edrian (uid: 36) (IP: 197.253.249.11) gives $1500 to Eazy_Gaviria (uid: 100) (IP: 105.66.133.174)'),
(97, '2023-03-16 16:40:39', 'Ismail_Sanch (uid: 175) (IP: 105.67.6.164) gives $700 to Ayman_Pedro (uid: 167) (IP: 105.67.6.164)'),
(98, '2023-03-16 16:42:01', 'Reda_Tazi (uid: 5) (IP: 105.157.197.127) gives $10000 to James_Edrian (uid: 36) (IP: 197.253.249.11)'),
(99, '2023-03-16 16:49:52', 'James_Edrian (uid: 36) gives 1 painkillers to DRISS_ESCOBAR (uid: 86)'),
(100, '2023-03-16 16:50:18', 'Ismail_Sanch (uid: 175) (IP: 105.67.6.164) gives $1000 to JERRY_SMOKER (uid: 173) (IP: 105.69.115.223)'),
(101, '2023-03-16 16:57:06', 'Hitman_ZERO (uid: 186) (IP: 196.70.137.105) gives $1 to Darwin_Watirson (uid: 106) (IP: 197.144.61.243)'),
(102, '2023-03-16 17:08:23', 'Yassir_sancho (uid: 135) (IP: 105.66.133.149) gives $2500 to Matrax_Smoker (uid: 184) (IP: 196.65.59.67)'),
(103, '2023-03-16 17:11:49', 'BADR_PEDRI (uid: 182) (IP: 41.140.77.30) gives $1000 to JERRY_SMOKER (uid: 173) (IP: 105.69.115.223)'),
(104, '2023-03-16 17:27:13', 'POP_SMOKE (uid: 157) (IP: 41.250.112.211) gives $20000 to Yassir_sancho (uid: 135) (IP: 105.66.133.149)'),
(105, '2023-03-16 17:27:56', 'Yassir_sancho (uid: 135) (IP: 105.66.133.149) gives $2000 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(106, '2023-03-16 17:28:05', 'Yassir_sancho (uid: 135) (IP: 105.66.133.149) gives $1800 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(107, '2023-03-16 17:28:13', 'Yassir_sancho (uid: 135) (IP: 105.66.133.149) gives $18000 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(108, '2023-03-16 17:42:32', 'JERRY_SMOKER (uid: 173) (IP: 105.69.115.223) gives $1000 to Matrax_Smoker (uid: 184) (IP: 196.65.59.67)'),
(109, '2023-03-16 18:17:42', 'HADES_SMOKERS (uid: 178) gives 250 materials to SHARLOC_SMOKERS (uid: 154)'),
(110, '2023-03-16 18:23:49', 'abdollah_algnawi (uid: 14) (IP: 196.112.135.21) gives $50000 to Eazy_Gaviria (uid: 100) (IP: 105.66.133.174)'),
(111, '2023-03-16 18:24:49', 'abdollah_algnawi (uid: 14) (IP: 196.112.135.21) gives $5000 to Eazy_Gaviria (uid: 100) (IP: 105.66.133.174)'),
(112, '2023-03-16 18:24:56', 'abdollah_algnawi (uid: 14) (IP: 196.112.135.21) gives $1000 to Eazy_Gaviria (uid: 100) (IP: 105.66.133.174)'),
(113, '2023-03-16 18:25:09', 'abdollah_algnawi (uid: 14) (IP: 196.112.135.21) gives $1000 to Eazy_Gaviria (uid: 100) (IP: 105.66.133.174)'),
(114, '2023-03-16 18:25:19', 'abdollah_algnawi (uid: 14) (IP: 196.112.135.21) gives $5000 to Eazy_Gaviria (uid: 100) (IP: 105.66.133.174)'),
(115, '2023-03-16 18:25:58', 'abdollah_algnawi (uid: 14) (IP: 196.112.135.21) gives $3500 to Eazy_Gaviria (uid: 100) (IP: 105.66.133.174)'),
(116, '2023-03-16 18:28:24', 'FAYO_SMOKERS (uid: 197) (IP: 196.65.166.188) gives $15000 to SHARLOC_SMOKERS (uid: 154) (IP: 196.65.166.188)'),
(117, '2023-03-16 18:29:47', 'SHARLOC_SMOKERS (uid: 154) (IP: 196.65.166.188) gives $500 to FAYO_SMOKERS (uid: 197) (IP: 196.65.166.188)'),
(118, '2023-03-16 18:31:42', 'Eazy_Gaviria (uid: 100) (IP: 105.66.133.174) gives $22000 to Kwika_Sriwila (uid: 117) (IP: 41.143.59.119)'),
(119, '2023-03-16 19:30:23', 'Savage_Alexander (uid: 171) (IP: 197.253.238.152) gives $100 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(120, '2023-03-16 19:30:29', 'Savage_Alexander (uid: 171) (IP: 197.253.238.152) gives $100 to Rachid_ekambi (uid: 17) (IP: 41.249.127.53)'),
(121, '2023-03-16 19:30:42', 'Savage_Alexander (uid: 171) (IP: 197.253.238.152) gives $100 to STEVAW_MARTINEZ (uid: 48) (IP: 196.70.202.245)'),
(122, '2023-03-16 19:30:46', 'Rachid_ekambi (uid: 17) (IP: 41.249.127.53) gives $5000 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(123, '2023-03-16 19:33:29', 'Savage_Alexander (uid: 171) (IP: 197.253.238.152) gives $100 to Ahmed_Sfriwi (uid: 148) (IP: 105.154.38.100)'),
(124, '2023-03-16 19:33:49', 'Savage_Alexander (uid: 171) (IP: 197.253.238.152) gives $100 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(125, '2023-03-16 19:33:54', 'Savage_Alexander (uid: 171) (IP: 197.253.238.152) gives $100 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(126, '2023-03-16 19:34:07', 'Savage_Alexander (uid: 171) (IP: 197.253.238.152) gives $100 to POP_SMOKE (uid: 157) (IP: 41.250.112.211)'),
(127, '2023-03-16 19:35:02', 'SALIM_LUCAS (uid: 113) (IP: 105.189.25.201) gives $1000 to JAIMSE_PALACIO (uid: 35) (IP: 196.67.67.52)'),
(128, '2023-03-16 19:35:27', 'JAIMSE_PALACIO (uid: 35) (IP: 196.67.67.52) gives $1000 to SALIM_LUCAS (uid: 113) (IP: 105.189.25.201)'),
(129, '2023-03-16 21:02:26', 'Limbo_sinyore (uid: 8) (IP: 196.117.3.94) gives $7000 to Jlabanda_MDFK (uid: 93) (IP: 196.117.3.94)'),
(130, '2023-03-16 21:22:04', 'Oualid_Jackson (uid: 85) (IP: 196.118.137.194) gives $1 to GOJO_ALGAHTANI (uid: 158) (IP: 196.74.104.110)'),
(131, '2023-03-17 13:15:53', 'AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190) gives $866 to GREN_BTRIK (uid: 181) (IP: 41.92.68.207)'),
(132, '2023-03-17 14:46:28', 'Mistro_Roberto (uid: 42) (IP: 196.121.49.149) gives $1 to Lmour_pholoko (uid: 76) (IP: 41.143.82.245)'),
(133, '2023-03-17 14:49:27', 'AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190) gives $30000 to JAIMSE_PALACIO (uid: 35) (IP: 154.149.213.190)'),
(134, '2023-03-17 15:27:47', 'JAIMSE_PALACIO (uid: 35) (IP: 154.149.213.190) gives $1000 to AYMEN_LME3DAWI (uid: 28) (IP: 196.118.12.190)'),
(135, '2023-03-17 16:14:55', 'X_Mafia (uid: 163) (IP: 105.66.7.65) gives $2500 to Yassir_sancho (uid: 135) (IP: 105.66.132.69)'),
(136, '2023-03-17 16:50:44', 'Yassir_sancho (uid: 135) (IP: 105.66.1.142) gives $1000 to Felix_Jigo (uid: 98) (IP: 41.142.156.185)'),
(137, '2023-03-17 16:58:10', 'STEVAW_MARTINEZ (uid: 48) (IP: 197.145.185.203) gives $500 to dob_lghaba (uid: 45) (IP: 102.78.98.199)'),
(138, '2023-03-17 16:58:13', 'STEVAW_MARTINEZ (uid: 48) (IP: 197.145.185.203) gives $5000 to dob_lghaba (uid: 45) (IP: 102.78.98.199)'),
(139, '2023-03-17 17:06:09', 'dob_lghaba (uid: 45) (IP: 102.78.98.199) gives $1000 to STEVAW_MARTINEZ (uid: 48) (IP: 197.145.185.203)'),
(140, '2023-03-17 19:00:57', 'islam_lmango (uid: 205) (IP: 197.146.119.46) gives $14890 to abdollah_algnawi (uid: 14) (IP: 197.146.119.46)'),
(141, '2023-03-17 19:59:40', 'NMS_PATRON (uid: 41) (IP: 196.206.117.69) gives $47000 to JAIMSE_PALACIO (uid: 35) (IP: 160.169.167.245)'),
(142, '2023-03-17 19:59:54', 'NMS_PATRON (uid: 41) (IP: 196.206.117.69) gives $965 to JAIMSE_PALACIO (uid: 35) (IP: 160.169.167.245)'),
(143, '2023-03-19 22:36:49', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $2000 to STEVAW_MARTINEZ (uid: 9) (IP: 105.68.185.116)'),
(144, '2023-03-19 23:41:57', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(145, '2023-03-19 23:42:00', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(146, '2023-03-19 23:42:03', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(147, '2023-03-19 23:42:07', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(148, '2023-03-19 23:42:27', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(149, '2023-03-19 23:42:31', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(150, '2023-03-19 23:42:34', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(151, '2023-03-19 23:42:42', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(152, '2023-03-19 23:43:41', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(153, '2023-03-19 23:43:44', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) gives $100000 to James_Edrian (uid: 16) (IP: 197.253.217.47)'),
(154, '2023-03-19 23:58:37', 'STEVAW_MARTINEZ (uid: 9) (IP: 105.68.185.116) gives $4000 to psiko_boukhris (uid: 1) (IP: 41.250.202.132)'),
(155, '2023-03-20 00:40:44', 'psiko_boukhris (uid: 1) (IP: 41.250.202.132) gives $29 to yasser_elallawi (uid: 5) (IP: 41.251.78.18)'),
(156, '2023-03-20 00:41:50', 'yasser_elallawi (uid: 5) (IP: 41.251.78.18) gives $1 to psiko_boukhris (uid: 1) (IP: 41.250.202.132)'),
(157, '2023-03-20 01:50:55', 'Marroki_Crazy (uid: 26) (IP: 41.141.96.45) gives $1000 to psiko_boukhris (uid: 1) (IP: 41.250.202.132)'),
(158, '2023-03-20 01:51:34', 'Marroki_Crazy (uid: 26) (IP: 41.141.96.45) gives $1500 to psiko_boukhris (uid: 1) (IP: 41.250.202.132)'),
(159, '2023-03-20 04:53:13', 'dob_lghaba (uid: 29) (IP: 160.176.24.218) gives $1000 to psiko_boukhris (uid: 1) (IP: 41.250.202.132)'),
(160, '2023-03-20 04:53:54', 'psiko_boukhris (uid: 1) (IP: 41.250.202.132) gives $100000 to dob_lghaba (uid: 29) (IP: 160.176.24.218)'),
(161, '2023-03-20 04:54:08', 'psiko_boukhris (uid: 1) (IP: 41.250.202.132) gives $100000 to dob_lghaba (uid: 29) (IP: 160.176.24.218)'),
(162, '2023-03-20 05:13:34', 'dob_lghaba (uid: 29) (IP: 160.176.24.218) gives $20000 to psiko_boukhris (uid: 1) (IP: 41.250.202.132)'),
(163, '2023-03-20 05:14:56', 'psiko_boukhris (uid: 1) (IP: 41.250.202.132) gives $20000 to dob_lghaba (uid: 29) (IP: 160.176.24.218)'),
(164, '2023-03-20 13:03:50', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $10000 to COROMBO_PABLO (uid: 33) (IP: 41.249.129.9)'),
(165, '2023-03-20 13:04:00', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $90000 to COROMBO_PABLO (uid: 33) (IP: 41.249.129.9)'),
(166, '2023-03-20 13:26:55', 'COROMBO_PABLO (uid: 33) (IP: 41.249.129.9) gives $100000 to X_Mafia (uid: 8) (IP: 105.67.2.165)'),
(167, '2023-03-20 13:29:34', 'UTCHIHA_PABLO (uid: 3) (IP: 105.69.112.228) gives $99000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(168, '2023-03-20 17:37:54', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(169, '2023-03-20 17:37:58', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(170, '2023-03-20 17:38:01', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(171, '2023-03-20 17:38:05', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(172, '2023-03-20 17:38:08', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(173, '2023-03-20 17:38:12', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(174, '2023-03-20 17:38:17', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(175, '2023-03-20 17:38:21', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(176, '2023-03-20 17:38:26', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(177, '2023-03-20 17:38:30', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(178, '2023-03-20 17:52:56', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(179, '2023-03-20 17:53:02', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(180, '2023-03-20 17:53:05', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(181, '2023-03-20 17:53:08', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(182, '2023-03-20 17:53:15', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(183, '2023-03-20 17:53:19', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(184, '2023-03-20 17:53:24', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(185, '2023-03-20 17:53:38', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(186, '2023-03-20 17:53:43', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(187, '2023-03-20 17:56:33', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(188, '2023-03-20 17:56:37', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(189, '2023-03-20 17:56:41', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(190, '2023-03-20 17:56:44', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(191, '2023-03-20 17:56:48', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(192, '2023-03-20 17:56:51', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(193, '2023-03-20 17:56:55', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(194, '2023-03-20 17:56:59', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(195, '2023-03-20 17:57:02', 'CORLO_NEGRO (uid: 30) (IP: 37.163.16.119) gives $100000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(196, '2023-03-20 18:20:51', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $50000 to GOD_TIPO (uid: 11) (IP: 105.67.6.52)'),
(197, '2023-03-20 18:22:19', 'GOD_TIPO (uid: 11) (IP: 105.67.6.52) gives $70000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(198, '2023-03-20 18:31:32', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $10000 to GOD_TIPO (uid: 11) (IP: 105.67.6.52)'),
(199, '2023-03-20 18:31:35', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $100000 to GOD_TIPO (uid: 11) (IP: 105.67.6.52)'),
(200, '2023-03-20 18:31:41', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $100000 to GOD_TIPO (uid: 11) (IP: 105.67.6.52)'),
(201, '2023-03-20 18:31:44', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $100000 to GOD_TIPO (uid: 11) (IP: 105.67.6.52)'),
(202, '2023-03-20 18:31:47', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $100000 to GOD_TIPO (uid: 11) (IP: 105.67.6.52)'),
(203, '2023-03-20 18:31:50', 'Pablo_Walid (uid: 4) (IP: 105.67.7.205) gives $100000 to GOD_TIPO (uid: 11) (IP: 105.67.6.52)'),
(204, '2023-03-20 19:16:18', 'psiko_boukhris (uid: 1) (IP: 160.176.110.194) gives $100000 to ZIZWAR_7M7 (uid: 40) (IP: 196.89.234.188)'),
(205, '2023-03-20 19:16:24', 'psiko_boukhris (uid: 1) (IP: 160.176.110.194) gives $100000 to ZIZWAR_7M7 (uid: 40) (IP: 196.89.234.188)'),
(206, '2023-03-20 21:06:48', 'psiko_boukhris (uid: 1) (IP: 160.176.110.194) gives $100000 to abdollah_algnawi (uid: 12) (IP: 105.191.3.135)'),
(207, '2023-03-20 21:06:55', 'psiko_boukhris (uid: 1) (IP: 160.176.110.194) gives $100000 to COROMBO_PABLO (uid: 33) (IP: 41.249.129.9)'),
(208, '2023-03-20 21:21:03', 'abdollah_algnawi (uid: 12) (IP: 105.191.3.135) gives $20000 to X_Mafia (uid: 8) (IP: 105.66.134.226)'),
(209, '2023-03-20 21:21:32', 'abdollah_algnawi (uid: 12) (IP: 105.191.3.135) gives $10000 to X_Mafia (uid: 8) (IP: 105.66.134.226)'),
(210, '2023-03-20 21:21:47', 'abdollah_algnawi (uid: 12) (IP: 105.191.3.135) gives $5000 to X_Mafia (uid: 8) (IP: 105.66.134.226)'),
(211, '2023-03-20 21:25:26', 'psiko_boukhris (uid: 1) (IP: 160.176.110.194) gives $30000 to abdollah_algnawi (uid: 12) (IP: 105.191.3.135)'),
(212, '2023-03-20 22:03:49', 'abdollah_algnawi (uid: 12) (IP: 105.191.3.135) gives $1000 to Pablo_Walid (uid: 4) (IP: 105.67.7.205)'),
(213, '2023-03-20 22:04:22', 'abdollah_algnawi (uid: 12) (IP: 105.191.3.135) gives $1001 to Dyablo_Dr3awi (uid: 28) (IP: 196.74.38.175)'),
(214, '2023-03-20 22:26:47', 'psiko_boukhris (uid: 1) (IP: 160.176.110.194) gives $10000 to abdollah_algnawi (uid: 12) (IP: 105.191.3.135)'),
(215, '2023-03-20 22:50:50', 'abdollah_algnawi (uid: 12) (IP: 105.191.3.135) gives $2000 to UTCHIHA_PABLO (uid: 3) (IP: 105.69.112.228)'),
(216, '2023-03-20 23:11:11', 'abdollah_algnawi (uid: 12) (IP: 105.191.3.135) gives $1000 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(217, '2023-03-21 00:47:14', 'GOD_TIPO (uid: 11) (IP: 105.67.6.52) gives $50000 to abdollah_algnawi (uid: 12) (IP: 105.191.3.135)'),
(218, '2023-03-21 18:52:40', 'psiko_boukhris (uid: 1) (IP: 105.159.132.225) gives $100000 to Dyablo_Dr3awi (uid: 28) (IP: 196.74.33.88)'),
(219, '2023-03-22 04:42:23', 'psiko_boukhris (uid: 1) (IP: 105.154.17.4) gives $100000 to JAIMSE_PALACIO (uid: 17) (IP: 196.86.44.37)'),
(220, '2023-03-22 04:57:12', 'psiko_boukhris (uid: 1) (IP: 105.154.17.4) gives $50000 to JAIMSE_PALACIO (uid: 17) (IP: 196.86.44.37)'),
(221, '2023-03-22 06:02:48', 'psiko_boukhris (uid: 1) (IP: 105.154.17.4) gives $100000 to JAIMSE_PALACIO (uid: 17) (IP: 196.86.44.37)'),
(222, '2023-03-22 06:02:54', 'psiko_boukhris (uid: 1) (IP: 105.154.17.4) gives $1000 to JAIMSE_PALACIO (uid: 17) (IP: 196.86.44.37)'),
(223, '2023-03-22 13:34:12', 'yasser_elallawi (uid: 5) (IP: 197.253.224.83) gives $50000 to X_Mafia (uid: 8) (IP: 105.71.16.189)'),
(224, '2023-03-22 19:59:30', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(225, '2023-03-22 19:59:44', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(226, '2023-03-22 19:59:58', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(227, '2023-03-22 20:00:07', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(228, '2023-03-22 20:00:13', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(229, '2023-03-22 20:00:19', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(230, '2023-03-22 20:00:25', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(231, '2023-03-22 20:00:30', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(232, '2023-03-22 20:00:37', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(233, '2023-03-22 20:01:05', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(234, '2023-03-22 20:01:32', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(235, '2023-03-22 20:01:48', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(236, '2023-03-22 20:01:54', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(237, '2023-03-22 20:02:05', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(238, '2023-03-22 20:02:23', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(239, '2023-03-22 20:02:30', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(240, '2023-03-22 20:02:35', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(241, '2023-03-22 20:02:41', 'Dyablo_Dr3awi (uid: 28) (IP: 196.89.3.72) gives $100000 to X_Mafia (uid: 8) (IP: 105.71.146.3)'),
(242, '2023-03-23 22:59:58', 'psiko_boukhris (uid: 1) (IP: 41.250.73.148) gives $60000 to Felix_Jigo (uid: 23) (IP: 41.250.8.214)'),
(243, '2023-03-23 23:03:46', 'psiko_boukhris (uid: 1) (IP: 41.250.73.148) gives $100000 to Felix_Jigo (uid: 23) (IP: 41.250.8.214)'),
(244, '2023-03-23 23:20:16', 'psiko_boukhris (uid: 1) (IP: 41.250.73.148) gives $100000 to yasser_elallawi (uid: 5) (IP: 41.251.64.150)'),
(245, '2023-03-23 23:20:19', 'psiko_boukhris (uid: 1) (IP: 41.250.73.148) gives $100000 to yasser_elallawi (uid: 5) (IP: 41.251.64.150)'),
(246, '2023-03-24 18:42:11', 'psiko_boukhris (uid: 1) (IP: 41.143.10.157) gives $100000 to salah_gozman (uid: 58) (IP: 160.177.193.86)'),
(247, '2023-03-25 11:37:13', 'X_Mafia (uid: 8) (IP: 105.71.147.205) gives $50000 to Ismail_Sanch (uid: 65) (IP: 105.67.0.148)'),
(248, '2023-03-25 15:47:15', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(249, '2023-03-25 15:47:20', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(250, '2023-03-25 15:47:24', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(251, '2023-03-25 15:47:27', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(252, '2023-03-25 15:47:31', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(253, '2023-03-25 15:49:26', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(254, '2023-03-25 15:49:29', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(255, '2023-03-25 15:49:33', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $10000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(256, '2023-03-25 15:49:43', 'ROCH_PRAN (uid: 24) (IP: 197.253.237.148) gives $9000 to benzz_lcasawi (uid: 71) (IP: 88.124.138.153)'),
(257, '2023-03-26 23:04:43', 'X_Mafia (uid: 77) (IP: 105.67.134.216) gives $1000 to Cryston_Robert (uid: 67) (IP: 160.179.0.29)'),
(258, '2023-03-27 17:07:28', 'AMRO_JOBINO (uid: 76) (IP: 41.92.51.217) gives $1500 to psiko_boukhris (uid: 1) (IP: 160.178.127.141)'),
(259, '2023-03-27 17:31:44', 'X_Mafia (uid: 77) (IP: 105.66.132.127) gives $10000 to Pablo_Walid (uid: 4) (IP: 105.67.6.16)'),
(260, '2023-03-27 17:54:56', 'ROCH_PRAN (uid: 24) (IP: 197.253.255.95) gives $20000 to GREN_BTRIK (uid: 87) (IP: 197.253.244.235)');

-- --------------------------------------------------------

--
-- Structure de la table `log_givecookie`
--

CREATE TABLE `log_givecookie` (
  `id` int(10) NOT NULL,
  `data` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_givegun`
--

CREATE TABLE `log_givegun` (
  `id` int(10) NOT NULL,
  `data` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_namechanges`
--

CREATE TABLE `log_namechanges` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_namechanges`
--

INSERT INTO `log_namechanges` (`id`, `date`, `description`) VALUES
(2, '2023-02-18 19:13:45', 'Karam_Billionaire (uid: 1265) changed Karam_Billionaire\'s (uid: 1265) name to Michael_Zodiac.'),
(3, '2023-03-14 15:56:50', 'Young_Houssam (uid: 6) changed Young_Houssam\'s (uid: 6) name to X__2.'),
(4, '2023-03-15 22:10:52', 'Andrew_Tate (uid: 62) changed Andrew_Tate\'s (uid: 62) name to BO3O_ADMIN.'),
(5, '2023-03-15 22:12:45', 'BO3O_ADMIN (uid: 62) changed BO3O_ADMIN\'s (uid: 62) name to Andrew_Tate.'),
(6, '2023-03-16 01:12:35', 'Andrew_Tate (uid: 62) changed Andrew_Tate\'s (uid: 62) name to ADMIN_BO3O.'),
(7, '2023-03-16 02:57:15', 'ADMIN_BO3O (uid: 62) changed ADMIN_BO3O\'s (uid: 62) name to khadoj_.'),
(8, '2023-03-16 02:58:45', 'khadoj_ (uid: 62) changed khadoj_\'s (uid: 62) name to ADMIN_BO3O.'),
(9, '2023-03-16 03:28:46', 'X_Mafia (uid: 56) changed X_Mafia\'s (uid: 56) name to Jason_Morinio.'),
(10, '2023-03-17 20:36:24', 'ADMIN_BO3O (uid: 62) changed ADMIN_BO3O\'s (uid: 62) name to andrew_Tat.'),
(11, '2023-03-17 20:37:05', 'andrew_Tat (uid: 62) changed andrew_Tat\'s (uid: 62) name to Yuri_Mercedes.'),
(12, '2023-03-26 02:08:29', 'X_Mafia (uid: 8) changed X_Mafia\'s (uid: 8) name to X_Mafiat.');

-- --------------------------------------------------------

--
-- Structure de la table `log_property`
--

CREATE TABLE `log_property` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_property`
--

INSERT INTO `log_property` (`id`, `date`, `description`) VALUES
(1, '2023-02-01 11:19:16', 'Karam_Billionaire (uid: 1243) purchased a Landstalker for $250000.'),
(2, '2023-02-03 13:09:38', 'Sperent_Spaw (uid: 1252) purchased blue neon for their Infernus (id: 0)'),
(3, '2023-02-03 13:10:25', 'Sperent_Spaw (uid: 1252) purchased blue neon for their Infernus (id: 0)'),
(4, '2023-02-06 20:07:43', 'Karam_Billionaire (uid: 1243) purchased a Squalo for $9000000.'),
(5, '2023-02-06 20:16:03', 'Karam_Billionaire (uid: 1243) purchased a Speeder for $9000000.'),
(6, '2023-02-06 21:46:22', 'Karam_Billionaire (uid: 1243) purchased a Maverick for $9000000.'),
(7, '2023-02-11 15:59:49', 'Karam_Billionaire (uid: 1243) purchased a Rancher for $300000.'),
(8, '2023-02-13 10:55:22', 'AZIZOS_LM3ALEM (uid: 1260) purchased a Mesa for $660000.'),
(9, '2023-02-16 15:37:14', 'Karam_Billionaire (uid: 1243) has edited business id owner to (id: Karam_Billionaire).'),
(10, '2023-02-16 20:02:17', 'Karam_Billionaire (uid: 1243) purchased a NRG-500 for $5000000.'),
(11, '2023-02-17 15:24:03', 'Karam_Billionaire (uid: 1243) purchased a FCR-900 for $600000.'),
(12, '2023-02-17 15:24:46', 'Karam_Billionaire (uid: 1243) sold their NRG-500 (id: 1388) to the dealership for $1750000'),
(13, '2023-02-17 22:30:25', 'Karam_Billionaire (uid: 1265) purchased a Sadler for $200000.'),
(14, '2023-03-14 21:34:19', 'Anas_Sousi (uid: 9) upgraded the trunk of their Super GT (id: 1435) to level 1/3.'),
(15, '2023-03-16 03:39:39', 'JAIMSE_PALACIO (uid: 35) purchased a Uranus for $200000.'),
(16, '2023-03-16 13:27:05', 'Limbo_sinyore (uid: 8) purchased a Glendale for $200000.'),
(17, '2023-03-16 13:47:02', 'Unknown_ (uid: 94) has edited business id owner to (id: Unknown_).'),
(18, '2023-03-16 13:52:19', 'CORLO_NEGRO (uid: 7) upgraded the trunk of their Glendale (id: 1450) to level 1/3.'),
(19, '2023-03-16 13:57:05', 'Limbo_sinyore (uid: 8) (IP: 196.117.3.94) sold their Glendale (id: 1450) for $1 to Mistro_Roberto (uid: 42) (IP: 196.121.49.149)'),
(20, '2023-03-16 13:59:15', 'Mistro_Roberto (uid: 42) (IP: 196.121.49.149) sold their Glendale (id: 1450) for $1 to Limbo_sinyore (uid: 8) (IP: 196.117.3.94)'),
(21, '2023-03-16 15:20:32', 'Felix_Jigo (uid: 98) purchased a Uranus for $200000.'),
(22, '2023-03-16 15:44:52', 'Nfha_Doo (uid: 30) purchased blue neon for their Uranus (id: 1457)'),
(23, '2023-03-16 15:45:53', 'Nfha_Doo (uid: 30) purchased a level 1 alarm for their Uranus (id: 1457).'),
(24, '2023-03-16 16:18:32', 'JAIMSE_PALACIO (uid: 35) upgraded the trunk of their Uranus (id: 1449) to level 1/3.'),
(25, '2023-03-16 16:24:08', 'JAIMSE_PALACIO (uid: 35) purchased yellow neon for their Uranus (id: 1449)'),
(26, '2023-03-16 16:26:58', 'JAIMSE_PALACIO (uid: 35) upgraded the trunk of their Unknown (id: 0) to level 1/3.'),
(27, '2023-03-16 16:50:45', 'Nfha_Doo (uid: 30) purchased blue neon for their Flash (id: 1459)'),
(28, '2023-03-16 16:50:59', 'Nfha_Doo (uid: 30) upgraded the trunk of their Flash (id: 1459) to level 1/3.'),
(29, '2023-03-16 16:51:01', 'Nfha_Doo (uid: 30) upgraded the trunk of their Flash (id: 1459) to level 2/3.'),
(30, '2023-03-16 16:51:03', 'Nfha_Doo (uid: 30) upgraded the trunk of their Flash (id: 1459) to level 3/3.'),
(31, '2023-03-16 19:49:01', 'Pedro_Admin (uid: 2) has edited business id owner to (id: Yassir_sancho).'),
(32, '2023-03-16 19:49:03', 'Pedro_Admin (uid: 2) has edited business id owner to (id: James_Edrian).'),
(33, '2023-03-16 20:02:33', 'JAIMSE_PALACIO (uid: 35) upgraded the trunk of their Uranus (id: 1449) to level 2/3.'),
(34, '2023-03-16 20:02:35', 'JAIMSE_PALACIO (uid: 35) upgraded the trunk of their Uranus (id: 1449) to level 3/3.'),
(35, '2023-03-16 20:06:10', 'Felix_Jigo (uid: 98) sold their Uranus (id: 1457) to the dealership for $80500'),
(36, '2023-03-17 13:54:37', 'Nfha_Doo (uid: 30) purchased a Uranus for $200000.'),
(37, '2023-03-17 14:12:13', 'Nfha_Doo (uid: 30) purchased blue neon for their Uranus (id: 1460)'),
(38, '2023-03-17 14:13:48', 'Felix_Jigo (uid: 98) purchased pink neon for their Super GT (id: 1458)'),
(39, '2023-03-17 17:16:52', 'JAIMSE_PALACIO (uid: 35) (IP: 160.166.188.130) sold their Uranus (id: 1449) for $1 to dob_lghaba (uid: 45) (IP: 102.78.98.199)'),
(40, '2023-03-17 17:20:52', 'dob_lghaba (uid: 45) (IP: 102.78.98.199) sold their Uranus (id: 1449) for $4 to JAIMSE_PALACIO (uid: 35) (IP: 160.166.188.130)'),
(41, '2023-03-17 20:13:44', 'JAIMSE_PALACIO (uid: 35) sold their Uranus (id: 1449) to the dealership for $91000'),
(42, '2023-03-17 20:21:00', 'JAIMSE_PALACIO (uid: 35) purchased a Premier for $220000.'),
(43, '2023-03-17 20:28:47', 'JAIMSE_PALACIO (uid: 35) purchased blue neon for their Premier (id: 1462)'),
(44, '2023-03-17 20:29:11', 'JAIMSE_PALACIO (uid: 35) upgraded the trunk of their Premier (id: 1462) to level 1/3.'),
(45, '2023-03-17 20:29:14', 'JAIMSE_PALACIO (uid: 35) upgraded the trunk of their Premier (id: 1462) to level 2/3.'),
(46, '2023-03-17 20:29:18', 'JAIMSE_PALACIO (uid: 35) upgraded the trunk of their Premier (id: 1462) to level 3/3.'),
(47, '2023-03-18 16:34:56', 'GOD_TIPO (uid: 125) has edited business id owner to (id: GOD_TIPO).'),
(48, '2023-03-19 20:56:09', 'GOD_TIPO (uid: 11) purchased Supermarket (id: 33) for $0.'),
(49, '2023-03-19 21:18:57', 'Felix_Jigo (uid: 23) purchased green neon for their Tow Truck (id: 1452)'),
(50, '2023-03-19 22:55:19', 'Vini_Edrian (uid: 7) purchased Clothes Shop (id: 11) for $2250000.'),
(51, '2023-03-19 22:55:55', 'Vini_Edrian (uid: 7) (IP: 196.65.226.211) sold their Clothes Shop business (id: 11) for $1 to STEVAW_MARTINEZ (uid: 9) (IP: 105.68.185.116)'),
(52, '2023-03-20 00:05:03', 'James_Edrian (uid: 16) purchased a Mesa for $660000.'),
(53, '2023-03-20 00:12:05', 'Vini_Edrian (uid: 7) purchased a Mesa for $660000.'),
(54, '2023-03-20 02:45:12', 'psiko_boukhris (uid: 1) purchased Supermarket (id: 3) for $1800000.'),
(55, '2023-03-20 14:55:58', 'GOD_TIPO (uid: 11) purchased a Huntley for $440000.'),
(56, '2023-03-20 15:18:07', 'Dyablo_Dr3awi (uid: 28) purchased a Landstalker for $250000.'),
(57, '2023-03-20 15:22:36', 'GOD_TIPO (uid: 11) sold their Huntley (id: 1472) to the dealership for $0'),
(58, '2023-03-20 17:20:45', 'CORLO_NEGRO (uid: 30) purchased Restaurant (id: 22) for $2500000.'),
(59, '2023-03-20 17:51:03', 'CORLO_NEGRO (uid: 30) purchased a Mesa for $660000.'),
(60, '2023-03-20 17:57:27', 'Pablo_Walid (uid: 4) purchased a Landstalker for $250000.'),
(61, '2023-03-20 17:59:11', 'CORLO_NEGRO (uid: 30) purchased a Mesa for $660000.'),
(62, '2023-03-20 18:31:53', 'GOD_TIPO (uid: 11) has edited business id owner to (id: Pablo_Walid).'),
(63, '2023-03-20 18:39:25', 'GOD_TIPO (uid: 11) (IP: 105.67.6.52) sold their Turismo (id: 1478) for $100 to psiko_boukhris (uid: 1) (IP: 160.176.110.194)'),
(64, '2023-03-20 18:46:18', 'GOD_TIPO (uid: 11) purchased yellow neon for their Euros (id: 0)'),
(65, '2023-03-20 18:47:14', 'GOD_TIPO (uid: 11) purchased yellow neon for their Euros (id: 0)'),
(66, '2023-03-20 18:48:40', 'GOD_TIPO (uid: 11) purchased yellow neon for their Euros (id: 1479)'),
(67, '2023-03-20 19:16:28', 'GOD_TIPO (uid: 11) purchased red neon for their Turismo (id: 1478)'),
(68, '2023-03-20 19:25:06', 'GOD_TIPO (uid: 11) purchased Large garage (id: 6) for $350000.'),
(69, '2023-03-20 19:25:30', 'GOD_TIPO (uid: 11) sold their Large garage (id: 6) to the state for $262500'),
(70, '2023-03-21 00:31:41', 'GOD_TIPO (uid: 11) purchased Large garage (id: 6) for $350000.'),
(71, '2023-03-22 05:15:40', 'psiko_boukhris (uid: 1) (IP: 105.154.17.4) sold their Supermarket business (id: 3) for $1 to JAIMSE_PALACIO (uid: 17) (IP: 196.86.44.37)'),
(72, '2023-03-22 05:23:58', 'psiko_boukhris (uid: 1) purchased Clothes Shop (id: 29) for $2250000.'),
(73, '2023-03-22 06:16:57', 'JAIMSE_PALACIO (uid: 17) purchased a Landstalker for $250000.'),
(74, '2023-03-22 06:17:08', 'JAIMSE_PALACIO (uid: 17) purchased a Rancher for $300000.'),
(75, '2023-03-22 06:17:19', 'JAIMSE_PALACIO (uid: 17) purchased a Mesa for $660000.'),
(76, '2023-03-22 06:17:27', 'JAIMSE_PALACIO (uid: 17) purchased a Huntley for $440000.'),
(77, '2023-03-22 07:37:31', 'JAIMSE_PALACIO (uid: 17) sold their Supermarket business (id: 3) to the state for pJAIMSE_PALACIO'),
(78, '2023-03-22 07:39:47', 'JAIMSE_PALACIO (uid: 17) purchased Supermarket (id: 10) for $1800000.'),
(79, '2023-03-23 00:53:35', 'GOD_TIPO (uid: 11) (IP: 105.71.19.131) sold their Euros (id: 1479) for $1 to ROCH_PRAN (uid: 24) (IP: 197.253.255.229)'),
(80, '2023-03-23 22:58:25', 'Felix_Jigo (uid: 23) purchased red neon for their Bullet (id: 1467)'),
(81, '2023-03-23 23:00:00', 'Felix_Jigo (uid: 23) upgraded the trunk of their Bullet (id: 1467) to level 1/3.'),
(82, '2023-03-23 23:00:04', 'Felix_Jigo (uid: 23) upgraded the trunk of their Bullet (id: 1467) to level 2/3.'),
(83, '2023-03-23 23:00:06', 'Felix_Jigo (uid: 23) upgraded the trunk of their Bullet (id: 1467) to level 3/3.'),
(84, '2023-03-23 23:03:12', 'X_Mafia (uid: 8) purchased red neon for their Bullet (id: 1487)'),
(85, '2023-03-24 05:19:17', 'STEVAW_MARTINEZ (uid: 9) sold their Huntley (id: 1468) to the dealership for $0'),
(86, '2023-03-24 14:32:33', 'Dyablo_Dr3awi (uid: 28) sold their NRG-500 (id: 1488) to the dealership for $0'),
(87, '2023-03-24 14:33:12', 'Dyablo_Dr3awi (uid: 28) sold their NRG-500 (id: 1489) to the dealership for $0'),
(88, '2023-03-25 16:32:06', 'ROCH_PRAN (uid: 24) purchased a Rancher for $300000.'),
(89, '2023-03-25 16:33:59', 'benzz_lcasawi (uid: 71) purchased a Mesa for $660000.'),
(90, '2023-03-26 02:31:20', 'ROCH_PRAN (uid: 24) purchased a Mesa for $660000.'),
(91, '2023-03-26 04:27:44', 'ROCH_PRAN (uid: 24) (IP: 197.253.236.245) sold their Rancher (id: 1492) for $1 to psiko_boukhris (uid: 1) (IP: 41.141.71.91)'),
(92, '2023-03-26 04:40:38', 'ROCH_PRAN (uid: 24) purchased white neon for their Rancher (id: 1492)'),
(93, '2023-03-26 04:41:39', 'ROCH_PRAN (uid: 24) purchased white neon for their Rancher (id: 1492)'),
(94, '2023-03-26 04:41:41', 'ROCH_PRAN (uid: 24) purchased white neon for their Rancher (id: 1492)'),
(95, '2023-03-26 04:42:28', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Rancher (id: 1492) to level 1/3.'),
(96, '2023-03-26 04:42:30', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Rancher (id: 1492) to level 2/3.'),
(97, '2023-03-26 04:42:31', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Rancher (id: 1492) to level 3/3.'),
(98, '2023-03-26 04:52:34', 'psiko_boukhris (uid: 1) (IP: 41.141.71.91) sold their Clothes Shop business (id: 29) for $1 to ROCH_PRAN (uid: 24) (IP: 197.253.193.10)'),
(99, '2023-03-26 04:58:06', 'psiko_boukhris (uid: 1) purchased Dealership (id: 1) for $15000000.'),
(100, '2023-03-26 04:58:36', 'ROCH_PRAN (uid: 24) purchased a Rancher for $300000.'),
(101, '2023-03-26 04:59:36', 'psiko_boukhris (uid: 1) purchased a Mesa for $660000.'),
(102, '2023-03-26 05:05:14', 'psiko_boukhris (uid: 1) sold their Dealership business (id: 1) to the state for Ppsiko_boukhris'),
(103, '2023-03-26 18:24:43', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Rancher (id: 1496) to level 1/3.'),
(104, '2023-03-26 18:24:45', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Rancher (id: 1496) to level 2/3.'),
(105, '2023-03-26 18:24:47', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Rancher (id: 1496) to level 3/3.'),
(106, '2023-03-26 18:25:24', 'ROCH_PRAN (uid: 24) purchased a level 3 alarm for their Rancher (id: 1496).'),
(107, '2023-03-26 18:25:53', 'ROCH_PRAN (uid: 24) purchased white neon for their Rancher (id: 1496)'),
(108, '2023-03-26 23:43:38', 'ROCH_PRAN (uid: 24) purchased blue neon for their Mesa (id: 1495)'),
(109, '2023-03-26 23:44:45', 'ROCH_PRAN (uid: 24) purchased a level 3 alarm for their Mesa (id: 1495).'),
(110, '2023-03-26 23:45:10', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Mesa (id: 1495) to level 1/3.'),
(111, '2023-03-26 23:45:12', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Mesa (id: 1495) to level 2/3.'),
(112, '2023-03-26 23:45:13', 'ROCH_PRAN (uid: 24) upgraded the trunk of their Mesa (id: 1495) to level 3/3.');

-- --------------------------------------------------------

--
-- Structure de la table `log_punishments`
--

CREATE TABLE `log_punishments` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_punishments`
--

INSERT INTO `log_punishments` (`id`, `date`, `description`) VALUES
(1, '2023-02-10 19:25:01', 'Karam_Billionaire (uid: 1243) jailed Karam_Billionaire (uid: 1243) for 1 minutes, reason: TEST'),
(2, '2023-02-10 20:52:27', 'Karam_Billionaire (uid: 1243) jailed Karam_Billionaire (uid: 1243) for 1 minutes, reason: AH'),
(3, '2023-02-10 20:52:38', 'Karam_Billionaire (uid: 1243) jailed Karam_Billionaire (uid: 1243) for 1 minutes, reason: AH'),
(4, '2023-02-10 20:53:42', 'Karam_Billionaire (uid: 1243) jailed Karam_Billionaire (uid: 1243) for 1 minutes, reason: AH'),
(5, '2023-02-10 20:53:44', 'Karam_Billionaire (uid: 1243) jailed Karam_Billionaire (uid: 1243) for 1 minutes, reason: AH'),
(6, '2023-02-13 09:05:03', 'Discord Team kicked Pablo_Hway (uid: 0), reason: ir7al ya 3adwa llah hhhh.'),
(7, '2023-02-17 21:51:21', 'Karam_Billionaire (uid: 1265) jailed Karam_Billionaire (uid: 1265) for 1 minutes, reason: TES'),
(8, '2023-02-22 17:39:43', 'Discord Team kicked Wahid_Titox (uid: 1277), reason: by hehehe'),
(9, '2023-03-14 19:19:17', 'POCO_LOCO (uid: 34) jailed abdollah_algnawi (uid: 14) for 5 minutes, reason: hrp'),
(10, '2023-03-14 19:30:41', 'POCO_LOCO (uid: 34) jailed Limbo_sinyore (uid: 8) for 9999999 minutes, reason: hackooor'),
(11, '2023-03-14 20:54:50', 'Felix_Jigo (uid: 3) jailed Limbo_sinyore (uid: 8) for 1 minutes, reason: -'),
(12, '2023-03-14 21:26:25', 'Unknown_ (uid: 94) jailed Unknown_ (uid: 94) for 1 minutes, reason: 1'),
(13, '2023-03-14 21:26:33', 'Unknown_ (uid: 94) silently jailed Unknown_ (uid: 94) for 1 minutes, reason: 1'),
(14, '2023-03-14 22:10:12', 'POCO_LOCO (uid: 34) has been prisoned for 20 minutes, reason: failing to change their name.'),
(15, '2023-03-15 05:55:49', 'Alex_Cobra (uid: 1) jailed Alex_Cobra (uid: 1) for 1 minutes, reason: test'),
(16, '2023-03-15 05:56:15', 'Alex_Cobra (uid: 1) jailed Alex_Cobra (uid: 1) for 1 minutes, reason: test'),
(17, '2023-03-15 12:08:51', 'Pedro_Admin (uid: 2) kicked Ayoub_Jasm (uid: 91), reason: mrg whyd lhack'),
(18, '2023-03-15 12:13:46', 'POCO_LOCO (uid: 34) jailed matouss_clean (uid: 121) for 9999999 minutes, reason: hackoor d jumia'),
(19, '2023-03-15 12:15:04', 'POCO_LOCO (uid: 34) jailed Ferda_Fratilo (uid: 126) for 2 minutes, reason: hrp language'),
(20, '2023-03-15 12:30:32', 'X_Mafia (uid: 56) jailed matouss_clean (uid: 121) for 1 minutes, reason: test '),
(21, '2023-03-15 12:37:24', 'POCO_LOCO (uid: 34) jailed GOD_TIPO (uid: 125) for 5 minutes, reason: 9weed carkill'),
(22, '2023-03-15 14:59:21', 'Smoke_Jigo (uid: 4) jailed Ismail_guzmane (uid: 105) for 30 minutes, reason: rtah chwiya'),
(23, '2023-03-15 15:02:18', 'Smoke_Jigo (uid: 4) jailed Comi_Escobar (uid: 123) for 30 minutes, reason: backflip'),
(24, '2023-03-15 15:14:26', 'Reda_Tazi (uid: 5) prisoned Smoke_Jigo (uid: 4) for 30 minutes, reason: DM [/dm]'),
(25, '2023-03-15 16:25:52', 'Andrew_Tate (uid: 62) jailed anuar_oustora (uid: 133) for 5 minutes, reason: sayk tono lspd'),
(26, '2023-03-15 18:40:09', 'X_Mafia (uid: 56) jailed Yassir_sancho (uid: 135) for 5 minutes, reason: bgha la carte'),
(27, '2023-03-15 19:37:43', 'Reda_Tazi (uid: 5) jailed OUSSAMA_HARAKAT (uid: 68) for 99999 minutes, reason: TELEPORT HACK'),
(28, '2023-03-15 21:39:06', 'GOD_TIPO (uid: 125) jailed moha_moro (uid: 145) for 2 minutes, reason: $'),
(29, '2023-03-15 22:29:43', 'Vini_Edrian (uid: 23) jailed Limbo_sinyore (uid: 8) for 15 minutes, reason: back fleep mra khra ban'),
(30, '2023-03-15 22:31:44', 'Vini_Edrian (uid: 23) jailed Limbo_sinyore (uid: 8) for 1 minutes, reason: akher mra'),
(31, '2023-03-15 22:34:26', 'Vini_Edrian (uid: 23) jailed DRISS_ESCOBAR (uid: 86) for 15 minutes, reason: pawer gaming'),
(32, '2023-03-15 23:20:05', 'X_Mafia (uid: 56) jailed Kaspre_Edrian (uid: 29) for 10 minutes, reason: pedro'),
(33, '2023-03-15 23:21:14', 'Andrew_Tate (uid: 62) jailed Chliha_Olmhjob (uid: 110) for 5 minutes, reason: trol'),
(34, '2023-03-15 23:26:43', 'Andrew_Tate (uid: 62) jailed Anas_Tali (uid: 63) for 5 minutes, reason: trol'),
(35, '2023-03-15 23:40:41', 'Pedro_Admin (uid: 2) jailed Hamdi_johnson (uid: 156) for 5 minutes, reason: sir'),
(36, '2023-03-15 23:53:26', 'Pedro_Admin (uid: 2) jailed Lmour_pholoko (uid: 76) for 1 minutes, reason: 1'),
(37, '2023-03-16 00:08:34', 'Andrew_Tate (uid: 62) jailed yasser_elallawi (uid: 122) for 5 minutes, reason: trol'),
(38, '2023-03-16 00:08:53', 'Andrew_Tate (uid: 62) jailed AYMEN_LME3DAWI (uid: 28) for 5 minutes, reason: trol'),
(39, '2023-03-16 00:13:22', 'Pedro_Admin (uid: 2) kicked Leo_Garcia (uid: 155), reason: 1'),
(40, '2023-03-16 00:16:12', 'psiko_boukhris (uid: 54) prisoned Yassir_sancho (uid: 135) for 30 minutes, reason: DM [/dm]'),
(41, '2023-03-16 00:16:20', 'psiko_boukhris (uid: 54) prisoned dob_lghaba (uid: 45) for 30 minutes, reason: DM [/dm]'),
(42, '2023-03-16 00:16:22', 'psiko_boukhris (uid: 54) prisoned dob_lghaba (uid: 45) for 60 minutes, reason: DM [/dm]'),
(43, '2023-03-16 00:16:25', 'psiko_boukhris (uid: 54) banned dob_lghaba (uid: 45), reason: DM (3/3 warnings)'),
(44, '2023-03-16 00:17:01', 'psiko_boukhris (uid: 54) prisoned psiko_boukhris (uid: 54) for 30 minutes, reason: DM [/dm]'),
(45, '2023-03-16 00:17:37', 'psiko_boukhris (uid: 54) prisoned abdollah_algnawi (uid: 14) for 30 minutes, reason: DM [/dm]'),
(46, '2023-03-16 00:17:44', 'psiko_boukhris (uid: 54) prisoned SALIM_LUCAS (uid: 113) for 30 minutes, reason: DM [/dm]'),
(47, '2023-03-16 00:31:36', 'Rachid_ekambi (uid: 17) jailed psiko_boukhris (uid: 54) for 1 minutes, reason: .'),
(48, '2023-03-16 01:06:31', 'Rachid_ekambi (uid: 17) jailed Yassir_sancho (uid: 135) for 1 minutes, reason: .'),
(49, '2023-03-16 01:20:00', 'Rachid_ekambi (uid: 17) jailed abdollah_algnawi (uid: 14) for 1 minutes, reason: .'),
(50, '2023-03-16 01:35:32', 'Vini_Edrian (uid: 23) jailed Kaspre_Edrian (uid: 29) for 1 minutes, reason: k'),
(51, '2023-03-16 02:14:35', 'ADMIN_BO3O (uid: 62) jailed Vini_Edrian (uid: 23) for 1 minutes, reason: no clip'),
(52, '2023-03-16 02:38:17', 'ADMIN_BO3O (uid: 62) jailed Eazy_Gaviria (uid: 100) for 5 minutes, reason: mix rp'),
(53, '2023-03-16 03:40:06', 'psiko_boukhris (uid: 54) prisoned ANAS_RAID (uid: 13) for 30 minutes, reason: DM [/dm]'),
(54, '2023-03-16 03:42:33', 'Rachid_ekambi (uid: 17) jailed ANAS_RAID (uid: 13) for 1 minutes, reason: .'),
(55, '2023-03-16 05:17:28', 'Rachid_ekambi (uid: 17) jailed STEVAW_MARTINEZ (uid: 48) for 1 minutes, reason: .'),
(56, '2023-03-16 12:13:08', 'Smoke_Jigo (uid: 4) jailed matouss_clean (uid: 121) for 5 minutes, reason: pg'),
(57, '2023-03-16 14:00:37', 'ADMIN_BO3O (uid: 62) jailed CORLO_NEGRO (uid: 7) for 15 minutes, reason: pawer geming '),
(58, '2023-03-16 14:25:48', 'X_Mafia (uid: 163) jailed moha_moro (uid: 145) for 5 minutes, reason: mbelbelha free kil f safe zone w tfnach'),
(59, '2023-03-16 14:42:05', 'ADMIN_BO3O (uid: 62) jailed POP_SMOKE (uid: 157) for 99999 minutes, reason: teleport hacking + sped'),
(60, '2023-03-16 15:24:39', 'psiko_boukhris (uid: 54) jailed anuar_oustora (uid: 133) for 1000 minutes, reason: ki drab bnadem f gren zone '),
(61, '2023-03-16 15:31:43', 'psiko_boukhris (uid: 54) jailed psiko_boukhris (uid: 54) for 1 minutes, reason: .'),
(62, '2023-03-16 15:34:18', 'psiko_boukhris (uid: 54) jailed anuar_oustora (uid: 133) for 1 minutes, reason: .'),
(63, '2023-03-16 15:48:26', 'X_Mafia (uid: 163) jailed BADR_PEDRI (uid: 182) for 2 minutes, reason: chafer moto men comico'),
(64, '2023-03-16 16:51:37', 'X_Mafia (uid: 163) silently banned Selfx_Tchapo (uid: 49), reason: hack'),
(65, '2023-03-16 17:08:17', 'X_Mafia (uid: 163) jailed POP_SMOKE (uid: 157) for 24 minutes, reason: no fear w tardif leainin men lfou9'),
(66, '2023-03-16 17:11:39', 'X_Mafia (uid: 163) jailed POP_SMOKE (uid: 157) for 4 minutes, reason: no fear '),
(67, '2023-03-16 18:01:38', 'psiko_boukhris (uid: 54) jailed Kwika_Sriwila (uid: 117) for 1000 minutes, reason: trol police'),
(68, '2023-03-16 18:04:56', 'James_Edrian (uid: 36) jailed Kwika_Sriwila (uid: 117) for 15 minutes, reason: troll'),
(69, '2023-03-16 18:05:49', 'James_Edrian (uid: 36) jailed abdollah_algnawi (uid: 14) for 15 minutes, reason: no fear'),
(70, '2023-03-16 18:09:49', 'psiko_boukhris (uid: 54) jailed Kwika_Sriwila (uid: 117) for 1 minutes, reason: .'),
(71, '2023-03-16 18:15:16', 'psiko_boukhris (uid: 54) jailed abdollah_algnawi (uid: 14) for 1 minutes, reason: .'),
(72, '2023-03-16 20:45:01', 'psiko_boukhris (uid: 54) prisoned HADES_SMOKERS (uid: 178) for 30 minutes, reason: DM [/dm]'),
(73, '2023-03-16 20:45:36', 'psiko_boukhris (uid: 54) prisoned HADES_SMOKERS (uid: 178) for 60 minutes, reason: DM [/dm]'),
(74, '2023-03-16 20:45:37', 'psiko_boukhris (uid: 54) banned HADES_SMOKERS (uid: 178), reason: DM (3/3 warnings)'),
(75, '2023-03-16 20:56:00', 'X_Mafia (uid: 163) jailed POP_SMOKE (uid: 157) for 30 minutes, reason: no fear w toxic w freekil'),
(76, '2023-03-17 13:09:46', 'Pedro_Admin (uid: 2) jailed James_Edrian (uid: 36) for 1 minutes, reason: wld l9hba '),
(77, '2023-03-17 13:11:46', 'James_Edrian (uid: 36) jailed James_Edrian (uid: 36) for 1 minutes, reason: test'),
(78, '2023-03-17 15:02:26', 'psiko_boukhris (uid: 54) prisoned Limbo_sinyore (uid: 8) for 30 minutes, reason: DM [/dm]'),
(79, '2023-03-17 15:02:36', 'psiko_boukhris (uid: 54) prisoned Limbo_sinyore (uid: 8) for 60 minutes, reason: DM [/dm]'),
(80, '2023-03-17 15:02:38', 'psiko_boukhris (uid: 54) banned Limbo_sinyore (uid: 8), reason: DM (3/3 warnings)'),
(81, '2023-03-17 15:56:34', 'X_Mafia (uid: 163) jailed hmed_twil (uid: 131) for 99 minutes, reason: speed'),
(82, '2023-03-17 17:15:15', 'X_Mafia (uid: 163) has unbanned Selfx_Tchapo.'),
(83, '2023-03-17 17:57:12', 'Unknown_ (uid: 94) jailed Unknown_ (uid: 94) for 1 minutes, reason: 1'),
(84, '2023-03-17 17:57:15', 'Unknown_ (uid: 94) silently jailed Unknown_ (uid: 94) for 1 minutes, reason: 1'),
(85, '2023-03-17 20:56:35', 'psiko_boukhris (uid: 54) jailed hmed_twil (uid: 131) for 1 minutes, reason: .'),
(86, '2023-03-18 14:21:35', 'GOD_TIPO (uid: 125) jailed AYMEN_LME3DAWI (uid: 28) for 3 minutes, reason: bach thyd mnk douda'),
(87, '2023-03-18 14:24:59', 'GOD_TIPO (uid: 125) jailed abdollah_algnawi (uid: 14) for 3 minutes, reason: tanta fik dooda hh'),
(88, '2023-03-19 20:32:48', 'GOD_TIPO (uid: 11) jailed GOD_TIPO (uid: 11) for 1 minutes, reason: "'),
(89, '2023-03-20 01:36:53', 'Vini_Edrian (uid: 7) kicked Dyablo_Dr3awi (uid: 28), reason: k'),
(90, '2023-03-20 01:37:46', 'Vini_Edrian (uid: 7) kicked Dyablo_Dr3awi (uid: 28), reason: k'),
(91, '2023-03-20 17:43:13', 'GOD_TIPO (uid: 11) jailed psiko_boukhris (uid: 1) for 19 minutes, reason: ?'),
(92, '2023-03-20 22:07:21', 'Dyablo_Dr3awi (uid: 28) jailed abdollah_algnawi (uid: 12) for 5 minutes, reason: NO FEAR'),
(93, '2023-03-20 22:07:54', 'Dyablo_Dr3awi (uid: 28) jailed abdollah_algnawi (uid: 12) for 5 minutes, reason: NO FEAR + CUFF BLA SB AT'),
(94, '2023-03-21 12:42:28', 'Dyablo_Dr3awi (uid: 28) jailed Dyablo_Dr3awi (uid: 28) for 1 minutes, reason: TELE'),
(95, '2023-03-21 12:42:33', 'Dyablo_Dr3awi (uid: 28) jailed Dyablo_Dr3awi (uid: 28) for 1 minutes, reason: TELE'),
(96, '2023-03-21 13:10:09', 'Dyablo_Dr3awi (uid: 28) jailed Dyablo_Dr3awi (uid: 28) for 1 minutes, reason: O'),
(97, '2023-03-22 04:07:06', 'psiko_boukhris (uid: 1) has been prisoned for 20 minutes, reason: failing to change their name.'),
(98, '2023-03-22 04:07:35', 'psiko_boukhris (uid: 1) has been prisoned for 20 minutes, reason: failing to change their name.'),
(99, '2023-03-22 04:09:22', 'psiko_boukhris (uid: 1) jailed psiko_boukhris (uid: 1) for 1 minutes, reason: a'),
(100, '2023-03-22 04:39:39', 'psiko_boukhris (uid: 1) jailed psiko_boukhris (uid: 1) for 1 minutes, reason: no fear'),
(101, '2023-03-22 05:03:49', 'psiko_boukhris (uid: 1) prisoned Snop_Amar (uid: 47) for 30 minutes, reason: DM [/dm]'),
(102, '2023-03-22 05:03:51', 'psiko_boukhris (uid: 1) prisoned Snop_Amar (uid: 47) for 60 minutes, reason: DM [/dm]'),
(103, '2023-03-22 05:03:53', 'psiko_boukhris (uid: 1) banned Snop_Amar (uid: 47), reason: DM (3/3 warnings)'),
(104, '2023-03-22 20:41:41', 'X_Mafia (uid: 8) jailed abdollah_algnawi (uid: 12) for 99 minutes, reason: bbissel'),
(105, '2023-03-24 20:13:50', 'X_Mafia (uid: 8) prisoned AMRO_MINE (uid: 57) for 1 minutes, reason: test '),
(106, '2023-03-25 16:51:49', 'GOD_TIPO (uid: 11) jailed hmed_twil (uid: 72) for 50 minutes, reason: ('),
(107, '2023-03-25 16:58:03', 'GOD_TIPO (uid: 11) has unbanned hmed_twil.'),
(108, '2023-03-26 01:57:55', 'X_Mafia (uid: 8) prisoned X_Mafia (uid: 8) for 30 minutes, reason: DM [/dm]'),
(109, '2023-03-26 04:04:29', 'X_Mafia (uid: 77) jailed psiko_boukhris (uid: 1) for 1 minutes, reason: mass rp'),
(110, '2023-03-27 18:14:25', 'ROCH_PRAN (uid: 24) jailed ROCH_PRAN (uid: 24) for 1 minutes, reason: tesy');

-- --------------------------------------------------------

--
-- Structure de la table `log_referrals`
--

CREATE TABLE `log_referrals` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `log_vip`
--

CREATE TABLE `log_vip` (
  `id` int(10) NOT NULL,
  `date` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `log_vip`
--

INSERT INTO `log_vip` (`id`, `date`, `description`) VALUES
(1, '2023-02-17 21:48:00', 'Karam_Billionaire (uid: 1265) has given Karam_Billionaire (uid: 1265) a Legendary VIP package for 3 days.'),
(2, '2023-03-18 16:48:13', 'GOD_TIPO (uid: 125) has given GOD_TIPO (uid: 125) a Legendary VIP package for 300 days.'),
(3, '2023-03-20 00:14:09', 'Vini_Edrian (uid: 7) has given Vini_Edrian (uid: 7) a Legendary VIP package for 4 days.'),
(4, '2023-03-20 00:14:12', 'Vini_Edrian (uid: 7) has given Vini_Edrian (uid: 7) a Legendary VIP package for 300 days.'),
(5, '2023-03-20 18:37:09', 'GOD_TIPO (uid: 11) has given GOD_TIPO (uid: 11) a Legendary VIP package for 365 days.'),
(6, '2023-03-22 22:02:50', 'GOD_TIPO (uid: 11) has given GOD_TIPO (uid: 11) a Legendary VIP package for 365 days.'),
(7, '2023-03-24 18:36:14', 'GOD_TIPO (uid: 11) has given GOD_TIPO (uid: 11) a Gold VIP package for 250 days.');

-- --------------------------------------------------------

--
-- Structure de la table `object`
--

CREATE TABLE `object` (
  `mobjID` int(8) NOT NULL,
  `mobjModel` int(8) NOT NULL DEFAULT '0',
  `mobjX` float NOT NULL DEFAULT '0',
  `mobjY` float NOT NULL DEFAULT '0',
  `mobjZ` float NOT NULL DEFAULT '0',
  `mobjRX` float NOT NULL DEFAULT '0',
  `mobjRY` float NOT NULL DEFAULT '0',
  `mobjRZ` float NOT NULL DEFAULT '0',
  `mobjInterior` int(8) NOT NULL DEFAULT '0',
  `mobjWorld` int(8) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `phonebook`
--

CREATE TABLE `phonebook` (
  `name` varchar(24) DEFAULT NULL,
  `number` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `points`
--

CREATE TABLE `points` (
  `id` tinyint(2) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `capturedby` varchar(24) DEFAULT 'No-one',
  `capturedgang` tinyint(2) DEFAULT '-1',
  `type` tinyint(2) DEFAULT '0',
  `profits` int(10) DEFAULT '0',
  `time` tinyint(2) DEFAULT '10',
  `point_x` float DEFAULT '0',
  `point_y` float DEFAULT '0',
  `point_z` float DEFAULT '0',
  `pointinterior` tinyint(2) DEFAULT '0',
  `pointworld` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rp_atms`
--

CREATE TABLE `rp_atms` (
  `atmID` int(12) NOT NULL,
  `atmX` float DEFAULT '0',
  `atmY` float DEFAULT '0',
  `atmZ` float DEFAULT '0',
  `atmA` float DEFAULT '0',
  `atmInterior` int(12) DEFAULT '0',
  `atmWorld` int(12) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `rp_atms`
--

INSERT INTO `rp_atms` (`atmID`, `atmX`, `atmY`, `atmZ`, `atmA`, `atmInterior`, `atmWorld`) VALUES
(2, 1495.33, -1749.95, 15.3468, -89.5438, 0, 0),
(4, 1102.38, -1438.24, 15.6768, -176.786, 0, 0),
(6, 1753.91, -1095.82, 23.9359, 178.111, 0, 0),
(12, 1310.16, -1366.91, 13.3557, 94.9601, 0, 0),
(14, -2281.83, 2293.33, 4.8105, 177.015, 0, 0),
(15, 1171.55, -1328.57, 15.1953, 99.5076, 0, 0),
(16, 1172.55, -1317.97, 15.3938, 3.1405, 0, 0),
(17, 1172.28, -1319.17, 14.9921, 82.139, 0, 0),
(26, 2401.08, 2470.77, 1569.48, 92.1998, 1, 1),
(27, 2076.35, 1236.25, 1019.08, 181.615, 1, 3000011),
(28, 1257.19, -811.256, 84.1406, 354.569, 0, 0),
(29, 1147.52, -1415.92, 13.6725, -89.6118, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `rp_contacts`
--

CREATE TABLE `rp_contacts` (
  `ID` int(11) NOT NULL,
  `Phone` int(12) DEFAULT '0',
  `Contact` varchar(24) DEFAULT NULL,
  `Number` int(12) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `rp_contacts`
--

INSERT INTO `rp_contacts` (`ID`, `Phone`, `Contact`, `Number`) VALUES
(1, 262813, 'me', 262813),
(2, 413159, 'walid pablo', 297911),
(3, 297911, 'Tipo admin', 413159),
(4, 413159, 'lspd', 112),
(5, 506699, 'amine', 1);

-- --------------------------------------------------------

--
-- Structure de la table `rp_dealercars`
--

CREATE TABLE `rp_dealercars` (
  `ID` int(12) NOT NULL,
  `Company` int(12) DEFAULT '0',
  `Model` int(4) DEFAULT '0',
  `Price` int(12) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rp_furniture`
--

CREATE TABLE `rp_furniture` (
  `fID` int(10) NOT NULL,
  `fHouseID` int(10) DEFAULT NULL,
  `fModel` smallint(5) DEFAULT NULL,
  `Mat1` varchar(64) DEFAULT NULL,
  `Mat2` varchar(64) DEFAULT NULL,
  `Mat3` varchar(64) DEFAULT NULL,
  `MatColor1` varchar(64) DEFAULT NULL,
  `MatColor2` varchar(64) DEFAULT NULL,
  `MatColor3` varchar(64) DEFAULT NULL,
  `fX` float DEFAULT NULL,
  `fY` float DEFAULT NULL,
  `fZ` float DEFAULT NULL,
  `fRX` float DEFAULT NULL,
  `fRY` float DEFAULT NULL,
  `fRZ` float DEFAULT NULL,
  `fInterior` tinyint(2) DEFAULT NULL,
  `fWorld` int(10) DEFAULT NULL,
  `fCode` int(10) DEFAULT '0',
  `fMoney` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `rp_gundamages`
--

CREATE TABLE `rp_gundamages` (
  `Weapon` tinyint(2) DEFAULT NULL,
  `Damage` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `rp_gundamages`
--

INSERT INTO `rp_gundamages` (`Weapon`, `Damage`) VALUES
(2, 15),
(8, 32),
(24, 50),
(31, 20),
(32, 20),
(30, 76),
(29, 30),
(27, 40),
(25, 10),
(22, 18),
(4, 100),
(28, 15),
(26, 20),
(23, 40),
(34, 50),
(33, 35);

-- --------------------------------------------------------

--
-- Structure de la table `rp_payphones`
--

CREATE TABLE `rp_payphones` (
  `phID` int(12) NOT NULL,
  `phNumber` int(12) DEFAULT '0',
  `phX` float DEFAULT '0',
  `phY` float DEFAULT '0',
  `phZ` float DEFAULT '0',
  `phA` float DEFAULT '0',
  `phInterior` int(12) DEFAULT '0',
  `phWorld` int(12) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `rp_payphones`
--

INSERT INTO `rp_payphones` (`phID`, `phNumber`, `phX`, `phY`, `phZ`, `phA`, `phInterior`, `phWorld`) VALUES
(2, 4530751, 1233.59, -1310.22, 13.1823, 92.6926, 0, 0),
(3, 7088932, 1111.08, -1415.63, 13.2239, 186.379, 0, 0),
(4, 8420046, 1145.58, -1415.58, 13.3456, -175.881, 0, 0),
(5, 5916898, 1753.28, -1094.45, 23.6909, 177.913, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `server_info`
--

CREATE TABLE `server_info` (
  `totalconnections` int(11) NOT NULL,
  `tax` int(11) NOT NULL,
  `govvault` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- --------------------------------------------------------

--
-- Structure de la table `shots`
--

CREATE TABLE `shots` (
  `id` int(10) NOT NULL,
  `playerid` smallint(3) DEFAULT NULL,
  `weaponid` tinyint(2) DEFAULT NULL,
  `hittype` tinyint(2) DEFAULT NULL,
  `hitid` int(10) DEFAULT NULL,
  `hitplayer` varchar(24) DEFAULT NULL,
  `pos_x` float DEFAULT NULL,
  `pos_y` float DEFAULT NULL,
  `pos_z` float DEFAULT NULL,
  `timestamp` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `speedcameras`
--

CREATE TABLE `speedcameras` (
  `speedID` int(11) NOT NULL,
  `speedRange` float DEFAULT '0',
  `speedLimit` float DEFAULT '0',
  `speedX` float DEFAULT '0',
  `speedY` float DEFAULT '0',
  `speedZ` float DEFAULT '0',
  `speedAngle` float DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `speedcameras`
--

INSERT INTO `speedcameras` (`speedID`, `speedRange`, `speedLimit`, `speedX`, `speedY`, `speedZ`, `speedAngle`) VALUES
(6, 20, 70, 1074.76, -1415.08, 12.5054, 357.709),
(7, 50, 70, 1547.58, -1737.78, 12.3468, 1.0739),
(8, 50, 50, 1531.07, -1586.49, 12.3468, 179.362);

-- --------------------------------------------------------

--
-- Structure de la table `texts`
--

CREATE TABLE `texts` (
  `id` int(10) NOT NULL,
  `sender_number` int(10) DEFAULT NULL,
  `recipient_number` int(10) DEFAULT NULL,
  `sender` varchar(24) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `turfs`
--

CREATE TABLE `turfs` (
  `id` tinyint(2) DEFAULT NULL,
  `name` varchar(32) DEFAULT NULL,
  `capturedby` varchar(24) DEFAULT 'No-one',
  `capturedgang` tinyint(2) DEFAULT '-1',
  `type` tinyint(2) DEFAULT '0',
  `time` tinyint(2) DEFAULT '12',
  `min_x` float DEFAULT '0',
  `min_y` float DEFAULT '0',
  `max_x` float DEFAULT '0',
  `max_y` float DEFAULT '0',
  `height` float DEFAULT '0',
  `count` int(4) NOT NULL DEFAULT '3'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `turfs`
--

INSERT INTO `turfs` (`id`, `name`, `capturedby`, `capturedgang`, `type`, `time`, `min_x`, `min_y`, `max_x`, `max_y`, `height`, `count`) VALUES
(0, 'MAFIA', 'No-one', 7, 1, 0, -2273.46, 2298.45, -2273.46, 2298.45, 4.82, 3),
(1, 'crips', 'No-one', 3, 0, 0, 2131.24, -1829.99, 2194.74, -1763.97, 18.867, 3),
(2, 'GROVE', 'No-one', 0, 0, 0, 2461.6, -1723.94, 2542.02, -1628.07, 17.976, 3),
(3, 'grove', 'No-one', 1, 0, 0, 2745.06, -1649.28, 2832.91, -1588.73, 14.372, 0),
(4, 'bikers ', 'No-one', 4, 0, 0, 1908.82, -2101.38, 1952.03, -2059.49, 13.547, 3);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `uid` int(10) NOT NULL,
  `username` varchar(24) DEFAULT NULL,
  `password` varchar(129) DEFAULT NULL,
  `regdate` datetime DEFAULT NULL,
  `lastlogin` datetime DEFAULT NULL,
  `ip` varchar(16) DEFAULT NULL,
  `setup` tinyint(1) DEFAULT '1',
  `gender` tinyint(1) DEFAULT '1',
  `age` tinyint(3) DEFAULT '18',
  `skin` smallint(3) DEFAULT '299',
  `camera_x` float DEFAULT '0',
  `camera_y` float DEFAULT '0',
  `camera_z` float DEFAULT '0',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `interior` tinyint(2) DEFAULT '0',
  `world` int(10) DEFAULT '0',
  `cash` int(10) DEFAULT '15000',
  `bank` int(10) DEFAULT '0',
  `paycheck` int(10) DEFAULT '0',
  `level` int(10) DEFAULT '1',
  `exp` int(10) DEFAULT '0',
  `minutes` smallint(3) DEFAULT '0',
  `hours` int(10) DEFAULT '2',
  `adminlevel` int(10) DEFAULT '0',
  `adminname` varchar(24) DEFAULT 'None',
  `helperlevel` tinyint(2) DEFAULT '0',
  `health` float DEFAULT '100',
  `armor` float DEFAULT '0',
  `upgradepoints` int(10) DEFAULT '0',
  `warnings` tinyint(3) DEFAULT '0',
  `injured` tinyint(1) DEFAULT '0',
  `hospital` tinyint(1) DEFAULT '0',
  `spawnhealth` float DEFAULT '50',
  `spawnarmor` float DEFAULT '0',
  `jailtype` tinyint(1) DEFAULT '0',
  `jailtime` int(10) DEFAULT '0',
  `newbiemuted` tinyint(1) DEFAULT '0',
  `helpmuted` tinyint(1) DEFAULT '0',
  `admuted` tinyint(1) DEFAULT '0',
  `livemuted` tinyint(1) DEFAULT '0',
  `globalmuted` tinyint(1) DEFAULT '0',
  `reportmuted` tinyint(2) DEFAULT '0',
  `reportwarns` tinyint(2) DEFAULT '0',
  `fightstyle` tinyint(2) DEFAULT '4',
  `locked` tinyint(1) DEFAULT '0',
  `accent` varchar(16) DEFAULT 'None',
  `cookies` int(10) DEFAULT '0',
  `phone` int(10) DEFAULT '0',
  `job` int(10) DEFAULT '-1',
  `secondjob` tinyint(2) DEFAULT '-1',
  `crimes` int(10) DEFAULT '0',
  `arrested` int(10) DEFAULT '0',
  `wantedlevel` tinyint(2) DEFAULT '0',
  `materials` int(10) DEFAULT '0',
  `pot` int(10) DEFAULT '0',
  `crack` int(10) DEFAULT '0',
  `meth` int(10) DEFAULT '0',
  `painkillers` int(10) DEFAULT '0',
  `seeds` int(10) DEFAULT '0',
  `ephedrine` int(10) DEFAULT '0',
  `muriaticacid` int(10) DEFAULT '0',
  `bakingsoda` int(10) DEFAULT '0',
  `cigars` int(10) DEFAULT '0',
  `weaponclip` int(10) DEFAULT '0',
  `walkietalkie` tinyint(1) DEFAULT '0',
  `channel` int(10) DEFAULT '0',
  `rentinghouse` int(10) DEFAULT '0',
  `spraycans` int(10) DEFAULT '0',
  `boombox` tinyint(1) DEFAULT '0',
  `mp3player` tinyint(1) DEFAULT '0',
  `phonebook` tinyint(1) DEFAULT '0',
  `fishingrod` tinyint(1) DEFAULT '0',
  `fishingbait` int(10) DEFAULT '0',
  `fishweight` int(10) DEFAULT '0',
  `components` int(10) DEFAULT '0',
  `courierskill` int(10) DEFAULT '0',
  `fishingskill` int(10) DEFAULT '0',
  `guardskill` int(10) DEFAULT '0',
  `weaponskill` int(10) DEFAULT '0',
  `mechanicskill` int(10) DEFAULT '0',
  `lawyerskill` int(10) DEFAULT '0',
  `smugglerskill` int(10) DEFAULT '0',
  `toggletextdraws` tinyint(1) DEFAULT '0',
  `toggleooc` tinyint(1) DEFAULT '0',
  `togglephone` tinyint(1) DEFAULT '0',
  `toggleadmin` tinyint(1) DEFAULT '0',
  `togglehelper` tinyint(1) DEFAULT '0',
  `togglenewbie` tinyint(1) DEFAULT '0',
  `togglewt` tinyint(1) DEFAULT '0',
  `toggleradio` tinyint(1) DEFAULT '0',
  `togglevip` tinyint(1) DEFAULT '0',
  `togglemusic` tinyint(1) DEFAULT '0',
  `togglefaction` tinyint(1) DEFAULT '0',
  `togglegang` tinyint(1) DEFAULT '0',
  `togglenews` tinyint(1) DEFAULT '0',
  `toggleglobal` tinyint(1) DEFAULT '0',
  `togglecam` tinyint(1) DEFAULT '0',
  `carlicense` tinyint(1) DEFAULT '0',
  `vippackage` tinyint(2) NOT NULL DEFAULT '0',
  `viptime` int(10) DEFAULT '0',
  `vipcooldown` int(10) DEFAULT '0',
  `weapon_0` tinyint(2) DEFAULT '0',
  `weapon_1` tinyint(2) DEFAULT '0',
  `weapon_2` tinyint(2) DEFAULT '0',
  `weapon_3` tinyint(2) DEFAULT '0',
  `weapon_4` tinyint(2) DEFAULT '0',
  `weapon_5` tinyint(2) DEFAULT '0',
  `weapon_6` tinyint(2) DEFAULT '0',
  `weapon_7` tinyint(2) DEFAULT '0',
  `weapon_8` tinyint(2) DEFAULT '0',
  `weapon_9` tinyint(2) DEFAULT '0',
  `weapon_10` tinyint(2) DEFAULT '0',
  `weapon_11` tinyint(2) DEFAULT '0',
  `weapon_12` tinyint(2) DEFAULT '0',
  `ammo_0` smallint(5) DEFAULT '0',
  `ammo_1` smallint(5) DEFAULT '0',
  `ammo_2` smallint(5) DEFAULT '0',
  `ammo_3` smallint(5) DEFAULT '0',
  `ammo_4` smallint(5) DEFAULT '0',
  `ammo_5` smallint(5) DEFAULT '0',
  `ammo_6` smallint(5) DEFAULT '0',
  `ammo_7` smallint(5) DEFAULT '0',
  `ammo_8` smallint(5) DEFAULT '0',
  `ammo_9` smallint(5) DEFAULT '0',
  `ammo_10` smallint(5) DEFAULT '0',
  `ammo_11` smallint(5) DEFAULT '0',
  `ammo_12` smallint(5) DEFAULT '0',
  `faction` tinyint(2) DEFAULT '-1',
  `gang` tinyint(2) DEFAULT '-1',
  `factionrank` tinyint(2) DEFAULT '0',
  `gangrank` tinyint(2) DEFAULT '0',
  `division` tinyint(2) DEFAULT '-1',
  `contracted` int(10) DEFAULT '0',
  `contractby` varchar(24) DEFAULT 'Nobody',
  `bombs` int(10) DEFAULT '0',
  `completedhits` int(10) DEFAULT '0',
  `failedhits` int(10) DEFAULT '0',
  `reports` int(10) DEFAULT '0',
  `helprequests` int(10) DEFAULT '0',
  `speedometer` tinyint(1) DEFAULT '1',
  `factionmod` tinyint(1) DEFAULT '0',
  `gangmod` tinyint(1) DEFAULT '0',
  `banappealer` tinyint(1) DEFAULT '0',
  `potplanted` tinyint(1) DEFAULT '0',
  `pottime` int(10) DEFAULT '0',
  `potgrams` int(10) DEFAULT '0',
  `pot_x` float DEFAULT '0',
  `pot_y` float DEFAULT '0',
  `pot_z` float DEFAULT '0',
  `pot_a` float DEFAULT '0',
  `inventoryupgrade` int(10) DEFAULT '0',
  `addictupgrade` int(10) DEFAULT '0',
  `traderupgrade` int(10) DEFAULT '0',
  `assetupgrade` int(10) DEFAULT '0',
  `laborupgrade` int(11) NOT NULL DEFAULT '0',
  `pistolammo` smallint(5) DEFAULT '0',
  `shotgunammo` smallint(5) DEFAULT '0',
  `smgammo` smallint(5) DEFAULT '0',
  `arammo` smallint(5) DEFAULT '0',
  `rifleammo` smallint(5) DEFAULT '0',
  `hpammo` smallint(5) DEFAULT '0',
  `poisonammo` smallint(5) DEFAULT '0',
  `fmjammo` smallint(5) DEFAULT '0',
  `ammotype` tinyint(2) DEFAULT '0',
  `ammoweapon` tinyint(2) DEFAULT '0',
  `dmwarnings` tinyint(2) DEFAULT '0',
  `weaponrestricted` int(10) DEFAULT '0',
  `referral_uid` int(10) DEFAULT '0',
  `refercount` int(10) DEFAULT '0',
  `watch` tinyint(1) DEFAULT '0',
  `gps` tinyint(1) DEFAULT '0',
  `prisonedby` varchar(24) DEFAULT 'No-one',
  `prisonreason` varchar(128) DEFAULT 'None',
  `togglehud` tinyint(1) DEFAULT '1',
  `clothes` smallint(3) DEFAULT '-1',
  `showturfs` tinyint(1) DEFAULT '1',
  `showlands` tinyint(1) DEFAULT '0',
  `watchon` tinyint(1) DEFAULT '0',
  `gpson` tinyint(1) DEFAULT '0',
  `doublexp` int(10) DEFAULT '0',
  `login_date` datetime DEFAULT NULL,
  `chatstyle` int(10) DEFAULT '0',
  `truckingxp` int(10) DEFAULT '0',
  `truckinglevel` int(10) DEFAULT '0',
  `vehiclecmd` int(10) DEFAULT '0',
  `adminstrike` int(10) DEFAULT '0',
  `dj` int(10) DEFAULT '0',
  `housealarm` int(10) DEFAULT '0',
  `vehlock` int(10) DEFAULT '0',
  `crowbar` int(10) DEFAULT '0',
  `graphic` int(10) DEFAULT '0',
  `helmet` int(10) DEFAULT '0',
  `togglevehicle` int(10) DEFAULT '0',
  `glassitem` int(10) DEFAULT '0',
  `metalitem` int(10) DEFAULT '0',
  `rubberitem` int(10) DEFAULT '0',
  `ironitem` int(10) DEFAULT '0',
  `plasticitem` int(10) DEFAULT '0',
  `u_accessories` varchar(68) CHARACTER SET utf8 NOT NULL DEFAULT '0|0|0|0|0|0|0|0',
  `u_accessories_used` varchar(68) CHARACTER SET utf8 NOT NULL DEFAULT '0|0|0|0|0|0|0|0',
  `weed` int(10) DEFAULT '0',
  `cocaine` int(10) DEFAULT '0',
  `thiefskill` int(10) DEFAULT '0',
  `togglepoints` int(10) DEFAULT '0',
  `toggleturfs` int(10) DEFAULT '1',
  `togglepm` int(10) DEFAULT '0',
  `togglereports` int(10) DEFAULT '0',
  `togglewhisper` int(10) DEFAULT '0',
  `togglebug` int(10) DEFAULT '0',
  `spawntype` int(10) DEFAULT '0',
  `spawnhouse` int(10) DEFAULT '0',
  `factionleader` int(10) DEFAULT '0',
  `crew` int(10) DEFAULT '0',
  `webdev` int(10) DEFAULT '0',
  `scripter` int(10) DEFAULT '0',
  `helpermanager` int(10) DEFAULT '0',
  `dynamicadmin` int(10) DEFAULT '0',
  `adminpersonnel` int(10) DEFAULT '0',
  `humanresources` int(10) DEFAULT '0',
  `complaintmod` int(10) DEFAULT '0',
  `weedplanted` int(10) DEFAULT '0',
  `weedtime` int(10) DEFAULT '0',
  `weedgrams` int(10) DEFAULT '0',
  `weed_x` float DEFAULT '0',
  `weed_y` float DEFAULT '0',
  `weed_z` float DEFAULT '0',
  `weed_a` float DEFAULT '0',
  `thiefcooldown` int(10) DEFAULT '0',
  `crackcooldown` int(10) DEFAULT '0',
  `newbiemutetime` int(10) DEFAULT '0',
  `reportmutetime` int(10) DEFAULT '0',
  `globalmutetime` int(10) DEFAULT '0',
  `adminhide` int(10) DEFAULT '0',
  `firstaid` int(10) DEFAULT '0',
  `policescanner` int(10) DEFAULT '0',
  `bodykits` int(10) DEFAULT '0',
  `rimkits` int(10) DEFAULT '0',
  `scanneron` int(10) DEFAULT '0',
  `cookfood` int(10) DEFAULT '0',
  `landkeys` int(10) DEFAULT '0',
  `bugged` int(10) DEFAULT '0',
  `rollerskates` int(10) DEFAULT '0',
  `couriercooldown` int(10) DEFAULT '0',
  `pizzacooldown` int(10) DEFAULT '0',
  `detectivecooldown` int(10) DEFAULT '0',
  `duty` int(10) DEFAULT '0',
  `bandana` int(10) NOT NULL DEFAULT '0',
  `detectiveskill` int(11) DEFAULT '0',
  `gascan` int(11) DEFAULT '0',
  `refunded` int(11) DEFAULT '0',
  `backpack` int(11) DEFAULT '0',
  `bpcash` int(11) DEFAULT '0',
  `bpmaterials` int(11) DEFAULT '0',
  `bppot` int(11) DEFAULT '0',
  `bpcrack` int(11) DEFAULT '0',
  `bpmeth` int(11) DEFAULT '0',
  `bppainkillers` int(11) DEFAULT '0',
  `bpweapon_0` int(11) DEFAULT '0',
  `bpweapon_1` int(11) DEFAULT '0',
  `bpweapon_2` int(11) DEFAULT '0',
  `bpweapon_3` int(11) DEFAULT '0',
  `bpweapon_4` int(11) DEFAULT '0',
  `bpweapon_5` int(11) DEFAULT '0',
  `bpweapon_6` int(11) DEFAULT '0',
  `bpweapon_7` int(11) DEFAULT '0',
  `bpweapon_8` int(11) DEFAULT '0',
  `bpweapon_9` int(11) DEFAULT '0',
  `bpweapon_10` int(11) DEFAULT '0',
  `bpweapon_11` int(11) DEFAULT '0',
  `bpweapon_12` int(11) DEFAULT '0',
  `bpweapon_13` int(11) DEFAULT '0',
  `bpweapon_14` int(11) DEFAULT '0',
  `bphpammo` int(11) DEFAULT '0',
  `bppoisonammo` int(11) DEFAULT '0',
  `bpfmjammo` int(11) DEFAULT '0',
  `formeradmin` int(2) NOT NULL DEFAULT '0',
  `deathcooldown` int(10) NOT NULL DEFAULT '0',
  `hunger` int(10) DEFAULT '100',
  `hungertimer` int(10) NOT NULL DEFAULT '0',
  `thirst` int(11) NOT NULL DEFAULT '100',
  `thirsttimer` int(11) NOT NULL DEFAULT '0',
  `covid` int(10) NOT NULL DEFAULT '100',
  `covidtimer` int(10) NOT NULL DEFAULT '0',
  `totalpatients` int(10) NOT NULL DEFAULT '0',
  `totalfires` int(10) NOT NULL DEFAULT '0',
  `rarecooldown` int(10) NOT NULL DEFAULT '0',
  `vipdlcooldown` int(11) NOT NULL DEFAULT '0',
  `customtitle` varchar(64) NOT NULL DEFAULT '0',
  `customcolor` varchar(16) NOT NULL DEFAULT '0',
  `mask` int(10) NOT NULL DEFAULT '0',
  `diamonds` int(11) NOT NULL DEFAULT '0',
  `ecoin` int(11) NOT NULL DEFAULT '0',
  `blindfold` int(10) NOT NULL DEFAULT '0',
  `rope` int(10) NOT NULL DEFAULT '0',
  `lockpick` int(10) NOT NULL DEFAULT '0',
  `repairkit` int(10) NOT NULL DEFAULT '0',
  `goldrim` int(11) NOT NULL DEFAULT '0',
  `food` int(10) NOT NULL DEFAULT '0',
  `drink` int(10) NOT NULL DEFAULT '0',
  `bandage` int(10) NOT NULL DEFAULT '0',
  `medkit` int(10) NOT NULL DEFAULT '0',
  `nationalid` int(10) NOT NULL DEFAULT '0',
  `diploma` int(11) NOT NULL DEFAULT '0',
  `insurance` int(10) NOT NULL DEFAULT '0',
  `passport` int(10) NOT NULL DEFAULT '0',
  `passportname` varchar(64) DEFAULT NULL,
  `passportlevel` int(10) NOT NULL DEFAULT '0',
  `passportskin` int(10) NOT NULL DEFAULT '0',
  `passportphone` int(10) NOT NULL DEFAULT '0',
  `marriedto` int(10) NOT NULL DEFAULT '-1',
  `newbies` int(10) NOT NULL DEFAULT '0',
  `chatanim` tinyint(2) NOT NULL DEFAULT '0',
  `Lottery` int(11) NOT NULL DEFAULT '0',
  `LotteryB` int(11) NOT NULL DEFAULT '0',
  `flashlight` tinyint(2) NOT NULL DEFAULT '0',
  `candy` int(11) NOT NULL DEFAULT '0',
  `gunlicense` tinyint(2) NOT NULL DEFAULT '0',
  `gunlicensetime` int(10) DEFAULT '1290000',
  `dirtycash` int(11) NOT NULL DEFAULT '0',
  `comserv` int(11) NOT NULL DEFAULT '0',
  `voicechat` int(11) DEFAULT NULL,
  `discordtag` text,
  `discordname` text,
  `money_earned` int(11) NOT NULL DEFAULT '0',
  `money_spent` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`uid`, `username`, `password`, `regdate`, `lastlogin`, `ip`, `setup`, `gender`, `age`, `skin`, `camera_x`, `camera_y`, `camera_z`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `interior`, `world`, `cash`, `bank`, `paycheck`, `level`, `exp`, `minutes`, `hours`, `adminlevel`, `adminname`, `helperlevel`, `health`, `armor`, `upgradepoints`, `warnings`, `injured`, `hospital`, `spawnhealth`, `spawnarmor`, `jailtype`, `jailtime`, `newbiemuted`, `helpmuted`, `admuted`, `livemuted`, `globalmuted`, `reportmuted`, `reportwarns`, `fightstyle`, `locked`, `accent`, `cookies`, `phone`, `job`, `secondjob`, `crimes`, `arrested`, `wantedlevel`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `seeds`, `ephedrine`, `muriaticacid`, `bakingsoda`, `cigars`, `weaponclip`, `walkietalkie`, `channel`, `rentinghouse`, `spraycans`, `boombox`, `mp3player`, `phonebook`, `fishingrod`, `fishingbait`, `fishweight`, `components`, `courierskill`, `fishingskill`, `guardskill`, `weaponskill`, `mechanicskill`, `lawyerskill`, `smugglerskill`, `toggletextdraws`, `toggleooc`, `togglephone`, `toggleadmin`, `togglehelper`, `togglenewbie`, `togglewt`, `toggleradio`, `togglevip`, `togglemusic`, `togglefaction`, `togglegang`, `togglenews`, `toggleglobal`, `togglecam`, `carlicense`, `vippackage`, `viptime`, `vipcooldown`, `weapon_0`, `weapon_1`, `weapon_2`, `weapon_3`, `weapon_4`, `weapon_5`, `weapon_6`, `weapon_7`, `weapon_8`, `weapon_9`, `weapon_10`, `weapon_11`, `weapon_12`, `ammo_0`, `ammo_1`, `ammo_2`, `ammo_3`, `ammo_4`, `ammo_5`, `ammo_6`, `ammo_7`, `ammo_8`, `ammo_9`, `ammo_10`, `ammo_11`, `ammo_12`, `faction`, `gang`, `factionrank`, `gangrank`, `division`, `contracted`, `contractby`, `bombs`, `completedhits`, `failedhits`, `reports`, `helprequests`, `speedometer`, `factionmod`, `gangmod`, `banappealer`, `potplanted`, `pottime`, `potgrams`, `pot_x`, `pot_y`, `pot_z`, `pot_a`, `inventoryupgrade`, `addictupgrade`, `traderupgrade`, `assetupgrade`, `laborupgrade`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `ammotype`, `ammoweapon`, `dmwarnings`, `weaponrestricted`, `referral_uid`, `refercount`, `watch`, `gps`, `prisonedby`, `prisonreason`, `togglehud`, `clothes`, `showturfs`, `showlands`, `watchon`, `gpson`, `doublexp`, `login_date`, `chatstyle`, `truckingxp`, `truckinglevel`, `vehiclecmd`, `adminstrike`, `dj`, `housealarm`, `vehlock`, `crowbar`, `graphic`, `helmet`, `togglevehicle`, `glassitem`, `metalitem`, `rubberitem`, `ironitem`, `plasticitem`, `u_accessories`, `u_accessories_used`, `weed`, `cocaine`, `thiefskill`, `togglepoints`, `toggleturfs`, `togglepm`, `togglereports`, `togglewhisper`, `togglebug`, `spawntype`, `spawnhouse`, `factionleader`, `crew`, `webdev`, `scripter`, `helpermanager`, `dynamicadmin`, `adminpersonnel`, `humanresources`, `complaintmod`, `weedplanted`, `weedtime`, `weedgrams`, `weed_x`, `weed_y`, `weed_z`, `weed_a`, `thiefcooldown`, `crackcooldown`, `newbiemutetime`, `reportmutetime`, `globalmutetime`, `adminhide`, `firstaid`, `policescanner`, `bodykits`, `rimkits`, `scanneron`, `cookfood`, `landkeys`, `bugged`, `rollerskates`, `couriercooldown`, `pizzacooldown`, `detectivecooldown`, `duty`, `bandana`, `detectiveskill`, `gascan`, `refunded`, `backpack`, `bpcash`, `bpmaterials`, `bppot`, `bpcrack`, `bpmeth`, `bppainkillers`, `bpweapon_0`, `bpweapon_1`, `bpweapon_2`, `bpweapon_3`, `bpweapon_4`, `bpweapon_5`, `bpweapon_6`, `bpweapon_7`, `bpweapon_8`, `bpweapon_9`, `bpweapon_10`, `bpweapon_11`, `bpweapon_12`, `bpweapon_13`, `bpweapon_14`, `bphpammo`, `bppoisonammo`, `bpfmjammo`, `formeradmin`, `deathcooldown`, `hunger`, `hungertimer`, `thirst`, `thirsttimer`, `covid`, `covidtimer`, `totalpatients`, `totalfires`, `rarecooldown`, `vipdlcooldown`, `customtitle`, `customcolor`, `mask`, `diamonds`, `ecoin`, `blindfold`, `rope`, `lockpick`, `repairkit`, `goldrim`, `food`, `drink`, `bandage`, `medkit`, `nationalid`, `diploma`, `insurance`, `passport`, `passportname`, `passportlevel`, `passportskin`, `passportphone`, `marriedto`, `newbies`, `chatanim`, `Lottery`, `LotteryB`, `flashlight`, `candy`, `gunlicense`, `gunlicensetime`, `dirtycash`, `comserv`, `voicechat`, `discordtag`, `discordname`, `money_earned`, `money_spent`) VALUES
(1, 'psiko_boukhris', 'EEDBF8005462C11BC81A3647CD487F956B73C3CDEE92C31271E54920970AD79A8DEDF39C02F91614DAC10759940D5B103C8756A5E89E1F589001D1F24003F1D8', '2023-03-19 19:42:59', '2023-03-27 19:52:42', '105.155.158.194', 0, 1, 20, 121, 1038.26, -1338.12, 15.5, 1038.13, -1340.43, 13.734, 183.632, 0, 0, 1399195692, 4016846, 0, 4, 26, 39, 29, 8, 'None', 0, 72, 0, 6, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 'None', 65, 892648, 12, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 10, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'Server', 'failing to change their name', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '19624|19033|18911|18926|19554|3026|0|0', '1|1|1|1|1|1|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 118, 95, 108, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 2, 2, 0, 0, 0, 747, 32, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1426537656, 27311964),
(2, 'Unknown_', 'FBA8B22B1243A13FD85BF61C8E370396EFD96FC8ADCCC8E1A1A2F06AB84A3526E8CB1EEB259CCB9FFE8129DD87E9FEDE590386C76575DC249A88CC4581A86BC6', '2023-03-19 19:43:59', '2023-03-19 19:46:24', '41.250.74.241', 0, 1, 22, 0, 1097.91, 1598.65, 36.769, 1099.55, 1601.5, 32.343, 330.039, 0, 0, 15000, 0, 0, 1, 0, 9, 2, 13, 'None', 0, 125, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 43, 96, 103, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(3, 'UTCHIHA_PABLO', '39751730E9B88DB85155E39B07C8C692421E6B0D22A1A451BCFF4F13AE869613BF2FBBD28A2165E63DCFAB1B52E9A990F0A8DD57E07589699B85CEE5D4FD0DE7', '2023-03-19 19:44:15', '2023-03-27 11:16:23', '105.69.90.185', 0, 1, 23, 79, 2183.04, -1744.65, 15.817, 2172.37, -1746.14, 13.214, 180.632, 0, 0, 9441, 460, 0, 1, 4, 90, 4, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 866637, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 1, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 15, 44, 23, 42, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 48, 44, 47, 44, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 2, 8, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 97391, 102950),
(4, 'Pablo_Walid', '4583DE9168CEC8D13E683D7D43422B297F8BBE2E888E72DD480EDBB430A5F6B2793F167C56346CE88D9C05E5A4F3DC26308F09DB8D6278B14CE96DE006998AFC', '2023-03-19 19:45:40', '2023-03-27 17:36:46', '105.67.6.16', 0, 1, 16, 121, 1757.8, -1944.34, 15.114, 1755.93, -1947.12, 13.557, 124.558, 0, 0, 1324550, 5770, 0, 1, 23, 8, 14, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 50, 297911, 18, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, 0, 5, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 286, 152, 391, 195, 355, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 94, 151, 90, 38, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 47, 11, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 2223665, 914115),
(5, 'yasser_elallawi', '15DB524443DD1D939CFCFB203685BD1D03FFCFAFC16A3BA31832CB50C657C2770DB31BDE79411F714F294D2DEEB362344CC6CBDBE9A5E3D0E63FDC814723178A', '2023-03-19 19:46:28', '2023-03-23 23:07:49', '41.251.64.150', 0, 1, 24, 292, 1277.44, -1252.49, 15.086, 1277.24, -1251.07, 14.26, 26.2, 0, 0, 276519, 16180, 0, 1, 10, 44, 7, 0, 'None', 0, 91, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 443430, 5, -1, 0, 0, 0, 250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 49, 0, 7, 0, 30, '18912|19624|19033|18967|0|0|0|0', '1|1|1|1|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 36, 38, 36, 100, 0, 0, 0, 1585, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 4, 2, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 374621, 113102),
(6, 'PABLO_PICASO', '3E403CF5693F867E2EA574E9EE45777F2F54C979C44A6505B704E11FCF4F9AA31B57F65643F8A75626FAE3F89C10C36667EE50C75A86AE64F6BDE37AD76B12D0', '2023-03-19 19:46:29', '2023-03-26 12:47:41', '105.158.148.176', 0, 1, 22, 137, 2080.18, 1224.8, 1020.85, 2080.58, 1226, 1019.08, 331.806, 1, 1, -111, 230, 0, 1, 2, 34, 3, 0, 'None', 0, 125, 100, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 956357, -1, -1, 0, 0, 0, 500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0, 211, 0, 0, 22, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 0, 5, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 172, 70, 210, 102, 208, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 71, 99, 56, 39, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 7889, 23000),
(7, 'Vini_Edrian', '2AD9E29BC6A37800C6E2C93C417A21A7E5AF97D04D66BCA616F5A10C231BE18DE5DFEBB4A9D5750DFFCDC546AEB205049A12C4CBFCF3C9CAB6965EE542BD80B3', '2023-03-19 19:50:17', '2023-03-21 18:27:45', '196.75.226.104', 0, 1, 89, -1, 2262.7, -1139, 1050.88, 2264.53, -1136.96, 1050.63, 118.483, 10, 0, 1014694, 113517, 0, 1, 10, 7, 7, 10, 'None', 0, 96, 97, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 'None', 50, 0, 18, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 1705191252, 0, 0, 4, 0, 26, 28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, -1, 5, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 11, 22, 12, 18, '18968|19011|18955|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 89, 5, 89, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 5150001, 4150307),
(8, 'X_Mafiat', '90C086088483CEF266D771E4FC049C2CE6C8DDA007DB88815454AE8A462F88A11BAA2990A3C6501A9720736D905B9CB1425E2A266B589CA8786AD1247374DB79', '2023-03-19 19:51:13', '2023-03-26 02:07:41', '105.66.135.202', 0, 1, 19, 123, 1536.75, -1684.71, 14.785, 1533.82, -1682.99, 13.383, 48.789, 0, 0, 1569035, 42508, 0, 1, 22, 4, 16, 13, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 'None', 50, 953749, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, -1, 5, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 3, 0, 0, 0, 1, 'X_Mafia', 'DM', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '18911|19624|0|0|0|0|0|0', '1|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 3, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 1, 46, 61, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 2, 0, 0, 0, 0, 6, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1539341598, 1537787563),
(9, 'STEVAW_MARTINEZ', '1B49D5EDDE289800D4B441C73D672B93A73BC9645DA8CD4A1BF67E295D497909FACAE8CFF7F9CFC4953949488C3C26B197680118E98275007B0B01DB23058413', '2023-03-19 19:52:26', '2023-03-24 07:05:16', '197.145.186.129', 0, 1, 18, 2, -2375.82, 13.699, 37.012, -2373.15, 15.15, 35.164, 119.013, 1, 0, 201852, -5250, 0, 1, 8, 25, 6, 0, 'None', 0, 125, 100, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 'None', 0, 496996, 6, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 1, 0, 0, 20, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 83, 0, 8, 0, 40, '19422|18916|19519|19028|3026|19554|19319|0', '1|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 66, 27, 59, 71, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 2, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 851669, 664817),
(10, 'Chliha_Olmhjob', '9CC1192336ABAD9E70AF6BEDAA7689354EC4A91E87E31A77143B7CDFF70A7FA1847E71E8A35442EB75AC4E3BE3B517AB852C038BC7A3837C6B60399797C851DA', '2023-03-19 19:52:55', '2023-03-19 20:12:02', '160.177.176.33', 0, 1, 23, 71, 1311.48, -1702.96, 16.336, 1320.32, -1704.32, 13.22, 188.27, 0, 0, 13300, 0, 0, 1, 0, 16, 2, 0, 'None', 0, 125, 100, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 288076, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, 136, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 120, 92, 60, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 1700),
(11, 'GOD_TIPO', '48A8011BF415073C2BB20569DBBDD7AAE36A2C7290DF6E95C59655CF609EDE94629405C32AC83F2C3731FA7BFB0A346CF2E23C38227E2ECE6817301C395C4093', '2023-03-19 19:54:56', '2023-03-27 16:56:06', '105.67.6.245', 0, 1, 35, 303, 1578.49, -1634.73, 14.434, 1579.29, -1634.13, 13.555, 352.453, 0, 0, 551952, 235004320, 0, 4, 10, 2, 97, 10, 'None', 0, 100, 0, 6, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 1410065457, 413159, 12, 14, 1, 0, 1, 999992999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1701282974, 0, 0, 0, 24, 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 17, 0, -1, 0, 'Nobody', 99981999, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 115, 52, 147, 68, 156, '18947|18914|18918|19624|0|19016|0|0', '1|0|0|1|0|1|0|0', 0, 999999999, 999999, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 31, 63, 21, 3, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 2, 0, 0, 0, 0, 2, 3, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 239965433, 4383481),
(12, 'abdollah_algnawi', '4A754F08A599A137F3259F6540C7D0E4BBECF64B85099E95A2940D4E749DF8282E666618EE78CED2D21242ECCBBA64232C12B7D02F8AAC5F8AB8C42146AB5632', '2023-03-19 20:00:29', '2023-03-23 22:30:40', '196.112.163.63', 0, 1, 50, 266, 1550.07, -1612.3, 12.906, 1548.96, -1611.15, 13.383, 168.973, 0, 0, 14670, 240932, 0, 1, 12, 14, 8, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 112, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, 230, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 23, 34, 83, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 194291, 194621),
(13, 'NMS_FLIX', '9A3B6779F0D3DB3D63B78B7D829C433AA369B3BE31B254CA85ABE7971BAF52D2C08E83C46B2DFD712B482676882A001083653E1F87D5BD0D43D113DEA888B559', '2023-03-19 20:02:33', '2023-03-21 19:50:25', '196.217.47.239', 0, 1, 25, 59, 1398.09, -686.3, 89.266, 1400.7, -688.223, 88.164, 129.262, 0, 0, 14850, 0, 0, 1, 0, 25, 2, 6, 'None', 0, 86, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 80, 0, 70, 0, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 150),
(14, 'AYMEN_LME3DAWI', '3F42CB651A6AEE67697C6478700B9498B86392B7C06F320318EA347C026133ABB6A3AAE92ED8B836D4795BB41E7ADE6D6A0A87CA5F30060BCCBA73CC92256C92', '2023-03-19 20:04:15', '2023-03-23 13:42:56', '196.118.12.190', 0, 1, 24, 249, 2784.45, -1604.21, 11.087, 2784.04, -1607.64, 10.922, 260.03, 0, 0, 14850, 3230, 0, 1, 2, 17, 3, 0, 'None', 0, 80, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 67, 4, 51, 64, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 150),
(15, 'MOUAD_PABLO', 'B925F44A0CF9DE473E7CB0DC2BAA85A7D61EF0CDD56FFF6A7597A0C570537FF0518A712F2C045F58423E7DE0AC33D9C1A8292FE41F10469FA3071BFCC6B9C233', '2023-03-19 20:06:22', '2023-03-19 20:49:02', '197.247.26.204', 0, 1, 24, 137, -62.149, -1053.18, 20.871, -60.269, -1057.68, 16.89, 189.859, 0, 0, 5494, 30260, 0, 1, 2, 13, 3, 0, 'None', 0, 93, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 941359, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 1, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 116, 61, 177, 90, 166, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 81, 7, 72, 67, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 22294, 31800),
(16, 'James_Edrian', 'CE146B2076C64A5821DA458C668F48A6B1C286C0CD3E8EB72832C2D5E56A2729148A15ABC591635400C0E90DF4A33D8699F72448195BE2657B311B5CC10266EC', '2023-03-19 20:13:37', '2023-03-20 22:13:33', '197.253.251.82', 0, 1, 30, 70, 1194.53, -1328.96, 14.454, 1193.13, -1330.13, 13.398, 178.215, 0, 0, 222324, 147213, 0, 1, 2, 46, 3, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 'None', 0, 839198, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -1, 5, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, 230, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 0, '18968|18909|19424|19274|19032|19624|19031|0', '1|0|1|0|1|1|1|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 112, 50, 112, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1014000, 806676),
(17, 'JAIMSE_PALACIO', '367006E67F68F9BFFC5333918EA2A732D24623835F3D7198A71F9C8349F9027032DB2C81DB2C0CDCD14B702DF9AD244CE7A030130FF91369E52245F33A8C138F', '2023-03-19 20:23:51', '2023-03-22 15:39:01', '196.95.109.166', 0, 1, 27, 126, 1361.48, -1751.12, 17.405, 1361.51, -1751.41, 13.525, 180.152, 0, 0, 627224, 230, 0, 1, 2, 52, 3, 0, 'None', 0, 120, 25, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 'None', 50, 281031, 7, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 78, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '11704|19624|19554|19028|18919|3026|0|0', '0|1|1|1|1|1|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 92, 19, 89, 93, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 8, 0, 0, 0, 0, 80, 4, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1745183581, 1744571357),
(18, 'Tyson_Choppa', 'FCCA09EE0D98F2C5ED10E70DBEB0204CFAED858E13AA2DBD58CEB88F482B9291F7F313558118B61D11895E146947704B8DA96A62177F0B1B9931268BBEB42D12', '2023-03-19 20:29:20', '2023-03-23 09:06:37', '105.73.96.64', 0, 1, 68, 303, 2294.96, -2222.15, 15.341, 2296.16, -2219.09, 13.547, 356.933, 0, 0, 15000, 0, 0, 1, 0, 35, 2, 0, 'None', 0, 96, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 17, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, 137, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 89, 131, 83, 71, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(19, 'LAMAR_PABLOX', '289C271BD028D182799CFBDED68E3008EC619EE57ACBE1F936A2FE4CB5E49D889A43C4FA1F6C8494B2CEEEE283AA83E97F7F4E7A6333129775D3F9B4DA44FE89', '2023-03-19 20:30:25', '2023-03-22 19:53:59', '105.157.62.110', 0, 1, 69, 106, 2477.84, -1682.44, 12.901, 2475.38, -1680.11, 13.012, 91.245, 0, 0, 14850, 0, 0, 1, 0, 38, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 165, 47, 21, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 150),
(20, 'Mocro_Vincenzo', '06FF011C5EA6B992090B263CC2BA3CC9B56DD4D71452F8B186954AAFACD3F5585DA62874BF9C0BF4DAC0E3FF6A1BEF144333FA1987FFC3E98495820D7BB64C98', '2023-03-19 20:37:18', '2023-03-19 20:37:18', '41.141.239.4', 1, 1, 18, 299, 1320.42, -1480.75, 78.601, 1310.98, -1445.24, -27.278, 1, 0, 0, 15000, 0, 0, 1, 0, 0, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 1, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 25, 100, 25, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(21, 'Aymen_Stunt', 'B5225CBE116B684165C50C40BF2E809044E3CE15F08034E6741E3EB85ADD241CA8290879532DCB439B8F0A00EFE00516BBDEF555B6A940F4924ADF5ADEF9687A', '2023-03-19 20:55:42', '2023-03-20 14:39:24', '134.0.7.74', 0, 1, 23, 276, 2071.43, 1233.31, 1020.08, 2068.77, 1235.35, 1019.08, 229.5, 0, 0, 12500, 0, 0, 1, 0, 29, 2, 0, 'None', 0, 45, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, 100, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5046, 0, 6246, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 2500),
(22, 'Yuri_Mercedes', '75A7338AC189F71DD5BDFC918A25FD224CDF82A93CD14F8507111717E512546A27E216E95CB7A1D865F3C5CBC9E729E98F195198937F798C8A9C2BFF66646EFF', '2023-03-19 21:10:39', '2023-03-19 21:10:39', '41.250.143.212', 0, 1, 27, 79, 1788.61, -1887.03, 14.378, 1791.55, -1888.45, 13.398, 275.158, 0, 0, 15000, 0, 0, 1, 0, 16, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 94, 38, 91, 38, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(23, 'Felix_Jigo', '1993CF5D170FAB49CFFE74D5D9B076EF147ECB883405C7712BB05E4C1DDB8F99A657136C211F1F40AA0CAE409B563994109C98F525DAA9F0187751CF80DA0EB6', '2023-03-19 21:12:21', '2023-03-23 22:35:54', '41.250.8.214', 0, 1, 30, 136, 100.748, -1550.19, 7.467, 99.32, -1554.6, 6.685, 140.588, 0, 0, 155850, 230, 0, 1, 2, 18, 3, 0, 'None', 0, 57, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, -1, 5, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 95, 44, 95, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 160000, 19150),
(24, 'ROCH_PRAN', '55DF4534BFCE08033254A14C3FABCC95BD2FAB096E03A67358A932969A2E557B6439A883F725CD49B22412C7FD63D65555055940A339AD5E23C4F0C88EF5B1FD', '2023-03-19 21:54:24', '2023-03-27 18:22:10', '197.253.221.101', 0, 1, 23, 46, 1773.46, -1087.19, 25.547, 1768.87, -1089.82, 23.961, 63.966, 0, 0, 1660294499, 2306, 0, 1, 15, 31, 12, 10, 'None', 0, 100, 100, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 51, 296381, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 23, 0, 0, 0, 0, 0, 0, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, -1, 5, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 1, 22, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|18916|18908|19011|11704|18906', '0|0|0|1|1|1|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 125, 30, 65, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1661992961, 1713462),
(25, 'Raynez_Partida', '5DDD19634C7CE5886FA6C95206B17C8A97BFB900EC78259103EF1C43EDC00F1ECFB6B97A234287C19E877AF909BB6F5AC6D2D9A76390FFEA00C8C410FFA463C4', '2023-03-19 22:34:55', '2023-03-19 23:09:32', '105.159.54.255', 0, 1, 22, 78, 1542.27, -1681.3, 14.085, 1541.94, -1677.86, 13.554, 44.022, 0, 0, 14415, 0, 0, 1, 0, 25, 2, 0, 'None', 0, 50, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 63, 9, 119, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 585),
(26, 'Marroki_Crazy', '0A0BD9DD4C56480FBDD9061A2A12A91DD457A3C833E7CE942CAC059E32C7E73AE9BEC1D520900D7C190444664C4BFDB00D3AC1C0FF0D8C63E2873F930559CC9D', '2023-03-19 23:22:38', '2023-03-20 01:35:02', '41.141.96.45', 0, 1, 27, 1, 1518.48, -829.717, 70.42, 1547.07, -1675.54, 13.923, 166.892, 0, 0, 12000, 0, 0, 1, 0, 27, 2, 0, 'None', 0, 100, 0, 0, 0, 1, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 144, 19, 24, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 3000),
(27, 'ANAS_RAID', '13F5ED6B84B4694FC7AFBF7EFE72B911D292856122127C09C4545DD01F67639818EAE6C3A4BEB9D04D03F79313365D16883F920BE408EB94E0AD79058E5E341B', '2023-03-19 23:27:50', '2023-03-19 23:57:27', '41.140.45.113', 0, 1, 20, 110, 820.636, -1767.6, 15.237, 822.541, -1763.5, 13.56, 278.141, 0, 0, 3799, 230, 0, 1, 2, 2, 3, 0, 'None', 0, 95, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 68, '18967|18914|3026|19624|18911|0|0|0', '1|1|1|0|1|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 90, 66, 85, 66, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 11201),
(28, 'Dyablo_Dr3awi', '63430683929E8B600B8654F640B421634D14F6DF5AFEC378893389C7BC034C6CF4DD07ACC640E0292005A3F89EBD662B94D9E6A576630DE770B3C9AEBFC85C89', '2023-03-19 23:34:47', '2023-03-27 13:54:37', '196.64.45.30', 0, 1, 60, 294, 1828.72, -1724.55, 13.856, 1824.06, -1723.89, 13.383, 348.146, 0, 0, 2442684, 119377, 0, 2, 26, 30, 18, 10, 'None', 0, 255, 0, 0, 0, 0, 0, 55, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, 13, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Server', 'Logging to avoid arrest', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '18907|19624|18967|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 25, 22, 13, 82, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1624497265, 1622059581),
(29, 'dob_lghaba', '21D5CB651222C347EA1284C0ACF162000B4D3E34766F0D00312E3480F633088822809B6A54BA7EDFA17E8FCB5713F8912EE3A218DD98D88C38BBF611B1B1ED2B', '2023-03-20 04:44:48', '2023-03-20 11:27:35', '160.176.24.218', 0, 1, 55, 127, 2798.54, -1601.17, 11.843, 2792.52, -1609.32, 10.628, 90.849, 0, 0, 100, 204440, 0, 1, 0, 51, 2, 0, 'None', 0, 98, 25, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 317413, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 21, 38, 21, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 240000, 254900),
(30, 'CORLO_NEGRO', '64BAC052DA68F92D2E28A644BF68BD3F2061F883A714A5F598D24023A513B0E75E5C5199261790FF5DDF4F470A7F1D43C509BD6E4B26409BCFF7349FF76DD92B', '2023-03-20 05:32:52', '2023-03-27 12:43:28', '37.161.201.23', 0, 1, 25, 78, 46.087, 6.719, 3.167, 52.132, 6.21, 1.936, 277.486, 0, 0, 1006395979, 1940000, 0, 1, 0, 68, 2, 0, 'None', 0, 48, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 770481, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 178, 7, 58, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1015002979, 8622000),
(31, 'LHAJ_SFIRAA', '899B76161701A4111B36CBADD0D168E896F1E97D22B4F470331293B9D9BCE5FD6A338B64BFD640B8D78EF3A465047886527E1C250D587CA7693F46D27AE8721A', '2023-03-20 11:20:08', '2023-03-20 11:20:08', '5.78.90.216', 0, 1, 20, 134, 1500.65, -1671.13, 14.781, 1502.16, -1668.01, 14.047, 331.419, 0, 0, 14850, 0, 0, 1, 0, 11, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 150, 95, 90, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 150),
(32, 'Oualid_Jackson', 'A89D409FB70630682280A1B805B5B66431F80ABD78398940F85E06DEFC98A6E49198B60B8F44E80F437C0BAF6B05B2DCAA88368C5E93CD531391371F13FE2CE1', '2023-03-20 11:34:46', '2023-03-20 11:34:46', '105.156.242.28', 0, 1, 19, 230, 1778.79, -1898.75, 12.899, 1778.63, -1899.93, 13.386, 345.562, 0, 0, 15000, 0, 0, 1, 0, 3, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 143, 99, 23, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(33, 'COROMBO_PABLO', 'F864C12C0FFFD918BAF046B62BF8719484A88726555F86C5425B06F71AEF779A2DA067AB8EA696F4C10A98C758D0221F14B3D7CC452E3B2500A0AC448B1E776D', '2023-03-20 13:02:31', '2023-03-24 01:44:17', '41.248.177.55', 0, 1, 25, 124, 409.554, -1351.57, 15.752, 407.609, -1354.45, 14.734, 144.855, 0, 0, 113750, 460, 0, 1, 4, 6, 4, 0, 'None', 0, 94, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 749416, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 1, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 65, 89, 24, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 55, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 200000, 101250);
INSERT INTO `users` (`uid`, `username`, `password`, `regdate`, `lastlogin`, `ip`, `setup`, `gender`, `age`, `skin`, `camera_x`, `camera_y`, `camera_z`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `interior`, `world`, `cash`, `bank`, `paycheck`, `level`, `exp`, `minutes`, `hours`, `adminlevel`, `adminname`, `helperlevel`, `health`, `armor`, `upgradepoints`, `warnings`, `injured`, `hospital`, `spawnhealth`, `spawnarmor`, `jailtype`, `jailtime`, `newbiemuted`, `helpmuted`, `admuted`, `livemuted`, `globalmuted`, `reportmuted`, `reportwarns`, `fightstyle`, `locked`, `accent`, `cookies`, `phone`, `job`, `secondjob`, `crimes`, `arrested`, `wantedlevel`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `seeds`, `ephedrine`, `muriaticacid`, `bakingsoda`, `cigars`, `weaponclip`, `walkietalkie`, `channel`, `rentinghouse`, `spraycans`, `boombox`, `mp3player`, `phonebook`, `fishingrod`, `fishingbait`, `fishweight`, `components`, `courierskill`, `fishingskill`, `guardskill`, `weaponskill`, `mechanicskill`, `lawyerskill`, `smugglerskill`, `toggletextdraws`, `toggleooc`, `togglephone`, `toggleadmin`, `togglehelper`, `togglenewbie`, `togglewt`, `toggleradio`, `togglevip`, `togglemusic`, `togglefaction`, `togglegang`, `togglenews`, `toggleglobal`, `togglecam`, `carlicense`, `vippackage`, `viptime`, `vipcooldown`, `weapon_0`, `weapon_1`, `weapon_2`, `weapon_3`, `weapon_4`, `weapon_5`, `weapon_6`, `weapon_7`, `weapon_8`, `weapon_9`, `weapon_10`, `weapon_11`, `weapon_12`, `ammo_0`, `ammo_1`, `ammo_2`, `ammo_3`, `ammo_4`, `ammo_5`, `ammo_6`, `ammo_7`, `ammo_8`, `ammo_9`, `ammo_10`, `ammo_11`, `ammo_12`, `faction`, `gang`, `factionrank`, `gangrank`, `division`, `contracted`, `contractby`, `bombs`, `completedhits`, `failedhits`, `reports`, `helprequests`, `speedometer`, `factionmod`, `gangmod`, `banappealer`, `potplanted`, `pottime`, `potgrams`, `pot_x`, `pot_y`, `pot_z`, `pot_a`, `inventoryupgrade`, `addictupgrade`, `traderupgrade`, `assetupgrade`, `laborupgrade`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `ammotype`, `ammoweapon`, `dmwarnings`, `weaponrestricted`, `referral_uid`, `refercount`, `watch`, `gps`, `prisonedby`, `prisonreason`, `togglehud`, `clothes`, `showturfs`, `showlands`, `watchon`, `gpson`, `doublexp`, `login_date`, `chatstyle`, `truckingxp`, `truckinglevel`, `vehiclecmd`, `adminstrike`, `dj`, `housealarm`, `vehlock`, `crowbar`, `graphic`, `helmet`, `togglevehicle`, `glassitem`, `metalitem`, `rubberitem`, `ironitem`, `plasticitem`, `u_accessories`, `u_accessories_used`, `weed`, `cocaine`, `thiefskill`, `togglepoints`, `toggleturfs`, `togglepm`, `togglereports`, `togglewhisper`, `togglebug`, `spawntype`, `spawnhouse`, `factionleader`, `crew`, `webdev`, `scripter`, `helpermanager`, `dynamicadmin`, `adminpersonnel`, `humanresources`, `complaintmod`, `weedplanted`, `weedtime`, `weedgrams`, `weed_x`, `weed_y`, `weed_z`, `weed_a`, `thiefcooldown`, `crackcooldown`, `newbiemutetime`, `reportmutetime`, `globalmutetime`, `adminhide`, `firstaid`, `policescanner`, `bodykits`, `rimkits`, `scanneron`, `cookfood`, `landkeys`, `bugged`, `rollerskates`, `couriercooldown`, `pizzacooldown`, `detectivecooldown`, `duty`, `bandana`, `detectiveskill`, `gascan`, `refunded`, `backpack`, `bpcash`, `bpmaterials`, `bppot`, `bpcrack`, `bpmeth`, `bppainkillers`, `bpweapon_0`, `bpweapon_1`, `bpweapon_2`, `bpweapon_3`, `bpweapon_4`, `bpweapon_5`, `bpweapon_6`, `bpweapon_7`, `bpweapon_8`, `bpweapon_9`, `bpweapon_10`, `bpweapon_11`, `bpweapon_12`, `bpweapon_13`, `bpweapon_14`, `bphpammo`, `bppoisonammo`, `bpfmjammo`, `formeradmin`, `deathcooldown`, `hunger`, `hungertimer`, `thirst`, `thirsttimer`, `covid`, `covidtimer`, `totalpatients`, `totalfires`, `rarecooldown`, `vipdlcooldown`, `customtitle`, `customcolor`, `mask`, `diamonds`, `ecoin`, `blindfold`, `rope`, `lockpick`, `repairkit`, `goldrim`, `food`, `drink`, `bandage`, `medkit`, `nationalid`, `diploma`, `insurance`, `passport`, `passportname`, `passportlevel`, `passportskin`, `passportphone`, `marriedto`, `newbies`, `chatanim`, `Lottery`, `LotteryB`, `flashlight`, `candy`, `gunlicense`, `gunlicensetime`, `dirtycash`, `comserv`, `voicechat`, `discordtag`, `discordname`, `money_earned`, `money_spent`) VALUES
(34, 'Anwar_Mohamed', '4D8EBF5711E03796EDFEEA519F10CCD9A8E62AAEB76F6A2545EADA749BE951856B09AC300B6DB67DBF4DD734786140BE9380F6D3E5E421B8590C8BF8E01EC932', '2023-03-20 13:45:50', '2023-03-20 13:45:50', '105.66.7.77', 0, 1, 65, 136, 1308.71, 1779.31, 745.948, 1310.37, 1781.33, 725.483, 286.303, 5, 1, 15000, 0, 0, 1, 0, 2, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 118, 100, 118, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(35, 'AJAXX_SIPO', '2F9959B230A44678DD2DC29F037BA1159F233AA9AB183CE3A0678EAAE002E5AA6F27F47144A1A4365116D3DB1B58EC47896623B92D85CB2F191705DAF11858B8', '2023-03-20 14:05:32', '2023-03-20 14:05:32', '196.70.175.205', 0, 1, 23, 135, -2330.24, 111.262, -4.574, -2328.88, 110.743, -5.394, 249.121, 1, 1, 14500, 0, 0, 1, 0, 6, 2, 0, 'None', 0, 50, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 77, 20, 77, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 500),
(36, 'POCO_LOCO', '0BDE518F9FD9C1E233F73B94003E43B6B9A8DF7847B4E1F86E6CE8D5C2B8127BD5BAA768719154F3ADB40835BB47E2C72645ACA41BE257E7D7E280E9F7771CC6', '2023-03-20 16:03:22', '2023-03-20 16:03:22', '41.142.60.228', 1, 1, 18, 299, 1538.41, -1697.68, 14.416, 1539.42, -1694.35, 14.595, 90.27, 0, 0, 15000, 0, 0, 1, 0, 1, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 1, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 38, 100, 38, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(37, 'Pablo_Hirmano', '987A1CFE5702D085A05EC05305DC5F48FB86A70EB6884BAAE9561AF700B8830328F4A8E75BBB1E44CA66184E6C5D59616685E3DBCD390C49CB406D4D2ECA5D35', '2023-03-20 17:11:17', '2023-03-20 17:11:17', '105.156.171.89', 0, 1, 40, 136, 54.689, -290.395, 3.754, 52.092, -292.143, 1.696, 167.399, 0, 0, 14700, 0, 0, 1, 0, 6, 2, 0, 'None', 0, 98, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 164, 98, 104, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 300),
(38, 'MADARA_33', '4E0658D00F47D86D19A0E792E4BB94B16DB2E902D307DA5637F57CF60E7A174CB4BB6D7095621745B2065DF0C87B77AF69F5D0FBD63359AD3CC6B72F076C3E1E', '2023-03-20 17:19:45', '2023-03-25 14:28:11', '105.69.96.210', 0, 1, 22, 137, 1527.2, -1635.23, 15.681, 1529.36, -1636.97, 13.383, 134.848, 0, 0, 15000, 0, 0, 1, 0, 20, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 94, 85, 91, 85, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(39, 'Jnyeen_Trix', 'FD867C982C604EC41792266043D72D6C65D43107A8F8599CD6B1A925FC846A10009E7448F31A310638DF094AF5E5F5783478526AC5634675BDD75AF466477BDE', '2023-03-20 17:36:38', '2023-03-21 18:51:00', '196.92.182.152', 0, 1, 25, 230, 1780.47, -1890.25, 13.971, 1779.33, -1888.58, 13.387, 256.605, 0, 0, 15000, 0, 0, 1, 0, 4, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 18, 99, 78, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(40, 'ZIZWAR_7M7', '008DE95703EC88B3209AF3804EA4E01C70457F874E757107078A7656030C98B4D4E3AACA1A368B78EAD62A90ADDA28233630A8507BCDA56D8742F9EBEB86A9FC', '2023-03-20 19:14:37', '2023-03-26 10:34:42', '160.178.254.51', 0, 1, 20, 134, 1074.23, -893.547, 103.515, 1080.57, -898.45, 77.153, 232.256, 0, 0, 215000, 0, 0, 1, 0, 24, 2, 0, 'None', 0, 12, 0, 0, 0, 1, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 92, 25, 88, 25, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 200000, 0),
(41, 'karim_pablo', '2F9959B230A44678DD2DC29F037BA1159F233AA9AB183CE3A0678EAAE002E5AA6F27F47144A1A4365116D3DB1B58EC47896623B92D85CB2F191705DAF11858B8', '2023-03-20 22:40:40', '2023-03-25 19:28:32', '197.205.154.61', 0, 1, 25, 79, 1377.54, -1730.12, 14.578, 1375.1, -1732.19, 13.383, 301.581, 0, 0, 12150, 0, 0, 1, 0, 41, 2, 0, 'None', 0, 93, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 796544, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 87, 151, 80, 91, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 2850),
(42, 'Tropa_Williams', 'D42BF311760C0A17915A43A3DBBA340C4E22F8D232EE25BDE712553E9811AC81F58F787151ECB69BE4ADE58D85B8F18D89F12DFEF26D2C6932AEFD41E7894DFE', '2023-03-21 08:20:44', '2023-03-21 08:20:44', '197.145.220.156', 0, 1, 28, 78, 1871.15, -1493.25, 4.003, 1872.83, -1496.3, 3.266, 57.176, 0, 0, 15000, 0, 0, 1, 0, 4, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 33, 99, 93, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(43, 'SALIM_LUCAS', 'DF4143CDA0BFB793CC642ED40E2A6F5A589FC09AB4AC6CF7AF756EC3B6D95E2E4C22423BD46FB43D1E7007226802AC5A9A66ECA69A04E43FC0A927BD24BEE136', '2023-03-21 13:18:37', '2023-03-21 13:33:41', '196.112.130.116', 0, 1, 24, 79, 1742.53, -1850.89, 14.56, 1744.32, -1852.56, 13.414, 215.608, 0, 0, 15000, 0, 0, 1, 0, 13, 2, 0, 'None', 0, 43, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 55, 94, 55, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(44, 'Carlos_Messi', '149CAD71473154885C1EEA00D2B1DA698B9BAFD2B9411390539873270AED99D68E7B04DD32DA1A51C3F305883A0DC2D1BDE2D9A9531C2FD9125FFCC85142C492', '2023-03-21 13:27:29', '2023-03-21 13:31:21', '105.72.63.112', 0, 1, 25, 137, 1743.26, -1850.64, 14.719, 1743.59, -1854.03, 13.414, 150.392, 0, 0, 15000, 0, 0, 1, 0, 6, 2, 0, 'None', 0, 58, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 26, 97, 26, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(45, 'Hamdi_johnson', '72127B42CB73393C2D8F9C6994043508B03E2C9C272C247A0C9A6EC834A12C9BAA99DA587355848996769F054313EA34A10584D881DFE7C77E5F3CB18B70ACE0', '2023-03-21 19:00:31', '2023-03-21 19:01:22', '196.118.137.194', 0, 1, 20, 136, 755.228, -1687.65, 4.883, 752.169, -1688.76, 4.177, 97.602, 0, 1, 15000, 0, 0, 1, 0, 0, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 64, 100, 64, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(46, 'POP_SMOKE', 'CB23EB1082330DA3DF317AC849F1EBB42BAFEB882B9A6F2EF7ED82A835F7A0D4298EF97B70AB1B91576587FDF157A31D7974ACCA221F10FB2B878821D8A586F0', '2023-03-21 20:34:45', '2023-03-21 20:34:45', '196.74.215.171', 0, 1, 21, 134, 1536.42, -1682.92, 15.027, 1534.63, -1683.25, 13.547, 202.692, 0, 0, 15000, 0, 0, 1, 0, 5, 2, 0, 'None', 0, 125, 100, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 138, 98, 78, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(47, 'Snop_Amar', '2F9959B230A44678DD2DC29F037BA1159F233AA9AB183CE3A0678EAAE002E5AA6F27F47144A1A4365116D3DB1B58EC47896623B92D85CB2F191705DAF11858B8', '2023-03-22 04:49:49', '2023-03-22 04:53:54', '105.66.128.235', 0, 1, 20, 136, -1132.88, 857.995, 4.065, -1132.91, 856.579, 3.16, 36, 0, 99999, 15000, 0, 0, 1, 0, 10, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 2, 3598, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 'psiko_boukhris', 'DM', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 32, 94, 32, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(48, 'Tristan_Tate', 'D923BAFA3B17B49FB4E862F2EDF12CD2702CBF1A5093A7DC64E3551C01B579842C71EE576EAAAA107586454E71C8FE40BFD176FEE83DC4B91CE85204C11CC47F', '2023-03-22 20:41:09', '2023-03-22 20:41:09', '41.251.38.87', 1, 1, 18, 299, 2795.04, -751.046, 190.658, 1529.6, -1691.2, 13.383, 1, 0, 0, 15000, 0, 0, 1, 0, 0, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 1, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 22, 100, 22, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(49, 'Amine_Darham', 'D923BAFA3B17B49FB4E862F2EDF12CD2702CBF1A5093A7DC64E3551C01B579842C71EE576EAAAA107586454E71C8FE40BFD176FEE83DC4B91CE85204C11CC47F', '2023-03-22 20:45:37', '2023-03-26 18:41:49', '160.176.119.53', 0, 1, 25, 79, 1475.34, -1642.31, 14.647, 1477.98, -1640.85, 14.148, 62.203, 0, 0, 15000, 460, 0, 1, 3, 24, 4, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 49, 87, 23, 27, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(50, 'LMCH_NATAZI', '63430683929E8B600B8654F640B421634D14F6DF5AFEC378893389C7BC034C6CF4DD07ACC640E0292005A3F89EBD662B94D9E6A576630DE770B3C9AEBFC85C89', '2023-03-22 21:16:42', '2023-03-22 21:16:42', '197.253.249.202', 0, 1, 20, 134, 1278.4, -1267.62, 14.52, 1276.23, -1267.61, 13.534, 90.21, 0, 0, 64430, 230, 0, 1, 2, 3, 3, 0, 'None', 0, 98, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, 5, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 86, 101, 79, 101, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 49730, 300),
(51, 'Onahi_Tiger', 'A90D3DBBDFB8AC9CD72081DBEB1BB63F989C7E7CE18B57FEEA8E45413AC6CB842C1D19B31EB85ED78E4BEF614CB07B64515C7DA88B7E75886AEECFDB774850C3', '2023-03-23 00:33:02', '2023-03-23 00:33:02', '160.179.196.184', 0, 1, 23, 230, 2071.43, 1233.31, 1020.08, 2069.4, 1235.08, 1019.08, 218.403, 1, 3000005, 13450, 0, 0, 1, 0, 15, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 592091, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 8, 0, 5, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 157, 93, 37, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 1550),
(52, 'Ferda_Fratilo', '3E403CF5693F867E2EA574E9EE45777F2F54C979C44A6505B704E11FCF4F9AA31B57F65643F8A75626FAE3F89C10C36667EE50C75A86AE64F6BDE37AD76B12D0', '2023-03-23 01:08:26', '2023-03-23 01:08:26', '105.66.1.131', 0, 1, 20, 135, 1326.57, 1789.21, 750.381, 1327.38, 1785.86, 749.185, 178.625, 5, 1, 15000, 0, 0, 1, 0, 0, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 47, 100, 47, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(53, 'MADARA_SHELBY', '93304E9CBF22FA68E69A18539E903225572248414C8EC79B5EFA7C677A5BBBC2A84FE40B6C99ED6FA37EAE0B50E89A15FD78B5A2F1BC741A19558BFB02CB7475', '2023-03-23 12:56:01', '2023-03-23 12:56:01', '105.155.228.40', 0, 1, 25, 136, 2233.3, -1551.82, 9.533, 2229.38, -1554.68, 1.976, 243.501, 0, 0, 14350, 0, 0, 1, 0, 16, 2, 0, 'None', 0, 95, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 161, 92, 101, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 650),
(54, 'Pedro_Admin', 'FBA8B22B1243A13FD85BF61C8E370396EFD96FC8ADCCC8E1A1A2F06AB84A3526E8CB1EEB259CCB9FFE8129DD87E9FEDE590386C76575DC249A88CC4581A86BC6', '2023-03-23 21:05:25', '2023-03-25 20:40:03', '41.141.136.236', 0, 1, 22, 304, 1525.09, -1664.7, 13.834, 1527.6, -1657.08, 12.948, 146.147, 0, 0, 14950, 0, 0, 1, 0, 23, 2, 13, 'None', 0, 100, 100, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 17, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, 230, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 93, 78, 89, 87, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 50),
(55, 'PROF_TIMSA7', '007552961F9453A374054A1ADC1F43325B141091A4C275CEBFB1073DAABCB6B9A1F0A366F8460B9EB98F4504BBF8FB889D81FF5CF69946734E53026C3D83FBD6', '2023-03-24 12:47:41', '2023-03-24 12:47:41', '160.164.116.162', 0, 1, 20, 135, 751.93, -1673.95, 16.01, 766.5, -1684.32, -6.86, 184.29, 0, 1, 15000, 0, 0, 1, 0, 1, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 28, 100, 28, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(56, 'nizar_nizar', 'DAB3CF23F2C98DC405BC19A156886025CF264E16B0A65144421117EE422C8BB1F529F815FACD785DA19EF108D7A5D83B078CF88060AD9CF9BBB4CDD7D366638C', '2023-03-24 17:48:03', '2023-03-26 18:17:42', '105.158.117.234', 0, 1, 29, 137, 771.207, -0.897, 1002.2, 771.929, -4.185, 1000.72, 259.966, 5, 3000006, 14350, 0, 0, 1, 0, 15, 2, 0, 'None', 0, 50, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 126, 19, 6, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 650),
(57, 'AMRO_MINE', '2EA7A0D2F69BD558A4476484F49E6A73AD9CE95CB0548E92C2A86244CF5370C3E16ADE5938FA6BF14D966A5B09162388EAB86F401CDC1E4A193B11CD630B6929', '2023-03-24 18:12:06', '2023-03-25 14:37:34', '41.92.22.43', 0, 1, 27, 62, 2189.03, -1792.97, 14.42, 2184.1, -1795.56, 13.365, 153.39, 0, 0, 14400, 3230, 0, 1, 1, 49, 3, 0, 'None', 0, 83, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 550744, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'X_Mafia', 'test ', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 15, 16, 75, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 600),
(58, 'salah_gozman', '6C4C8373F632BE1F0AC2D6369E51FD5E6E55D0AE267E20B620EB36F11D2960B850172B98FA3C63F13E07A77564F94F001BA01EA1106FB1CA15975433339E8606', '2023-03-24 18:14:21', '2023-03-24 18:28:03', '160.177.193.86', 0, 1, 21, 62, 1091.51, 2306.53, 12.585, 1094.74, 2307.19, 10.82, 235.177, 0, 0, 115000, 0, 0, 1, 0, 36, 2, 0, 'None', 0, 65, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 88, 70, 82, 70, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 100000, 0),
(59, 'SPECIAL_DEEB', '049DC8A33DA20406B929F7482D93FB10FED5A8F0AF9E5BDB0C4959EF783861E58658519C4D0144421F8F4D23120D7E5EFA155B99233342D0C3BC70C712820145', '2023-03-24 18:38:00', '2023-03-24 18:41:26', '160.179.13.58', 0, 1, 40, 124, 859.961, -1148.83, 25.327, 854.445, -1148.44, 23.206, 68.661, 0, 0, 15000, 0, 0, 1, 0, 7, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 28, 31, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 108, 97, 108, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(60, 'PITER_PARKER', 'FBA7661FFD7183FA28AD6BF8FEC8C3EB04C124CD92ADCFA6A277D555D1C33F3294567AE18CA3499F287B68DE806059CE2DB1BE07C074AE5706F3A02E91DB2F3A', '2023-03-24 21:13:35', '2023-03-27 20:15:56', '105.67.132.228', 0, 1, 40, 28, -2239.26, 129.615, 35.689, -2239.02, 128.469, 35.32, 230.019, 1, 1, 11850, 0, 0, 1, 0, 24, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 0, 5, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 93, 169, 89, 109, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 3150),
(61, 'Aymane_tobo', '3DC8A82A43430E16DDA6054A21E5ACA8A5E8374573B394DE0C4C512BD343B6D214BC58B8A60AD4DAEA3961378E52BDD729252D5FB144576D589945EE8AFC98FF', '2023-03-25 00:05:51', '2023-03-26 23:43:40', '41.92.23.20', 0, 1, 22, 114, 2186.04, -1793.25, 14.17, 2184.59, -1796.16, 13.366, 151.182, 0, 0, 4350, 9700, 0, 1, 0, 39, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 0, 5, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 60, 35, 60, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 10650),
(62, 'Simo_Black', '8B8EE0F2B512BC61B9C0DF41618BE2C980C0CF9FB0D6F5F0AB43C3CC8F133ABDBA5FC91D126C37849C5B9F99AEDF7C2598A242E11AE538A2990A95DB54D7DB2C', '2023-03-25 00:32:54', '2023-03-25 00:32:54', '105.71.145.218', 0, 1, 24, 136, 1329.43, 1785.54, 750.5, 1331.87, 1787.7, 749.185, 308.172, 5, 1, 15000, 0, 0, 1, 0, 1, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 65, 100, 65, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(63, 'LilD_Kingos', '0FDFFC89FAA31C5043EAA01F9D5424848F991E8F6A68980DCFE0AA0B108A7FEE8A3044A4B693CD56F5175136BCD9EE36C5F3D1130C35121530C0125641BFDFA9', '2023-03-25 01:52:31', '2023-03-25 22:02:49', '196.91.66.177', 0, 1, 19, 2, 2796.52, -1606.22, 11.703, 2794.7, -1609.24, 10.929, 136.723, 0, 0, 15000, 0, 0, 1, 0, 13, 2, 0, 'None', 0, 97, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 92, 94, 92, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(64, 'Cedos_Sparow', 'CCE08BBA3F2E3C029CD257104B06D4B075772D5F514CF1B7789506F9A69D53C51464881D2C18445AB290553B302F67A24B1C69E3E737A46215DEAF43517E4960', '2023-03-25 11:31:59', '2023-03-26 23:03:51', '196.119.174.37', 0, 1, 22, 123, 1830.98, -1843.6, 14.848, 1713.72, -1190.8, 23.214, 270.229, 0, 0, 13750, 0, 0, 1, 0, 51, 2, 0, 'None', 0, 86, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 347460, 4, -1, 0, 0, 0, 250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23, 0, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 7, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 83, 9, 75, 69, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 1250),
(65, 'Ismail_Sanch', '2F9D8E3F80A717DFE700062F53EA4455DEFAB1B66C2733332AF3C472AF0D44D33C473A83B4FB649A4B2ECF36CCFE16078DF8100867356A8E3655F90F65F3EC68', '2023-03-25 11:36:05', '2023-03-25 13:51:51', '105.67.0.148', 0, 1, 15, 2, 2017.03, -1812.53, 14.519, 2016.97, -1809.04, 13.383, 149.162, 0, 0, 65000, 0, 0, 1, 0, 7, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 52, 97, 52, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 50000, 0),
(66, 'HECTOR_BENZ', '8EB1F05B2396C73A5DACD4D47E09E0A6E613FB8D1509CE73CA8C26809E5BA6D965D372F73D0CCC0F55A05832A347271B2BDA8C036BC116E93556967C3A2EB27E', '2023-03-25 12:36:58', '2023-03-25 12:36:58', '196.77.45.233', 0, 1, 25, 136, 1766.42, -1857.12, 14.207, 1763.15, -1857.87, 13.414, 122.754, 0, 0, 15000, 0, 0, 1, 0, 1, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 84, 100, 84, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(67, 'Cryston_Robert', 'CCE08BBA3F2E3C029CD257104B06D4B075772D5F514CF1B7789506F9A69D53C51464881D2C18445AB290553B302F67A24B1C69E3E737A46215DEAF43517E4960', '2023-03-25 12:59:56', '2023-03-26 22:44:39', '160.179.0.29', 0, 1, 24, 300, 1198.84, -1338.15, 14.532, 1155.52, -1570.82, 12.842, 1.122, 0, 0, 13550, 230, 0, 1, 1, 4, 3, 0, 'None', 0, 50, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 109, 17, 109, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1000, 2450);
INSERT INTO `users` (`uid`, `username`, `password`, `regdate`, `lastlogin`, `ip`, `setup`, `gender`, `age`, `skin`, `camera_x`, `camera_y`, `camera_z`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `interior`, `world`, `cash`, `bank`, `paycheck`, `level`, `exp`, `minutes`, `hours`, `adminlevel`, `adminname`, `helperlevel`, `health`, `armor`, `upgradepoints`, `warnings`, `injured`, `hospital`, `spawnhealth`, `spawnarmor`, `jailtype`, `jailtime`, `newbiemuted`, `helpmuted`, `admuted`, `livemuted`, `globalmuted`, `reportmuted`, `reportwarns`, `fightstyle`, `locked`, `accent`, `cookies`, `phone`, `job`, `secondjob`, `crimes`, `arrested`, `wantedlevel`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `seeds`, `ephedrine`, `muriaticacid`, `bakingsoda`, `cigars`, `weaponclip`, `walkietalkie`, `channel`, `rentinghouse`, `spraycans`, `boombox`, `mp3player`, `phonebook`, `fishingrod`, `fishingbait`, `fishweight`, `components`, `courierskill`, `fishingskill`, `guardskill`, `weaponskill`, `mechanicskill`, `lawyerskill`, `smugglerskill`, `toggletextdraws`, `toggleooc`, `togglephone`, `toggleadmin`, `togglehelper`, `togglenewbie`, `togglewt`, `toggleradio`, `togglevip`, `togglemusic`, `togglefaction`, `togglegang`, `togglenews`, `toggleglobal`, `togglecam`, `carlicense`, `vippackage`, `viptime`, `vipcooldown`, `weapon_0`, `weapon_1`, `weapon_2`, `weapon_3`, `weapon_4`, `weapon_5`, `weapon_6`, `weapon_7`, `weapon_8`, `weapon_9`, `weapon_10`, `weapon_11`, `weapon_12`, `ammo_0`, `ammo_1`, `ammo_2`, `ammo_3`, `ammo_4`, `ammo_5`, `ammo_6`, `ammo_7`, `ammo_8`, `ammo_9`, `ammo_10`, `ammo_11`, `ammo_12`, `faction`, `gang`, `factionrank`, `gangrank`, `division`, `contracted`, `contractby`, `bombs`, `completedhits`, `failedhits`, `reports`, `helprequests`, `speedometer`, `factionmod`, `gangmod`, `banappealer`, `potplanted`, `pottime`, `potgrams`, `pot_x`, `pot_y`, `pot_z`, `pot_a`, `inventoryupgrade`, `addictupgrade`, `traderupgrade`, `assetupgrade`, `laborupgrade`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `ammotype`, `ammoweapon`, `dmwarnings`, `weaponrestricted`, `referral_uid`, `refercount`, `watch`, `gps`, `prisonedby`, `prisonreason`, `togglehud`, `clothes`, `showturfs`, `showlands`, `watchon`, `gpson`, `doublexp`, `login_date`, `chatstyle`, `truckingxp`, `truckinglevel`, `vehiclecmd`, `adminstrike`, `dj`, `housealarm`, `vehlock`, `crowbar`, `graphic`, `helmet`, `togglevehicle`, `glassitem`, `metalitem`, `rubberitem`, `ironitem`, `plasticitem`, `u_accessories`, `u_accessories_used`, `weed`, `cocaine`, `thiefskill`, `togglepoints`, `toggleturfs`, `togglepm`, `togglereports`, `togglewhisper`, `togglebug`, `spawntype`, `spawnhouse`, `factionleader`, `crew`, `webdev`, `scripter`, `helpermanager`, `dynamicadmin`, `adminpersonnel`, `humanresources`, `complaintmod`, `weedplanted`, `weedtime`, `weedgrams`, `weed_x`, `weed_y`, `weed_z`, `weed_a`, `thiefcooldown`, `crackcooldown`, `newbiemutetime`, `reportmutetime`, `globalmutetime`, `adminhide`, `firstaid`, `policescanner`, `bodykits`, `rimkits`, `scanneron`, `cookfood`, `landkeys`, `bugged`, `rollerskates`, `couriercooldown`, `pizzacooldown`, `detectivecooldown`, `duty`, `bandana`, `detectiveskill`, `gascan`, `refunded`, `backpack`, `bpcash`, `bpmaterials`, `bppot`, `bpcrack`, `bpmeth`, `bppainkillers`, `bpweapon_0`, `bpweapon_1`, `bpweapon_2`, `bpweapon_3`, `bpweapon_4`, `bpweapon_5`, `bpweapon_6`, `bpweapon_7`, `bpweapon_8`, `bpweapon_9`, `bpweapon_10`, `bpweapon_11`, `bpweapon_12`, `bpweapon_13`, `bpweapon_14`, `bphpammo`, `bppoisonammo`, `bpfmjammo`, `formeradmin`, `deathcooldown`, `hunger`, `hungertimer`, `thirst`, `thirsttimer`, `covid`, `covidtimer`, `totalpatients`, `totalfires`, `rarecooldown`, `vipdlcooldown`, `customtitle`, `customcolor`, `mask`, `diamonds`, `ecoin`, `blindfold`, `rope`, `lockpick`, `repairkit`, `goldrim`, `food`, `drink`, `bandage`, `medkit`, `nationalid`, `diploma`, `insurance`, `passport`, `passportname`, `passportlevel`, `passportskin`, `passportphone`, `marriedto`, `newbies`, `chatanim`, `Lottery`, `LotteryB`, `flashlight`, `candy`, `gunlicense`, `gunlicensetime`, `dirtycash`, `comserv`, `voicechat`, `discordtag`, `discordname`, `money_earned`, `money_spent`) VALUES
(68, 'SIMO_LMRAKXI', 'DE7AE818B27AC217C6D0C4E4F52D68A728775C06299651431B4B14B61EAE46E307BC60BF65F7337B4203EAACD40C6772317C3378F8E769C74997EE753633CA1E', '2023-03-25 13:12:43', '2023-03-26 18:25:14', '105.158.104.29', 0, 1, 35, 135, 947.988, -1642.87, 704.726, 947.728, -1644.3, 703.899, 170.739, 13, 0, 15000, 0, 0, 1, 0, 5, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 87, 98, 27, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(69, 'Ayman_Pedro', '9BC11107615693DB1B5093E5DC1BC5F1B4D65E70A4AF8B941FF3355719111D0F22F834BDEAE33421A707FD032B9FC91538A848DA878CC6042457A4ECF5576C3A', '2023-03-25 13:20:55', '2023-03-25 13:26:51', '105.67.0.148', 0, 1, 22, 79, 1799.44, -1886.23, 15.703, 1808.54, -1882.51, 13.411, 340.341, 0, 0, 14100, 0, 0, 1, 0, 4, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 418640, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 74, 98, 14, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 900),
(70, 'Selfx_Tchapo', '7A378013789FAB6839E5CA57BE3DCE30A968D50AC05B0B9387FD2E4ED187502B47A77FF7CC07D7CD9105B7D01996807C1905CADA1A97867D8D81510846DCC4D4', '2023-03-25 14:42:12', '2023-03-25 14:42:12', '196.115.46.208', 0, 1, 21, 136, 1480.5, -1753.18, 18.43, 1480.68, -1756.66, 17.531, 182.959, 0, 0, 13610, 0, 0, 1, 0, 9, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 919335, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 153, 96, 33, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 1390),
(71, 'benzz_lcasawi', 'C5F5ADF620B4B6FA3B8C6F7920896A1B7EB9DF35D9968124726E3BD38B92FE0160090202DB55A7C00A1796D3473B66A563C3D2C4435E10C3FD670FE62D7727F6', '2023-03-25 15:30:44', '2023-03-25 17:05:16', '88.124.138.153', 0, 1, 20, 71, 2335.06, -1505.96, 26.368, 2343.29, -1505.4, 23.557, 274.806, 0, 0, 41450, 10460, 0, 1, 2, 5, 4, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 893739, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, 78, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3468, 0, 6468, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 689000, 662550),
(72, 'hmed_twil', '36E9467F8AF8B61588233117DE1416EE6299B67B96E077FB5169A6931022D5FC8E36C5C62DC2198BBFBF1625C480AAE91CB7BCF7CF5DAE1A44484CF545108030', '2023-03-25 16:44:35', '2023-03-25 16:44:35', '196.118.102.132', 0, 1, 14, 137, 1482.92, -1119.53, 24.631, 1482.14, -1122.92, 23.811, 171.697, 0, 0, 15000, 0, 0, 1, 0, 11, 2, 0, 'None', 0, 100, 100, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 97, 138, 95, 78, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(73, 'Cheblyyy_Baggio', '6C12695A231D98E7DF7EE6A6546EFEBFAB2DA1F7E7BC2641429279BC8F38AB72DA3367CC983F293CA6FBF9132BD5AA59A7C867B7B083666A361125614DBEF6E2', '2023-03-25 20:22:55', '2023-03-27 11:42:30', '41.142.70.67', 0, 1, 20, 49, 1211.3, -1324.52, 14.426, 1207.82, -1325.55, 13.398, 86.011, 0, 0, 16705, 3230, 0, 1, 1, 66, 3, 0, 'None', 0, 90, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 5, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '18969|19067|0|0|0|0|0|0', '0|1|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 38, 16, 32, 16, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 10000, 8295),
(74, 'Imad_Ghiberti', '2B689FD512021EE8914F06FA42187799A6DB5E30554251AE8FC72AE3368E35C191E99F1E530E305DDD654B344048357016A299DC595F8FCA28CE1E7A94A5599C', '2023-03-25 20:34:39', '2023-03-25 20:34:39', '41.140.227.236', 0, 1, 22, 79, 1260.79, -1801.53, 17.789, 1260.03, -1824.98, 13.263, 181.656, 0, 0, 14850, 0, 0, 1, 0, 4, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 58, 99, 118, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 150),
(75, 'ENZO_CHL7', '2F9959B230A44678DD2DC29F037BA1159F233AA9AB183CE3A0678EAAE002E5AA6F27F47144A1A4365116D3DB1B58EC47896623B92D85CB2F191705DAF11858B8', '2023-03-25 21:02:56', '2023-03-26 13:34:51', '196.118.15.151', 0, 1, 17, 136, 1109.62, -1441.28, 17.131, 1112.89, -1440.44, 15.797, 268.684, 0, 0, 14850, 0, 0, 1, 0, 8, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 98, 67, 97, 67, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 150),
(76, 'AMRO_JOBINO', '2EA7A0D2F69BD558A4476484F49E6A73AD9CE95CB0548E92C2A86244CF5370C3E16ADE5938FA6BF14D966A5B09162388EAB86F401CDC1E4A193B11CD630B6929', '2023-03-26 01:33:27', '2023-03-27 17:51:59', '41.92.45.145', 0, 1, 50, 62, 2178.01, -1810.26, 14.729, 2174, -1809.04, 13.044, 3.003, 0, 0, 14500, 6463, 0, 1, 3, 18, 4, 0, 'None', 0, 98, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 47, 153, 45, 93, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 1000, 1500),
(77, 'X_Mafia', '90C086088483CEF266D771E4FC049C2CE6C8DDA007DB88815454AE8A462F88A11BAA2990A3C6501A9720736D905B9CB1425E2A266B589CA8786AD1247374DB79', '2023-03-26 02:09:30', '2023-03-27 18:16:39', '105.66.131.139', 0, 1, 19, 123, 1543.2, -1675.24, 14.329, 1539.73, -1674.81, 13.547, 82.901, 0, 0, 999, 26158, 0, 1, 11, 19, 11, 13, 'None', 0, 95, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 7, 0, 6, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '18911|19624|0|0|0|0|0|0', '1|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 35, 6, 28, 66, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 14001),
(78, 'Hitman_ZERO', '61505123EDB27CF5816403A8B04291226B7F51696C64591CA6BCB70C94A7CC19F2F7619FD05FCFD6B8B01BFB6F3895F6B2CEEC8EC3A4E2EE90AAD4D1D0D0CD07', '2023-03-26 02:20:37', '2023-03-26 02:20:37', '196.64.231.115', 1, 1, 18, 299, 1529.86, -1694.6, 14.168, 1529.79, -1691.1, 13.383, 271.163, 0, 0, 15000, 0, 0, 1, 0, 0, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 1, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 4, 100, 4, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(79, 'GSI3A_LMHAYB', '78541CFB65B3F1A3959BCC844273862857F76BD32765400070D1CC0C9956AF63C12A26A96AA0F4F7E62EB9E7F0F187F5A46B8F92E14F96F41B10168222BE8B2F', '2023-03-26 10:50:16', '2023-03-26 10:50:16', '197.145.152.3', 0, 1, 25, 137, 1310.31, 1779.79, 750.007, 1310.27, 1780.72, 749.185, 38.221, 5, 1, 15000, 0, 0, 1, 0, 1, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 92, 100, 92, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(80, 'LMHYB_LEOVANO', '913E880590E21D2060CB84C50E2143E7D1E936E745AFF885232F0149D887A016E64267C79DC06EF0D4D726C86DD93194426C12ED5E29B3DFC79639032BE36D97', '2023-03-26 11:34:25', '2023-03-26 11:34:25', '196.119.48.172', 0, 1, 25, 230, 1312.07, 1781.41, 750.422, 1310.43, 1781.16, 749.185, 98.497, 5, 1, 15000, 0, 0, 1, 0, 18, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 170, 92, 110, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(81, 'Ahmed_lhaj', '56A44D6259E8A6642E29575BA10E367C92D73D702AB683E7676F476420D3E7A79D2779C9717969735867044B08656B8831EA69FD80B609A4392B640883C9FFEB', '2023-03-26 12:56:48', '2023-03-26 12:56:48', '41.104.59.114', 0, 1, 22, 135, 1312.7, 1780.03, 751.802, 1310.74, 1781.17, 749.185, 309.587, 5, 1, 15000, 0, 0, 1, 0, 3, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 1, 99, 61, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(82, 'mohamad_goto', '286699B1482F88222E5F6FA1DF7269978639BB7A4D3542D114B000924FDC977F86BDCD6FDA8CEC8930805454B78BCDDE52AB12F4B9C7BBA6E199DE5EE661394B', '2023-03-26 13:52:00', '2023-03-27 11:50:59', '105.69.116.136', 0, 1, 23, 230, 1894.54, -2067.92, 15.405, 1892.37, -2067.93, 15.03, 30.189, 0, 0, 15000, 0, 0, 1, 0, 10, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 96, 12, 94, 12, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(83, 'VIRUS_narcos', '599123D91FD2DED0BD36FE60518E1891FAEE5F5FE6C51BDE566DEC3554B258FD2F8A1423435887A2299373FAA075902028C7BA52D8CBC85606469E8400010FDC', '2023-03-26 14:52:23', '2023-03-26 14:52:23', '105.159.236.43', 0, 1, 24, 134, 1319.84, 1787.57, 750.331, 1316.88, 1782.94, 749.185, 121.038, 5, 1, 15000, 0, 0, 1, 0, 3, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 99, 52, 99, 112, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(84, 'Ayoub_bakh', 'D1434CEFCAC4742125A8F4EB029A9CBEF33F2A85EF47FBC72EF28034C306DA4C6E65F971CF50E0068A7FC90A5EF814E984A3D143C2E94B698DDDE2FD1AA83BA9', '2023-03-26 15:38:12', '2023-03-26 22:31:38', '105.69.94.60', 0, 1, 18, 137, 1404.23, -2201.22, 20.082, 1407.97, -2201.49, 18.177, 281.686, 0, 0, 14850, 230, 0, 1, 1, 15, 3, 0, 'None', 0, 56, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 81, 37, 72, 97, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 150),
(85, 'Ahmed_mohamadi', '1F3114CD1EA097F7766B97427070EBFAB959C3AEE7AFC949330FEB8C086A35536DE7DF4186DE57958A6A81CB274F39F671E9AB6FECA7C488DBC873FB2FAC5335', '2023-03-26 19:38:49', '2023-03-26 19:38:49', '196.119.156.83', 0, 1, 23, 136, 1326.31, 1781.98, 750.279, 1323.21, 1782.99, 749.185, 72.539, 5, 1, 15000, 0, 0, 1, 0, 2, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 129, 99, 9, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(86, 'Kvara_escobar', '03DCE0D508A46B0E2F5240471A7AEF0E295CE77948B15C030BAE011F438F53341C2B24681D60459FCD1B5B64912DF79B4FF099411B5843B302E0FCA760040BE3', '2023-03-26 21:26:57', '2023-03-27 17:49:45', '41.142.41.127', 0, 1, 20, 2, 1745.49, -1956.44, 15.585, 1744.45, -1951.01, 14.117, 113.85, 0, 0, 25000, 690, 0, 1, 3, 0, 5, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 33, 40, 93, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 10000, 0),
(87, 'GREN_BTRIK', '120E263BA2CDDD005A25ED4713BE62EAA2030FB41A52E2993A97A3F70E5A4203DD1EDC678AF177D88F894FEC3C7CDD5E822D096E49F46BD13CB3D7416163A084', '2023-03-26 21:31:30', '2023-03-27 17:27:13', '197.253.244.235', 0, 1, 23, 61, -1154.12, 836.51, 40.298, -1138.71, 847.703, 35.876, 305.986, 0, 0, 327099, 460, 0, 1, 2, 10, 4, 0, 'None', 0, 90, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 506699, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 71, 90, 56, 30, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 320000, 7901),
(88, 'BADR_PEDRI', '9DFEA49E08CDB59C2F5B08829BC1CEE777642E3DDC88E770510597A24D507FF8C105B8488621818BEEB1C43189F49D002050DA07958B3215C3812E11E1B24DCC', '2023-03-27 01:57:41', '2023-03-27 01:57:41', '105.155.18.50', 0, 1, 22, 134, 1093.84, 1487.35, 47.102, 1099.55, 1601.5, 32.343, 12.392, 0, 1, 15000, 0, 0, 1, 0, 2, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 127, 99, 7, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(89, 'WALID_PABLO', '4583DE9168CEC8D13E683D7D43422B297F8BBE2E888E72DD480EDBB430A5F6B2793F167C56346CE88D9C05E5A4F3DC26308F09DB8D6278B14CE96DE006998AFC', '2023-03-27 11:13:47', '2023-03-27 17:01:54', '105.67.6.16', 0, 1, 16, 134, 1344.16, 1787.67, 750.446, 1342.68, 1786.89, 749.185, 117.31, 5, 1, 15000, 0, 0, 1, 0, 1, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100, 50, 100, 50, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0),
(90, 'Mike_tyson', 'E168693CFF343B7BFA4036243E937F24A9879634DA752346ADE7E0958FF5A9ABF27297D9DCC58D4E932F2FC83127B81CD0B2F85ABFDF0C75F9DCEFE162A157EF', '2023-03-27 16:55:08', '2023-03-27 17:14:37', '105.159.137.21', 0, 1, 24, 137, 1879.91, -1742.85, 15.436, 1878.8, -1743.09, 13.547, 279.241, 0, 0, 4605, 0, 0, 1, 0, 16, 2, 0, 'None', 0, 72, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, 'None', 0, 769360, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, 0, 5, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 95, 111, 92, 51, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 10395),
(91, 'Angad_smaklo', 'EECEDA64A618677DF34728B324EA9F210B0880003CB2BC9A85638385269109D6F048D0B6745CFA47867113FFF67CB63C7EE4AD65811D383B5623635199A6BE7E', '2023-03-27 18:05:47', '2023-03-27 19:52:49', '160.176.185.50', 0, 1, 19, 2, 666.861, -1317.77, 16.445, 668.335, -1315.66, 13.577, 320.316, 0, 0, 15000, 0, 0, 1, 0, 32, 2, 0, 'None', 0, 100, 0, 0, 0, 0, 0, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 'None', 0, 0, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, 0, 0, -1, 0, 'Nobody', 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'No-one', 'None', 0, -1, 1, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '0|0|0|0|0|0|0|0', '0|0|0|0|0|0|0|0', 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 89, 1, 84, 61, 100, 0, 0, 0, 0, 0, '0', '0', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 1290000, 0, 0, NULL, NULL, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(10) NOT NULL,
  `ownerid` int(10) DEFAULT '0',
  `owner` varchar(24) DEFAULT 'Nobody',
  `modelid` smallint(3) DEFAULT '0',
  `price` int(10) DEFAULT '0',
  `tickets` int(10) DEFAULT '0',
  `locked` tinyint(1) DEFAULT '0',
  `plate` varchar(32) DEFAULT 'None',
  `fuel` tinyint(3) DEFAULT '100',
  `health` float DEFAULT '1000',
  `pos_x` float DEFAULT '0',
  `pos_y` float DEFAULT '0',
  `pos_z` float DEFAULT '0',
  `pos_a` float DEFAULT '0',
  `color1` smallint(3) DEFAULT '0',
  `color2` smallint(3) DEFAULT '0',
  `paintjob` smallint(3) DEFAULT '-1',
  `registered` int(11) DEFAULT NULL,
  `interior` tinyint(2) DEFAULT '0',
  `world` int(10) DEFAULT '0',
  `neon` smallint(5) DEFAULT '0',
  `neonenabled` tinyint(1) DEFAULT '0',
  `trunk` tinyint(1) DEFAULT '0',
  `mod_1` smallint(4) DEFAULT '0',
  `mod_2` smallint(4) DEFAULT '0',
  `mod_3` smallint(4) DEFAULT '0',
  `mod_4` smallint(4) DEFAULT '0',
  `mod_5` smallint(4) DEFAULT '0',
  `mod_6` smallint(4) DEFAULT '0',
  `mod_7` smallint(4) DEFAULT '0',
  `mod_8` smallint(4) DEFAULT '0',
  `mod_9` smallint(4) DEFAULT '0',
  `mod_10` smallint(4) DEFAULT '0',
  `mod_11` smallint(4) DEFAULT '0',
  `mod_12` smallint(4) DEFAULT '0',
  `mod_13` smallint(4) DEFAULT '0',
  `mod_14` smallint(4) DEFAULT '0',
  `cash` int(10) DEFAULT '0',
  `materials` int(10) DEFAULT '0',
  `pot` int(10) DEFAULT '0',
  `crack` int(10) DEFAULT '0',
  `meth` int(10) DEFAULT '0',
  `painkillers` int(10) DEFAULT '0',
  `weapon_1` tinyint(2) DEFAULT '0',
  `weapon_2` tinyint(2) DEFAULT '0',
  `weapon_3` tinyint(2) DEFAULT '0',
  `ammo_1` smallint(5) DEFAULT '0',
  `ammo_2` smallint(5) DEFAULT '0',
  `ammo_3` smallint(5) DEFAULT '0',
  `gangid` tinyint(2) DEFAULT '-1',
  `factiontype` tinyint(2) DEFAULT '0',
  `job` tinyint(2) DEFAULT '-1',
  `respawndelay` int(10) DEFAULT '0',
  `pistolammo` smallint(5) DEFAULT '0',
  `shotgunammo` smallint(5) DEFAULT '0',
  `smgammo` smallint(5) DEFAULT '0',
  `arammo` smallint(5) DEFAULT '0',
  `rifleammo` smallint(5) DEFAULT '0',
  `hpammo` smallint(5) DEFAULT '0',
  `poisonammo` smallint(5) DEFAULT '0',
  `fmjammo` smallint(5) DEFAULT '0',
  `impounded` tinyint(1) NOT NULL DEFAULT '0',
  `siren` int(10) DEFAULT '0',
  `vippackage` int(10) DEFAULT '0',
  `carImpounded` int(10) DEFAULT '0',
  `carImpoundPrice` int(10) DEFAULT '0',
  `mileage` int(10) DEFAULT '0',
  `rank` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `vehicles`
--

INSERT INTO `vehicles` (`id`, `ownerid`, `owner`, `modelid`, `price`, `tickets`, `locked`, `plate`, `fuel`, `health`, `pos_x`, `pos_y`, `pos_z`, `pos_a`, `color1`, `color2`, `paintjob`, `registered`, `interior`, `world`, `neon`, `neonenabled`, `trunk`, `mod_1`, `mod_2`, `mod_3`, `mod_4`, `mod_5`, `mod_6`, `mod_7`, `mod_8`, `mod_9`, `mod_10`, `mod_11`, `mod_12`, `mod_13`, `mod_14`, `cash`, `materials`, `pot`, `crack`, `meth`, `painkillers`, `weapon_1`, `weapon_2`, `weapon_3`, `ammo_1`, `ammo_2`, `ammo_3`, `gangid`, `factiontype`, `job`, `respawndelay`, `pistolammo`, `shotgunammo`, `smgammo`, `arammo`, `rifleammo`, `hpammo`, `poisonammo`, `fmjammo`, `impounded`, `siren`, `vippackage`, `carImpounded`, `carImpoundPrice`, `mileage`, `rank`) VALUES
(1367, 0, 'Nobody', 416, 0, 0, 0, 'BXF 551', 100, 1000, 1177.18, -1308.78, 13.954, 267.509, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, -1486618625, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1368, 0, 'Nobody', 416, 0, 0, 0, 'DGF 616', 100, 1000, 1145.68, -1316.32, 13.772, 87.689, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 1874919423, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1369, 0, 'Nobody', 416, 0, 0, 0, 'JRF 285', 100, 1000, 1145.6, -1310.68, 13.805, 90.293, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 1874919423, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1370, 0, 'Nobody', 586, 0, 0, 0, 'QIV 741', 100, 1000, 1146.72, -1304.6, 13.128, 81.415, 146, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 1874919423, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1371, 0, 'Nobody', 586, 0, 0, 0, 'YVA 591', 100, 1000, 1146.7, -1301.64, 13.181, 84.024, 146, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, 1874919423, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1373, 0, 'Nobody', 416, 0, 0, 0, 'CQL 613', 100, 1000, 2034.84, -1432.21, 17.255, 178.887, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, -1981284353, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1374, 0, 'Nobody', 416, 0, 0, 0, 'CGO 539', 100, 1000, 2016.18, -1410.47, 17.141, 267.083, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 2, -1, -1486618625, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1375, 0, 'Nobody', 490, 0, 0, 0, 'RDE 712', 100, 1000, 280.941, -1531, 24.721, 234.208, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, -159383553, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1376, 0, 'Nobody', 490, 0, 0, 0, 'BGJ 135', 100, 1000, 284.459, -1526.52, 24.721, 233.308, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, -159383553, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1377, 0, 'Nobody', 490, 0, 0, 0, 'IMC 991', 100, 1000, 287.336, -1521.65, 24.732, 233.348, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, -159383553, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1378, 0, 'Nobody', 541, 0, 0, 0, 'EKO 254', 100, 1000, 290.74, -1516.8, 24.254, 234.654, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 6, -1, -159383553, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1385, 0, 'Nobody', 475, 0, 0, 0, 'POK 712', 100, 1000, 2205.94, -1164.82, 25.534, 91.451, 5, 5, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, -1530494977, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1396, 0, 'Nobody', 412, 0, 0, 0, 'BMA 833', 100, 1000, 2643.34, -2022.26, 13.384, 357.596, 5, 5, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, -1, -1981284353, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1397, 0, 'Nobody', 412, 0, 0, 0, 'WMI 372', 100, 1000, 2646.64, -1996.5, 13.371, 269.187, 5, 5, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, -1, -1981284353, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1399, 0, 'Nobody', 468, 0, 0, 0, 'NTW 776', 100, 1000, 2768.32, -1606.61, 10.59, 272.102, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1316134911, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1400, 0, 'Nobody', 468, 0, 0, 0, 'YUE 373', 100, 1000, 2768.66, -1614.97, 10.591, 274.89, 6, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 1316134911, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1402, 0, 'Nobody', 536, 0, 0, 0, 'VXY 741', 100, 1000, 2171.09, -1807.75, 13.114, 0.29, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1403, 0, 'Nobody', 468, 0, 0, 0, 'VFW 506', 100, 1000, 2165.36, -1808.6, 13.045, 357.229, 2, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1405, 0, 'Nobody', 536, 0, 0, 0, 'OKJ 701', 100, 1000, 2206.37, -1168.91, 25.466, 91.906, 5, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, -727379969, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1406, 0, 'Nobody', 468, 0, 0, 0, 'CPC 512', 100, 1000, 210.334, -257.757, 1.247, 83.51, 5, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1409, 0, 'Nobody', 468, 0, 0, 0, 'XYF 592', 100, 1000, 2509.25, -1667.55, 13.103, 86.109, 243, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1316134911, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1411, 0, 'Nobody', 536, 0, 0, 0, 'MNE 318', 100, 1000, 2507.25, -1669.39, 13.117, 88.473, 243, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 276447231, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1412, 0, 'Nobody', 468, 0, 0, 0, 'UFY 883', 100, 1000, 2507.45, -1672.42, 13.043, 91.238, 243, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 276447231, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1413, 0, 'Nobody', 463, 0, 0, 0, 'VGP 811', 100, 1000, 1917.02, -2074.74, 13.101, 273.279, 30, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1414, 0, 'Nobody', 463, 0, 0, 0, 'JLJ 349', 100, 1000, 1915.85, -2081.96, 13.112, 269.368, 30, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1415, 0, 'Nobody', 536, 0, 0, 0, 'EQB 910', 100, 1000, 1918.39, -2078.21, 13.305, 267.769, 30, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, -1, 1215752191, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1417, 0, 'Nobody', 525, 0, 0, 0, 'CMP 637', 100, 1000, 1793.32, -1069.66, 23.838, 181.449, 200, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 9, -1, -1486618625, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1418, 0, 'Nobody', 409, 0, 0, 0, 'VKY 665', 100, 1000, -2263.86, 2288.82, 4.574, 355.667, 127, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 3, -1, 999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1419, 0, 'Nobody', 560, 0, 0, 0, 'RYQ 111', 100, 1000, -2271.9, 2306.45, 4.525, 270.014, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1420, 0, 'Nobody', 560, 0, 0, 1, 'CFE 845', 100, 1000, -2272.09, 2309.23, 4.525, 269.709, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1421, 0, 'Nobody', 560, 0, 0, 0, 'IMR 976', 100, 1000, -2272.33, 2312.38, 4.525, 270.207, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1422, 0, 'Nobody', 560, 0, 0, 0, 'MGG 518', 100, 1000, -2272.17, 2315.17, 4.525, 269.614, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1423, 0, 'Nobody', 522, 0, 0, 0, 'BSN 609', 100, 1000, -2272.92, 2318.2, 4.39, 271.32, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1424, 0, 'Nobody', 522, 0, 0, 0, 'SGU 404', 100, 1000, -2273.18, 2321.4, 4.387, 269.124, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1425, 0, 'Nobody', 522, 0, 0, 0, 'CHS 209', 100, 1000, -2273.22, 2324.14, 4.384, 271.433, 0, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1426, 0, 'Nobody', 541, 0, 0, 0, 'UAB 882', 100, 1000, -2272.65, 2327.34, 4.445, 271.743, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1427, 0, 'Nobody', 541, 0, 0, 0, 'RTD 902', 100, 1000, -2272.22, 2330.21, 4.441, 271.382, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1428, 0, 'Nobody', 487, 0, 0, 0, 'FGO 161', 100, 1000, 1450.14, 2009.31, 11.029, 316.354, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1429, 0, 'Nobody', 456, 0, 0, 0, 'UTP 990', 100, 1000, -2253.38, 2317.99, 4.986, 90.685, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1430, 0, 'Nobody', 456, 0, 0, 1, 'BSM 508', 100, 1000, -2252.81, 2315, 4.986, 89.634, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1431, 0, 'Nobody', 453, 0, 0, 0, 'FQT 841', 100, 1000, -2321.33, 2327.52, -0.329, 184.545, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1432, 0, 'Nobody', 454, 0, 0, 0, 'XOJ 481', 100, 1000, -2321.23, 2311.64, 0.301, 185.274, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1433, 0, 'Nobody', 472, 0, 0, 0, 'SOO 372', 100, 1000, -2313.32, 2329.92, 0.068, 179.735, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7, 0, -1, 1233977344, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1434, 0, 'Nobody', 482, 0, 0, 0, 'IXG 844', 100, 1000, 2217.63, -1169.63, 25.852, 93.239, 147, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, -1, -956301312, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1441, 0, 'Nobody', 560, 0, 0, 0, 'YMN 615', 100, 1000, 755.704, -1333.47, 13.244, 183.86, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1442, 0, 'Nobody', 560, 0, 0, 0, 'CYB 445', 100, 1000, 759.49, -1333.27, 13.244, 184.48, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1443, 0, 'Nobody', 582, 0, 0, 0, 'HOW 401', 100, 1000, 751.565, -1334.79, 13.59, 182.565, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1444, 0, 'Nobody', 582, 0, 0, 0, 'HUU 141', 100, 1000, 746.754, -1335.84, 13.586, 182.511, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1445, 0, 'Nobody', 586, 0, 0, 0, 'UIC 297', 100, 1000, 743.391, -1335.43, 13.052, 185.672, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1446, 0, 'Nobody', 586, 0, 0, 0, 'DVF 852', 100, 1000, 741.573, -1334.08, 13.054, 185.672, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1447, 0, 'Nobody', 488, 0, 0, 0, 'QXT 972', 100, 1000, 736.202, -1374.99, 25.841, 178.629, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1448, 0, 'Nobody', 488, 0, 0, 0, 'XQG 655', 100, 1000, 744.233, -1371.65, 25.87, 358.154, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 3, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1451, 0, 'Nobody', 525, 0, 0, 0, 'SUE 233', 100, 1000, 1784.27, -1068.97, 23.704, 179.962, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 9, -1, 99999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1452, 0, 'Nobody', 525, 0, 0, 0, 'ATW 495', 100, 1000, 1775.22, -1069.33, 23.697, 181.318, -1, -1, -1, NULL, 0, 0, 18649, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 9, -1, 99999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1453, 0, 'Nobody', 525, 0, 0, 0, 'XQS 994', 100, 1000, 1766.19, -1069.04, 23.698, 180.536, -1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 9, -1, 9999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1454, 0, 'Nobody', 468, 0, 0, 0, 'FCQ 808', 100, 1000, 1683.72, -2108.08, 13.049, 273.142, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1455, 0, 'Nobody', 468, 0, 0, 0, 'OAK 895', 100, 1000, 1683.95, -2116.65, 13.148, 268.054, 3, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1464, 0, 'Nobody', 468, 0, 0, 0, 'MSX 857', 100, 1000, 1002.09, -1432.72, 13.216, 194.701, 1, -1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1465, 0, 'Nobody', 468, 0, 0, 0, 'HQW 775', 100, 1000, 1012.34, -1432.59, 13.216, 181.523, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1466, 0, 'Nobody', 533, 0, 0, 0, 'SGE 593', 100, 1000, 1006.88, -1434.59, 13.258, 176.801, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1467, 1, 'psiko_boukhris', 541, 0, 0, 1, 'OHP 761', 20, 1000, 1502.91, 2001.81, 10.445, 0.634, 3, 3, -1, NULL, 0, 0, 18647, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1085, 0, 0, 0, 0, 0, 0, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1469, 16, 'James_Edrian', 500, 660000, 0, 0, 'ITF 250', 100, 996.89, 1191.07, -1330.62, 13.582, 174.233, 135, 135, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1470, 7, 'Vini_Edrian', 500, 660000, 0, 1, 'GPJ 777', 97, 997.234, 1175.72, -1339.23, 14.063, 270.798, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1471, 30, 'CORLO_NEGRO', 0, 0, 0, 0, 'OFN 700', 100, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1474, 11, 'GOD_TIPO', 560, 0, 0, 0, 'LCJ 119', 88, 1000, 555.951, -1278.43, 17.242, 44.147, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1475, 30, 'CORLO_NEGRO', 500, 660000, 0, 0, 'WNO 684', 100, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1476, 4, 'Pablo_Walid', 400, 250000, 0, 0, 'CBB 813', 90, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1477, 30, 'CORLO_NEGRO', 500, 660000, 0, 0, 'PPQ 153', 100, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1478, 1, 'psiko_boukhris', 451, 0, 0, 0, 'THC 738', 17, 1000, 1499.62, 2001.91, 10.528, 357.819, 3, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1479, 24, 'ROCH_PRAN', 587, 0, 0, 0, 'UFF 526', 48, 300, 1768.11, -1077.97, 23.715, 185.894, 6, 6, -1, NULL, 0, 0, 18650, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1481, 7, 'Vini_Edrian', 541, 0, 0, 0, 'XHQ 188', 100, 1000, 1219.08, -829.939, 85.027, 75.565, 1, 1, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1482, 17, 'JAIMSE_PALACIO', 400, 250000, 0, 0, 'DQX 213', 100, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1483, 17, 'JAIMSE_PALACIO', 489, 300000, 0, 0, 'QDI 360', 100, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1484, 17, 'JAIMSE_PALACIO', 500, 660000, 0, 0, 'QIY 952', 100, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1485, 17, 'JAIMSE_PALACIO', 579, 440000, 0, 0, 'KCJ 739', 92, 927.901, 1359.73, -1753.84, 13.287, 181.177, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1486, 0, 'Nobody', 567, 0, 0, 0, 'XLE 459', 100, 1000, 2770.3, -1610.97, 10.791, 270.303, 6, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, -1, 999999999, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1487, 8, 'X_Mafiat', 541, 0, 0, 0, 'UTY 807', 97, 938.973, 1751.9, -1109.17, 24.078, 254.577, 1, 3, -1, NULL, 0, 0, 18647, 1, 0, 0, 0, 0, 0, 0, 1010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1491, 0, 'Nobody', 468, 0, 0, 0, 'UEL 887', 100, 1000, 2174.81, -1807.61, 13.044, 3.003, 2, 2, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1492, 1, 'psiko_boukhris', 489, 300000, 0, 1, 'QXH 184', 47, 794.902, 1003.39, -1459.48, 13.644, 358.238, 1, 1, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 100000, 0, 0, 0, 0, 0, 23, 23, 23, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1493, 71, 'benzz_lcasawi', 500, 660000, 0, 0, 'PTO 159', 86, 1000, 0, 0, 0, 0, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1494, 0, 'Nobody', 533, 0, 0, 0, 'NWB 241', 100, 1000, 1684.69, -2112.9, 13.179, 267.669, 3, 3, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1495, 24, 'ROCH_PRAN', 500, 660000, 0, 0, 'SRP 962', 81, 1000, 1831.97, -1744.93, 13.593, 264.375, 99, 1, -1, NULL, 0, 0, 18648, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1496, 24, 'ROCH_PRAN', 489, 300000, 0, 1, 'LIG 983', 69, 882.776, 1535.2, -1693.7, 13.604, 3.183, 0, 0, -1, NULL, 0, 0, 18652, 1, 3, 0, 0, 0, 0, 0, 1010, 0, 1083, 0, 1087, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(1497, 1, 'psiko_boukhris', 500, 660000, 0, 1, 'SBJ 557', 95, 1000, 997.356, -1459.88, 13.653, 358.595, 0, 0, -1, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `weapons`
--

CREATE TABLE `weapons` (
  `uid` int(10) DEFAULT NULL,
  `slot` tinyint(2) DEFAULT NULL,
  `weaponid` tinyint(2) DEFAULT NULL,
  `ammo` smallint(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables exportées
--

--
-- Index pour la table `bans`
--
ALTER TABLE `bans`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Index pour la table `billboards`
--
ALTER TABLE `billboards`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `businesses`
--
ALTER TABLE `businesses`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `changes`
--
ALTER TABLE `changes`
  ADD UNIQUE KEY `slot` (`slot`);

--
-- Index pour la table `charges`
--
ALTER TABLE `charges`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `clothing`
--
ALTER TABLE `clothing`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `crates`
--
ALTER TABLE `crates`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `crews`
--
ALTER TABLE `crews`
  ADD UNIQUE KEY `id` (`id`,`crewid`) USING BTREE;

--
-- Index pour la table `criminals`
--
ALTER TABLE `criminals`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `divisions`
--
ALTER TABLE `divisions`
  ADD UNIQUE KEY `id` (`id`,`divisionid`);

--
-- Index pour la table `entrances`
--
ALTER TABLE `entrances`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `factionlockers`
--
ALTER TABLE `factionlockers`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `factionpay`
--
ALTER TABLE `factionpay`
  ADD UNIQUE KEY `id` (`id`,`rank`) USING BTREE;

--
-- Index pour la table `factionranks`
--
ALTER TABLE `factionranks`
  ADD UNIQUE KEY `id` (`id`,`rank`) USING BTREE;

--
-- Index pour la table `factions`
--
ALTER TABLE `factions`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `factionskins`
--
ALTER TABLE `factionskins`
  ADD UNIQUE KEY `id` (`id`,`slot`) USING BTREE;

--
-- Index pour la table `flags`
--
ALTER TABLE `flags`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `gangranks`
--
ALTER TABLE `gangranks`
  ADD UNIQUE KEY `id` (`id`,`rank`) USING BTREE;

--
-- Index pour la table `gangskins`
--
ALTER TABLE `gangskins`
  ADD UNIQUE KEY `id` (`id`,`slot`) USING BTREE;

--
-- Index pour la table `garages`
--
ALTER TABLE `garages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `gates`
--
ALTER TABLE `gates`
  ADD PRIMARY KEY (`gateID`);

--
-- Index pour la table `gunracks`
--
ALTER TABLE `gunracks`
  ADD PRIMARY KEY (`rackID`);

--
-- Index pour la table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `impoundlots`
--
ALTER TABLE `impoundlots`
  ADD PRIMARY KEY (`impoundID`);

--
-- Index pour la table `kills`
--
ALTER TABLE `kills`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `landobjects`
--
ALTER TABLE `landobjects`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `lands`
--
ALTER TABLE `lands`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Index pour la table `log_admin`
--
ALTER TABLE `log_admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_bans`
--
ALTER TABLE `log_bans`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_cheat`
--
ALTER TABLE `log_cheat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_contracts`
--
ALTER TABLE `log_contracts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_faction`
--
ALTER TABLE `log_faction`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_gang`
--
ALTER TABLE `log_gang`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_give`
--
ALTER TABLE `log_give`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_namechanges`
--
ALTER TABLE `log_namechanges`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_property`
--
ALTER TABLE `log_property`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_punishments`
--
ALTER TABLE `log_punishments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_referrals`
--
ALTER TABLE `log_referrals`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `log_vip`
--
ALTER TABLE `log_vip`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `object`
--
ALTER TABLE `object`
  ADD PRIMARY KEY (`mobjID`);

--
-- Index pour la table `phonebook`
--
ALTER TABLE `phonebook`
  ADD UNIQUE KEY `number` (`number`);

--
-- Index pour la table `points`
--
ALTER TABLE `points`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `rp_atms`
--
ALTER TABLE `rp_atms`
  ADD PRIMARY KEY (`atmID`);

--
-- Index pour la table `rp_contacts`
--
ALTER TABLE `rp_contacts`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `rp_dealercars`
--
ALTER TABLE `rp_dealercars`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Company` (`Company`);

--
-- Index pour la table `rp_furniture`
--
ALTER TABLE `rp_furniture`
  ADD PRIMARY KEY (`fID`);

--
-- Index pour la table `rp_gundamages`
--
ALTER TABLE `rp_gundamages`
  ADD UNIQUE KEY `Weapon` (`Weapon`);

--
-- Index pour la table `rp_payphones`
--
ALTER TABLE `rp_payphones`
  ADD PRIMARY KEY (`phID`);

--
-- Index pour la table `shots`
--
ALTER TABLE `shots`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `speedcameras`
--
ALTER TABLE `speedcameras`
  ADD PRIMARY KEY (`speedID`);

--
-- Index pour la table `texts`
--
ALTER TABLE `texts`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `turfs`
--
ALTER TABLE `turfs`
  ADD UNIQUE KEY `id` (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- Index pour la table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `weapons`
--
ALTER TABLE `weapons`
  ADD UNIQUE KEY `uid` (`uid`,`slot`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `bans`
--
ALTER TABLE `bans`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `billboards`
--
ALTER TABLE `billboards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `businesses`
--
ALTER TABLE `businesses`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT pour la table `charges`
--
ALTER TABLE `charges`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `clothing`
--
ALTER TABLE `clothing`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `crates`
--
ALTER TABLE `crates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `crews`
--
ALTER TABLE `crews`
  MODIFY `id` tinyint(2) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `criminals`
--
ALTER TABLE `criminals`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `entrances`
--
ALTER TABLE `entrances`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=531;
--
-- AUTO_INCREMENT pour la table `factionlockers`
--
ALTER TABLE `factionlockers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;
--
-- AUTO_INCREMENT pour la table `flags`
--
ALTER TABLE `flags`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT pour la table `garages`
--
ALTER TABLE `garages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `gates`
--
ALTER TABLE `gates`
  MODIFY `gateID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;
--
-- AUTO_INCREMENT pour la table `gunracks`
--
ALTER TABLE `gunracks`
  MODIFY `rackID` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `impoundlots`
--
ALTER TABLE `impoundlots`
  MODIFY `impoundID` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `kills`
--
ALTER TABLE `kills`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=548;
--
-- AUTO_INCREMENT pour la table `landobjects`
--
ALTER TABLE `landobjects`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `lands`
--
ALTER TABLE `lands`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `log_admin`
--
ALTER TABLE `log_admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5676;
--
-- AUTO_INCREMENT pour la table `log_bans`
--
ALTER TABLE `log_bans`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `log_cheat`
--
ALTER TABLE `log_cheat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1496;
--
-- AUTO_INCREMENT pour la table `log_contracts`
--
ALTER TABLE `log_contracts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `log_faction`
--
ALTER TABLE `log_faction`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1722;
--
-- AUTO_INCREMENT pour la table `log_gang`
--
ALTER TABLE `log_gang`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=222;
--
-- AUTO_INCREMENT pour la table `log_give`
--
ALTER TABLE `log_give`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=261;
--
-- AUTO_INCREMENT pour la table `log_namechanges`
--
ALTER TABLE `log_namechanges`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `log_property`
--
ALTER TABLE `log_property`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT pour la table `log_punishments`
--
ALTER TABLE `log_punishments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT pour la table `log_referrals`
--
ALTER TABLE `log_referrals`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `log_vip`
--
ALTER TABLE `log_vip`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT pour la table `object`
--
ALTER TABLE `object`
  MODIFY `mobjID` int(8) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `rp_atms`
--
ALTER TABLE `rp_atms`
  MODIFY `atmID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT pour la table `rp_contacts`
--
ALTER TABLE `rp_contacts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT pour la table `rp_dealercars`
--
ALTER TABLE `rp_dealercars`
  MODIFY `ID` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `rp_furniture`
--
ALTER TABLE `rp_furniture`
  MODIFY `fID` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `rp_payphones`
--
ALTER TABLE `rp_payphones`
  MODIFY `phID` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `shots`
--
ALTER TABLE `shots`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;
--
-- AUTO_INCREMENT pour la table `speedcameras`
--
ALTER TABLE `speedcameras`
  MODIFY `speedID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `texts`
--
ALTER TABLE `texts`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT pour la table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1498;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
