Cheats
------

The list below shows cheats IDs and additional information that is passed via AC_OnCheatDetected.

*	__ID = 0:	unknown hack__

	Extra parameter is reserved for debugging purposes.

*	__ID = 1:	desync__
	
	Extra parameter is reserved for sync type.
	
*	__ID = 2:	high ping__

	Extra parameter is reserved for actual ping.

*	__ID = 3:	low fps__

	Extra parameter is reserved for actual FPS rate.
	
*	__ID = 4:	afk__

	Extra parameter is `true` if player is AFK now and `false` if it isn't anymore.
	
*	__ID = 5:	health hack__
*	__ID = 6:	armour hack__
*	__ID = 7:	money hack__
*	__ID = 8:	fake kill__
*	__ID = 9:	teleport hack__
*	__ID = 10:	speed hack__
*	__ID = 11:	fly hack__
*	__ID = 12:	airbreak hack__
*	__ID = 13:	weapon hack__
*	__ID = 14:	joypad__
*	__ID = 15:	aim bot__
*	__ID = 16:	jetpack hack__
*	__ID = 17:	vehicle warp hack__
*	__ID = 18:	vehicle repair hack__
*	__ID = 19:	vehicle (illegal) mod__
*	__ID = 20:	RCON bruteforcer__
*	__ID = 21:	m0d_sa (hacking tool)__
